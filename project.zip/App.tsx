import 'react-native-gesture-handler';
import React, { useEffect, useState } from 'react';
import { Platform, StyleSheet } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { enableScreens } from 'react-native-screens';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
} from '@expo-google-fonts/inter';
import Toast from 'react-native-toast-message';
import { RootNavigator } from './src/navigation';
import { getSession } from './src/data/store';

// react-native-screens has no native module on web — only enable on iOS/Android.
enableScreens(Platform.OS !== 'web');

export default function App() {
  const [fontsLoaded] = useFonts({
    'Inter-Regular': Inter_400Regular,
    'Inter-Medium': Inter_500Medium,
    'Inter-SemiBold': Inter_600SemiBold,
    'Inter-Bold': Inter_700Bold,
  });
  const [initialRoute, setInitialRoute] = useState<'Login' | 'MainTabs' | null>(null);

  useEffect(() => {
    getSession().then((session) => setInitialRoute(session ? 'MainTabs' : 'Login'));
  }, []);

  if (!fontsLoaded || initialRoute === null) {
    return null;
  }

  return (
    <GestureHandlerRootView style={styles.root}>
      <SafeAreaProvider style={styles.root}>
        <StatusBar style="dark" />
        <NavigationContainer>
          <RootNavigator initialRouteName={initialRoute} />
        </NavigationContainer>
      </SafeAreaProvider>
      {/* Sibling of SafeAreaProvider so a screen's overflow:'hidden' never clips the toast. */}
      <Toast />
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    ...(Platform.OS === 'web'
      ? { height: '100vh' as any, maxHeight: '100vh' as any, overflow: 'hidden' as const }
      : {}),
  },
});
