import { Platform } from 'react-native';

// NOTE: do NOT read the "platform" query param here — Expo's own Metro dev
// server already reserves that exact key. A differently-named param is used.
if (Platform.OS === 'web' && typeof window !== 'undefined') {
  const forced = new URLSearchParams(window.location.search).get('forcePlatform');
  if (forced === 'ios' || forced === 'android') {
    // Only patch Platform.select() — never reassign Platform.OS itself, because
    // third-party native libraries read it to pick native branches that don't
    // exist on web.
    const originalSelect = Platform.select ? Platform.select.bind(Platform) : null;
    Platform.select = (specifics) => {
      if (forced in specifics) return specifics[forced];
      if ('default' in specifics) return specifics.default;
      return originalSelect ? originalSelect(specifics) : undefined;
    };
  }
}
