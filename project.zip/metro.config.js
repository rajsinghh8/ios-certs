const { getDefaultConfig } = require('expo/metro-config');
const config = getDefaultConfig(__dirname);

// Force JSC for the web bundle — Metro otherwise defaults the dev-server's
// index.bundle?platform=web request to transform.engine=hermes (a native
// Android/iOS-only engine), which a real browser cannot execute and leaves
// the page blank. platform=android / platform=ios requests are untouched
// so the native APK/IPA builds keep using Hermes as intended.
config.server.rewriteRequestUrl = (url) => {
  if (url.includes('platform=web')) {
    return url.replace('transform.engine=hermes', 'transform.engine=jsc');
  }
  return url;
};

module.exports = config;
