import { TaskPriority, TaskStatus, ProjectStatus, Availability } from '../types';

export const TASK_STATUSES: TaskStatus[] = ['To Do', 'In Progress', 'Done'];
export const TASK_PRIORITIES: TaskPriority[] = ['Low', 'Medium', 'High'];
export const PROJECT_STATUSES: ProjectStatus[] = ['Planning', 'Active', 'On Hold', 'Completed'];
export const AVAILABILITIES: Availability[] = ['Available', 'Busy', 'Away'];

export const MIN_PASSWORD_LENGTH = 6;
export const RECENT_ACTIVITY_LIMIT = 10;
export const SIMULATED_LATENCY_MS = 400;
