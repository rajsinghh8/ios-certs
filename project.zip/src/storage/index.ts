import { MMKV } from 'react-native-mmkv';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';

// Encrypted at rest — this key is app-level, not per-user/per-install, which is
// fine for a generated demo/starter app; a production app should source it from
// a per-install secret instead of hardcoding it here.
const mmkv =
  Platform.OS === 'web'
    ? null
    : new MMKV({ id: 'app-storage', encryptionKey: 'frontendx-app-storage-key' });

export const storage = {
  getItem: async (key: string): Promise<string | null> =>
    Platform.OS === 'web' ? AsyncStorage.getItem(key) : (mmkv!.getString(key) ?? null),
  setItem: async (key: string, value: string): Promise<void> =>
    Platform.OS === 'web' ? AsyncStorage.setItem(key, value) : mmkv!.set(key, value),
  deleteItem: async (key: string): Promise<void> =>
    Platform.OS === 'web' ? AsyncStorage.removeItem(key) : mmkv!.delete(key),
};
