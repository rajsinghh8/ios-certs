import { apiClient } from '../api/client';
import { storage } from '../utils/storage';
import { Appointment, Location, ScheduleOverride, Service, Session, StaffMember, User, WaitlistEntry, WeeklySchedule } from '../types';
import { appointments, demoUsers, locations, scheduleOverrides, services, staff, waitlist, weeklySchedules } from './mockData';

export const USE_MOCK = true;

type EntityKey = 'app_locations' | 'app_services' | 'app_staff' | 'app_appointments' | 'app_waitlist' | 'app_schedules' | 'app_overrides' | 'app_users';

async function readJson<T>(key: EntityKey, fallback: T): Promise<T> {
  const raw = await storage.getItem(key);
  if (!raw) {
    await storage.setItem(key, JSON.stringify(fallback));
    return fallback;
  }
  return JSON.parse(raw) as T;
}

async function writeJson<T>(key: EntityKey, value: T): Promise<T> {
  await storage.setItem(key, JSON.stringify(value));
  return value;
}

const createId = (prefix: string) => `${prefix}${Date.now()}`;

async function localLogin(email: string, password: string): Promise<Session | null> {
  const saved = await readJson<User[]>('app_users', []);
  const all = [...demoUsers, ...saved];
  const existing = all.find((u) => u.email.toLowerCase() === email.toLowerCase());
  const user = existing ?? { id: createId('u'), name: email.split('@')[0] || 'Operator', email, password, role: 'operator' as const };
  if (!existing) {
    await writeJson('app_users', [...saved, user]);
  }
  return { token: `mock-${user.id}`, userId: user.id, name: user.name, email: user.email, role: user.role };
}

export async function login(email: string, password: string): Promise<Session | null> {
  const session = USE_MOCK ? await localLogin(email, password) : (await apiClient.post<Session>('/api/v1/auth/login', { email, password })).data;
  if (!session) return null;
  await storage.setItem('auth_token', JSON.stringify(session));
  return session;
}

async function localSignup(name: string, email: string, password: string): Promise<Session | null> {
  const users = await readJson<User[]>('app_users', []);
  const existing = [...demoUsers, ...users].find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (existing) return null;
  const user: User = { id: createId('u'), name, email, password, role: 'operator' };
  await writeJson('app_users', [...users, user]);
  return { token: `mock-${user.id}`, userId: user.id, name: user.name, email: user.email, role: user.role };
}

export async function signup(name: string, email: string, password: string): Promise<Session | null> {
  const session = USE_MOCK ? await localSignup(name, email, password) : (await apiClient.post<Session>('/api/v1/auth/signup', { name, email, password })).data;
  if (!session) return null;
  await storage.setItem('auth_token', JSON.stringify(session));
  return session;
}

export async function logout(): Promise<void> {
  await storage.deleteItem('auth_token');
}

export const getLocations = async (): Promise<Location[]> => USE_MOCK ? readJson('app_locations', locations) : (await apiClient.get<Location[]>('/api/v1/locations')).data;
export const saveLocation = async (input: Omit<Location, 'id'> & { id?: string }): Promise<Location> => {
  if (!USE_MOCK) return (await apiClient.post<Location>('/api/v1/locations', input)).data;
  const items = await getLocations();
  const item: Location = { id: input.id ?? createId('loc'), name: input.name, city: input.city, timezone: input.timezone, address: input.address };
  await writeJson('app_locations', input.id ? items.map((i) => i.id === input.id ? item : i) : [...items, item]);
  return item;
};

export const getServices = async (): Promise<Service[]> => USE_MOCK ? readJson('app_services', services) : (await apiClient.get<Service[]>('/api/v1/services')).data;
export const saveService = async (input: Omit<Service, 'id'> & { id?: string }): Promise<Service> => {
  if (!USE_MOCK) return (await apiClient.post<Service>('/api/v1/services', input)).data;
  const items = await getServices();
  const item: Service = { id: input.id ?? createId('svc'), name: input.name, durationMinutes: input.durationMinutes, priceCents: input.priceCents, staffIds: input.staffIds };
  await writeJson('app_services', input.id ? items.map((i) => i.id === input.id ? item : i) : [...items, item]);
  return item;
};

export const getStaff = async (): Promise<StaffMember[]> => USE_MOCK ? readJson('app_staff', staff) : (await apiClient.get<StaffMember[]>('/api/v1/staff')).data;
export const saveStaff = async (input: Omit<StaffMember, 'id' | 'color'> & { id?: string; color?: string }): Promise<StaffMember> => {
  if (!USE_MOCK) return (await apiClient.post<StaffMember>('/api/v1/staff', input)).data;
  const items = await getStaff();
  const item: StaffMember = { id: input.id ?? createId('st'), name: input.name, locationId: input.locationId, serviceIds: input.serviceIds, color: input.color ?? '#0F766E' };
  await writeJson('app_staff', input.id ? items.map((i) => i.id === input.id ? item : i) : [...items, item]);
  return item;
};

export const getAppointments = async (): Promise<Appointment[]> => USE_MOCK ? readJson('app_appointments', appointments) : (await apiClient.get<Appointment[]>('/api/v1/appointments')).data;
export const saveAppointments = async (items: Appointment[]): Promise<Appointment[]> => writeJson('app_appointments', items);
export const createAppointment = async (input: Omit<Appointment, 'id' | 'createdAt' | 'status'>): Promise<Appointment> => {
  if (!USE_MOCK) return (await apiClient.post<Appointment>('/api/v1/appointments', input)).data;
  const items = await getAppointments();
  const appointment: Appointment = { ...input, id: createId('apt'), status: 'confirmed', createdAt: new Date().toISOString() };
  await writeJson('app_appointments', [...items, appointment]);
  return appointment;
};

export const getWaitlist = async (): Promise<WaitlistEntry[]> => USE_MOCK ? readJson('app_waitlist', waitlist) : (await apiClient.get<WaitlistEntry[]>('/api/v1/waitlist')).data;
export const saveWaitlist = async (items: WaitlistEntry[]): Promise<WaitlistEntry[]> => writeJson('app_waitlist', items);
export const createWaitlistEntry = async (input: Omit<WaitlistEntry, 'id' | 'createdAt' | 'notified'>): Promise<WaitlistEntry> => {
  if (!USE_MOCK) return (await apiClient.post<WaitlistEntry>('/api/v1/waitlist', input)).data;
  const items = await getWaitlist();
  const item: WaitlistEntry = { ...input, id: createId('w'), notified: false, createdAt: new Date().toISOString() };
  await writeJson('app_waitlist', [...items, item]);
  return item;
};

export const getSchedules = async (): Promise<WeeklySchedule[]> => USE_MOCK ? readJson('app_schedules', weeklySchedules) : (await apiClient.get<WeeklySchedule[]>('/api/v1/schedules')).data;
export const saveSchedules = async (items: WeeklySchedule[]): Promise<WeeklySchedule[]> => writeJson('app_schedules', items);
export const getOverrides = async (): Promise<ScheduleOverride[]> => USE_MOCK ? readJson('app_overrides', scheduleOverrides) : (await apiClient.get<ScheduleOverride[]>('/api/v1/overrides')).data;
export const saveOverrides = async (items: ScheduleOverride[]): Promise<ScheduleOverride[]> => writeJson('app_overrides', items);
