import { apiClient } from '../api/client';
import { Appointment, Location, ScheduleOverride, Service, StaffMember, User, WaitlistEntry, WeeklyScheduleDay } from '../types';
import { storage } from '../utils/storage';
import { appointments, demoUsers, locations, scheduleOverrides, services, staffMembers, waitlistEntries, weeklySchedules } from './mockData';

export const USE_MOCK = true;

type Session = { token: string; userId: string; name: string; email: string; role: User['role'] };

type EntityMap = {
  locations: Location[];
  services: Service[];
  staff: StaffMember[];
  appointments: Appointment[];
  waitlist: WaitlistEntry[];
  weeklySchedules: WeeklyScheduleDay[];
  scheduleOverrides: ScheduleOverride[];
  users: User[];
};

const seeds: EntityMap = {
  locations,
  services,
  staff: staffMembers,
  appointments,
  waitlist: waitlistEntries,
  weeklySchedules,
  scheduleOverrides,
  users: demoUsers,
};

async function readJson<K extends keyof EntityMap>(key: K): Promise<EntityMap[K]> {
  const raw = await storage.getItem(`ipa_${key}`);
  if (!raw) {
    const seeded = seeds[key];
    await storage.setItem(`ipa_${key}`, JSON.stringify(seeded));
    return seeded;
  }
  return JSON.parse(raw) as EntityMap[K];
}

async function writeJson<K extends keyof EntityMap>(key: K, value: EntityMap[K]): Promise<void> {
  await storage.setItem(`ipa_${key}`, JSON.stringify(value));
}

const newId = (prefix: string) => `${prefix}_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

async function localLogin(email: string, password: string): Promise<Session | null> {
  const users = await readJson('users');
  let match = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (!match) {
    match = { id: newId('u'), name: email.split('@')[0] || 'New User', email, password, role: 'operator' };
    await writeJson('users', [...users, match]);
  }
  const session: Session = { token: `mock-${match.id}`, userId: match.id, name: match.name, email: match.email, role: match.role };
  await storage.setItem('auth_token', JSON.stringify(session));
  return session;
}

export async function login(email: string, password: string): Promise<Session | null> {
  const session = USE_MOCK ? await localLogin(email, password) : (await apiClient.post('/api/v1/auth/login', { email, password })).data;
  if (session) await storage.setItem('auth_token', JSON.stringify(session));
  return session;
}

async function localSignup(name: string, email: string, password: string): Promise<Session | null> {
  const users = await readJson('users');
  const existing = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  const user = existing ?? { id: newId('u'), name, email, password, role: 'operator' as const };
  if (!existing) await writeJson('users', [...users, user]);
  const session: Session = { token: `mock-${user.id}`, userId: user.id, name: user.name, email: user.email, role: user.role };
  await storage.setItem('auth_token', JSON.stringify(session));
  return session;
}

export async function signup(name: string, email: string, password: string): Promise<Session | null> {
  const session = USE_MOCK ? await localSignup(name, email, password) : (await apiClient.post('/api/v1/auth/signup', { name, email, password })).data;
  if (session) await storage.setItem('auth_token', JSON.stringify(session));
  return session;
}

export async function logout(): Promise<void> {
  if (!USE_MOCK) await apiClient.post('/api/v1/auth/logout');
  await storage.deleteItem('auth_token');
}

export const getLocations = async (): Promise<Location[]> => (USE_MOCK ? readJson('locations') : (await apiClient.get('/api/v1/locations')).data);
export const saveLocation = async (input: Omit<Location, 'id'> & { id?: string }): Promise<Location> => {
  if (!USE_MOCK) return (await apiClient.post('/api/v1/locations', input)).data;
  const rows = await readJson('locations');
  const item = { ...input, id: input.id ?? newId('loc') };
  await writeJson('locations', input.id ? rows.map((r) => (r.id === input.id ? item : r)) : [...rows, item]);
  return item;
};

export const getServices = async (): Promise<Service[]> => (USE_MOCK ? readJson('services') : (await apiClient.get('/api/v1/services')).data);
export const saveService = async (input: Omit<Service, 'id'> & { id?: string }): Promise<Service> => {
  if (!USE_MOCK) return (await apiClient.post('/api/v1/services', input)).data;
  const rows = await readJson('services');
  const item = { ...input, id: input.id ?? newId('svc') };
  await writeJson('services', input.id ? rows.map((r) => (r.id === input.id ? item : r)) : [...rows, item]);
  return item;
};

export const getStaff = async (): Promise<StaffMember[]> => (USE_MOCK ? readJson('staff') : (await apiClient.get('/api/v1/staff')).data);
export const saveStaff = async (input: Omit<StaffMember, 'id'> & { id?: string }): Promise<StaffMember> => {
  if (!USE_MOCK) return (await apiClient.post('/api/v1/staff', input)).data;
  const rows = await readJson('staff');
  const item = { ...input, id: input.id ?? newId('st') };
  await writeJson('staff', input.id ? rows.map((r) => (r.id === input.id ? item : r)) : [...rows, item]);
  return item;
};

export const getAppointments = async (): Promise<Appointment[]> => (USE_MOCK ? readJson('appointments') : (await apiClient.get('/api/v1/appointments')).data);
export const saveAppointment = async (input: Omit<Appointment, 'id' | 'createdAt'> & { id?: string; createdAt?: string }): Promise<Appointment> => {
  if (!USE_MOCK) return (await apiClient.post('/api/v1/appointments', input)).data;
  const rows = await readJson('appointments');
  const item = { ...input, id: input.id ?? newId('appt'), createdAt: input.createdAt ?? new Date().toISOString() };
  await writeJson('appointments', input.id ? rows.map((r) => (r.id === input.id ? item : r)) : [...rows, item]);
  return item;
};

export const updateAppointmentStatus = async (id: string, status: Appointment['status']): Promise<Appointment | null> => {
  const rows = await getAppointments();
  const updated = rows.map((row) => (row.id === id ? { ...row, status } : row));
  if (USE_MOCK) await writeJson('appointments', updated);
  else await apiClient.patch(`/api/v1/appointments/${id}`, { status });
  return updated.find((row) => row.id === id) ?? null;
};

export const getWaitlist = async (): Promise<WaitlistEntry[]> => (USE_MOCK ? readJson('waitlist') : (await apiClient.get('/api/v1/waitlist')).data);
export const saveWaitlistEntry = async (input: Omit<WaitlistEntry, 'id' | 'createdAt' | 'notified'> & { id?: string; createdAt?: string; notified?: boolean }): Promise<WaitlistEntry> => {
  if (!USE_MOCK) return (await apiClient.post('/api/v1/waitlist', input)).data;
  const rows = await readJson('waitlist');
  const item = { ...input, id: input.id ?? newId('wl'), createdAt: input.createdAt ?? new Date().toISOString(), notified: input.notified ?? false };
  await writeJson('waitlist', input.id ? rows.map((r) => (r.id === input.id ? item : r)) : [...rows, item]);
  return item;
};

export const getWeeklySchedules = async (): Promise<WeeklyScheduleDay[]> => (USE_MOCK ? readJson('weeklySchedules') : (await apiClient.get('/api/v1/schedules/weekly')).data);
export const saveWeeklySchedules = async (rows: WeeklyScheduleDay[]): Promise<WeeklyScheduleDay[]> => {
  if (!USE_MOCK) return (await apiClient.post('/api/v1/schedules/weekly', rows)).data;
  await writeJson('weeklySchedules', rows);
  return rows;
};

export const getScheduleOverrides = async (): Promise<ScheduleOverride[]> => (USE_MOCK ? readJson('scheduleOverrides') : (await apiClient.get('/api/v1/schedules/overrides')).data);
export const saveScheduleOverride = async (input: Omit<ScheduleOverride, 'id'> & { id?: string }): Promise<ScheduleOverride> => {
  if (!USE_MOCK) return (await apiClient.post('/api/v1/schedules/overrides', input)).data;
  const rows = await readJson('scheduleOverrides');
  const item = { ...input, id: input.id ?? newId('ov') };
  await writeJson('scheduleOverrides', input.id ? rows.map((r) => (r.id === input.id ? item : r)) : [...rows, item]);
  return item;
};
