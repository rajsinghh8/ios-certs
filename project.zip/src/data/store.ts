import { apiClient } from '../api/client';
import { storage } from '../storage';
import { RECENT_ACTIVITY_LIMIT, SIMULATED_LATENCY_MS } from '../constants';
import {
  Activity,
  AppNotification,
  AppSettings,
  Project,
  Session,
  Task,
  TeamMember,
} from '../types';
import {
  mockActivities,
  mockNotifications,
  mockProjects,
  mockSettings,
  mockTasks,
  mockTeamMembers,
  mockUsers,
} from './mockData';

// TODO(USE_MOCK): verify path + response shape against the real
// backend's OpenAPI schema before flipping this to false.
export const USE_MOCK = true;

// ── Storage helpers ─────────────────────────────────────────────

// MOCK: simulates network latency so loading states are visible.
const simulateLatency = (): Promise<void> =>
  new Promise((resolve) => setTimeout(resolve, SIMULATED_LATENCY_MS));

async function readJson<T>(key: string, seed: T): Promise<T> {
  const raw = await storage.getItem(key);
  if (raw === null) {
    await storage.setItem(key, JSON.stringify(seed));
    return seed;
  }
  return JSON.parse(raw) as T;
}

async function writeJson<T>(key: string, value: T): Promise<void> {
  await storage.setItem(key, JSON.stringify(value));
}

const makeId = (prefix: string): string =>
  `${prefix}${Date.now().toString(36)}${Math.floor(Math.random() * 1000).toString(36)}`;

// ── Auth ────────────────────────────────────────────────────────

// MOCK: stands in for POST /api/v1/auth/login returning { token, userId, name, email, role }.
async function localLogin(email: string, password: string): Promise<Session | null> {
  await simulateLatency();
  const match = mockUsers.find(
    (user) => user.email === email.trim().toLowerCase() && user.password === password,
  );
  if (!match) {
    return null;
  }
  return {
    token: `mock-${match.id}`,
    userId: match.id,
    name: match.name,
    email: match.email,
    role: match.role,
  };
}

export async function login(email: string, password: string): Promise<Session | null> {
  const session = USE_MOCK
    ? await localLogin(email, password)
    : (await apiClient.post('/api/v1/auth/login', { email, password })).data;
  if (!session) {
    return null;
  }
  await storage.setItem('auth_token', JSON.stringify(session));
  return session;
}

export async function logout(): Promise<void> {
  if (!USE_MOCK) {
    await apiClient.post('/api/v1/auth/logout');
  }
  await storage.deleteItem('auth_token');
}

export async function getSession(): Promise<Session | null> {
  const raw = await storage.getItem('auth_token');
  return raw ? (JSON.parse(raw) as Session) : null;
}

// ── Projects ────────────────────────────────────────────────────

// MOCK: stands in for GET /api/v1/projects.
async function localGetProjects(): Promise<Project[]> {
  await simulateLatency();
  return readJson<Project[]>('app_projects', mockProjects);
}

// MOCK: stands in for POST /api/v1/projects.
async function localCreateProject(input: Omit<Project, 'id' | 'createdAt'>): Promise<Project> {
  const projects = await readJson<Project[]>('app_projects', mockProjects);
  const created: Project = { ...input, id: makeId('p'), createdAt: new Date().toISOString() };
  await writeJson('app_projects', [created, ...projects]);
  await pushActivity(created.id, `created project ${created.name}`);
  await pushNotification({
    type: 'project',
    message: `${created.name} was created`,
    relatedEntityType: 'project',
    relatedEntityId: created.id,
  });
  return created;
}

// MOCK: stands in for PUT /api/v1/projects/:id.
async function localUpdateProject(id: string, changes: Partial<Project>): Promise<Project> {
  const projects = await readJson<Project[]>('app_projects', mockProjects);
  const updated = projects.map((project) => (project.id === id ? { ...project, ...changes } : project));
  await writeJson('app_projects', updated);
  return updated.find((project) => project.id === id) as Project;
}

export async function getProjects(): Promise<Project[]> {
  if (USE_MOCK) {
    return localGetProjects();
  }
  return (await apiClient.get('/api/v1/projects')).data;
}

export async function createProject(input: Omit<Project, 'id' | 'createdAt'>): Promise<Project> {
  if (USE_MOCK) {
    return localCreateProject(input);
  }
  return (await apiClient.post('/api/v1/projects', input)).data;
}

export async function updateProject(id: string, changes: Partial<Project>): Promise<Project> {
  if (USE_MOCK) {
    return localUpdateProject(id, changes);
  }
  return (await apiClient.put(`/api/v1/projects/${id}`, changes)).data;
}

// ── Tasks ───────────────────────────────────────────────────────

// MOCK: stands in for GET /api/v1/tasks.
async function localGetTasks(): Promise<Task[]> {
  await simulateLatency();
  return readJson<Task[]>('app_tasks', mockTasks);
}

// MOCK: stands in for POST /api/v1/projects/:id/tasks.
async function localCreateTask(input: Omit<Task, 'id' | 'createdAt'>): Promise<Task> {
  const tasks = await readJson<Task[]>('app_tasks', mockTasks);
  const created: Task = { ...input, id: makeId('t'), createdAt: new Date().toISOString() };
  await writeJson('app_tasks', [created, ...tasks]);
  await pushActivity(created.projectId, `created "${created.title}"`);
  await pushNotification({
    type: 'task',
    message: `New task "${created.title}" was created`,
    relatedEntityType: 'task',
    relatedEntityId: created.id,
  });
  return created;
}

// MOCK: stands in for PUT /api/v1/tasks/:id.
async function localUpdateTask(id: string, changes: Partial<Task>): Promise<Task> {
  const tasks = await readJson<Task[]>('app_tasks', mockTasks);
  const previous = tasks.find((task) => task.id === id);
  const updatedTasks = tasks.map((task) => (task.id === id ? { ...task, ...changes } : task));
  await writeJson('app_tasks', updatedTasks);
  const updated = updatedTasks.find((task) => task.id === id) as Task;
  if (previous && changes.status && changes.status !== previous.status) {
    await pushActivity(updated.projectId, `moved "${updated.title}" to ${updated.status}`);
    await pushNotification({
      type: 'task',
      message: `"${updated.title}" moved to ${updated.status}`,
      relatedEntityType: 'task',
      relatedEntityId: updated.id,
    });
  }
  return updated;
}

// MOCK: stands in for DELETE /api/v1/tasks/:id.
async function localDeleteTask(id: string): Promise<void> {
  const tasks = await readJson<Task[]>('app_tasks', mockTasks);
  await writeJson(
    'app_tasks',
    tasks.filter((task) => task.id !== id),
  );
}

export async function getTasks(): Promise<Task[]> {
  if (USE_MOCK) {
    return localGetTasks();
  }
  return (await apiClient.get('/api/v1/tasks')).data;
}

export async function createTask(input: Omit<Task, 'id' | 'createdAt'>): Promise<Task> {
  if (USE_MOCK) {
    return localCreateTask(input);
  }
  return (await apiClient.post(`/api/v1/projects/${input.projectId}/tasks`, input)).data;
}

export async function updateTask(id: string, changes: Partial<Task>): Promise<Task> {
  if (USE_MOCK) {
    return localUpdateTask(id, changes);
  }
  return (await apiClient.put(`/api/v1/tasks/${id}`, changes)).data;
}

export async function deleteTask(id: string): Promise<void> {
  if (USE_MOCK) {
    return localDeleteTask(id);
  }
  await apiClient.delete(`/api/v1/tasks/${id}`);
}

// ── Team members ────────────────────────────────────────────────

// MOCK: stands in for GET /api/v1/team-members.
async function localGetTeamMembers(): Promise<TeamMember[]> {
  await simulateLatency();
  return readJson<TeamMember[]>('app_team', mockTeamMembers);
}

// MOCK: stands in for POST /api/v1/team-members.
async function localAddTeamMember(input: Omit<TeamMember, 'id'>): Promise<TeamMember> {
  const members = await readJson<TeamMember[]>('app_team', mockTeamMembers);
  const created: TeamMember = { ...input, id: makeId('m') };
  await writeJson('app_team', [...members, created]);
  return created;
}

// MOCK: stands in for DELETE /api/v1/team-members/:id.
async function localRemoveTeamMember(id: string): Promise<void> {
  const members = await readJson<TeamMember[]>('app_team', mockTeamMembers);
  await writeJson(
    'app_team',
    members.filter((member) => member.id !== id),
  );
  const tasks = await readJson<Task[]>('app_tasks', mockTasks);
  await writeJson(
    'app_tasks',
    tasks.map((task) => (task.assigneeId === id ? { ...task, assigneeId: null } : task)),
  );
}

export async function getTeamMembers(): Promise<TeamMember[]> {
  if (USE_MOCK) {
    return localGetTeamMembers();
  }
  return (await apiClient.get('/api/v1/team-members')).data;
}

export async function addTeamMember(input: Omit<TeamMember, 'id'>): Promise<TeamMember> {
  if (USE_MOCK) {
    return localAddTeamMember(input);
  }
  return (await apiClient.post('/api/v1/team-members', input)).data;
}

export async function removeTeamMember(id: string): Promise<void> {
  if (USE_MOCK) {
    return localRemoveTeamMember(id);
  }
  await apiClient.delete(`/api/v1/team-members/${id}`);
}

// ── Notifications ───────────────────────────────────────────────

// MOCK: stands in for GET /api/v1/notifications.
async function localGetNotifications(): Promise<AppNotification[]> {
  await simulateLatency();
  const items = await readJson<AppNotification[]>('app_notifications', mockNotifications);
  return [...items].sort((first, second) => second.createdAt.localeCompare(first.createdAt));
}

// MOCK: stands in for PUT /api/v1/notifications/:id/read (and a bulk mark-all variant).
async function localMarkNotificationsRead(ids: string[] | 'all'): Promise<void> {
  const items = await readJson<AppNotification[]>('app_notifications', mockNotifications);
  await writeJson(
    'app_notifications',
    items.map((item) =>
      ids === 'all' || ids.includes(item.id) ? { ...item, isRead: true } : item,
    ),
  );
}

// MOCK: stands in for DELETE /api/v1/notifications/:id.
async function localDeleteNotification(id: string): Promise<void> {
  const items = await readJson<AppNotification[]>('app_notifications', mockNotifications);
  await writeJson(
    'app_notifications',
    items.filter((item) => item.id !== id),
  );
}

export async function getNotifications(): Promise<AppNotification[]> {
  if (USE_MOCK) {
    return localGetNotifications();
  }
  return (await apiClient.get('/api/v1/notifications')).data;
}

export async function markNotificationsRead(ids: string[] | 'all'): Promise<void> {
  if (USE_MOCK) {
    return localMarkNotificationsRead(ids);
  }
  if (ids === 'all') {
    await apiClient.put('/api/v1/notifications/read-all');
    return;
  }
  await Promise.all(ids.map((id) => apiClient.put(`/api/v1/notifications/${id}/read`)));
}

export async function deleteNotification(id: string): Promise<void> {
  if (USE_MOCK) {
    return localDeleteNotification(id);
  }
  await apiClient.delete(`/api/v1/notifications/${id}`);
}

async function pushNotification(
  input: Pick<AppNotification, 'type' | 'message' | 'relatedEntityType' | 'relatedEntityId'>,
): Promise<void> {
  const items = await readJson<AppNotification[]>('app_notifications', mockNotifications);
  const created: AppNotification = {
    ...input,
    id: makeId('n'),
    isRead: false,
    createdAt: new Date().toISOString(),
  };
  await writeJson('app_notifications', [created, ...items]);
}

// ── Activity feed ───────────────────────────────────────────────

async function pushActivity(projectId: string, description: string): Promise<void> {
  const items = await readJson<Activity[]>('app_activities', mockActivities);
  const session = await getSession();
  const created: Activity = {
    id: makeId('a'),
    projectId,
    userName: session?.name ?? 'Someone',
    description,
    timestamp: new Date().toISOString(),
  };
  await writeJson('app_activities', [created, ...items]);
}

// MOCK: stands in for GET /api/v1/dashboard/recent-activity (last 10, newest first).
async function localGetActivities(): Promise<Activity[]> {
  await simulateLatency();
  const items = await readJson<Activity[]>('app_activities', mockActivities);
  return [...items]
    .sort((first, second) => second.timestamp.localeCompare(first.timestamp))
    .slice(0, RECENT_ACTIVITY_LIMIT);
}

export async function getActivities(): Promise<Activity[]> {
  if (USE_MOCK) {
    return localGetActivities();
  }
  return (await apiClient.get('/api/v1/dashboard/recent-activity')).data;
}

// ── Settings ────────────────────────────────────────────────────

// MOCK: stands in for GET /api/v1/settings.
async function localGetSettings(): Promise<AppSettings> {
  return readJson<AppSettings>('app_settings', mockSettings);
}

// MOCK: stands in for PUT /api/v1/settings.
async function localUpdateSettings(changes: Partial<AppSettings>): Promise<AppSettings> {
  const current = await readJson<AppSettings>('app_settings', mockSettings);
  const updated = { ...current, ...changes };
  await writeJson('app_settings', updated);
  return updated;
}

export async function getSettings(): Promise<AppSettings> {
  if (USE_MOCK) {
    return localGetSettings();
  }
  return (await apiClient.get('/api/v1/settings')).data;
}

export async function updateSettings(changes: Partial<AppSettings>): Promise<AppSettings> {
  if (USE_MOCK) {
    return localUpdateSettings(changes);
  }
  return (await apiClient.put('/api/v1/settings', changes)).data;
}
