import { TaskItem } from '../types';
import { mockTasks } from './mockData';
import { storage } from '../utils/storage';
import { apiClient } from '../api/client';

export const USE_MOCK = true;
const TASKS_KEY = 'test_tasks';

async function readJson<T>(key: string, fallback: T): Promise<T> {
  const raw = await storage.getItem(key);
  if (!raw) return fallback;
  return JSON.parse(raw) as T;
}

async function writeJson<T>(key: string, value: T): Promise<void> {
  await storage.setItem(key, JSON.stringify(value));
}

async function localGetTasks(): Promise<TaskItem[]> {
  const saved = await readJson<TaskItem[] | null>(TASKS_KEY, null);
  if (saved) return saved;
  await writeJson(TASKS_KEY, mockTasks);
  return mockTasks;
}

async function localCreateTask(input: Omit<TaskItem, 'id' | 'createdAt'>): Promise<TaskItem> {
  const tasks = await localGetTasks();
  const created: TaskItem = { ...input, id: `task-${Date.now()}`, createdAt: new Date().toISOString().slice(0, 10) };
  await writeJson(TASKS_KEY, [created, ...tasks]);
  return created;
}

async function localUpdateTask(id: string, changes: Partial<TaskItem>): Promise<TaskItem | null> {
  const tasks = await localGetTasks();
  const updated = tasks.map((task) => (task.id === id ? { ...task, ...changes } : task));
  await writeJson(TASKS_KEY, updated);
  return updated.find((task) => task.id === id) ?? null;
}

async function localDeleteTask(id: string): Promise<void> {
  const tasks = await localGetTasks();
  await writeJson(TASKS_KEY, tasks.filter((task) => task.id !== id));
}

export async function getTasks(): Promise<TaskItem[]> {
  if (USE_MOCK) return localGetTasks();
  const res = await apiClient.get<TaskItem[]>('/api/v1/tasks');
  return res.data;
}

export async function createTask(input: Omit<TaskItem, 'id' | 'createdAt'>): Promise<TaskItem> {
  if (USE_MOCK) return localCreateTask(input);
  const res = await apiClient.post<TaskItem>('/api/v1/tasks', input);
  return res.data;
}

export async function updateTask(id: string, changes: Partial<TaskItem>): Promise<TaskItem | null> {
  if (USE_MOCK) return localUpdateTask(id, changes);
  const res = await apiClient.put<TaskItem>(`/api/v1/tasks/${id}`, changes);
  return res.data;
}

export async function deleteTask(id: string): Promise<void> {
  if (USE_MOCK) return localDeleteTask(id);
  await apiClient.delete<void>(`/api/v1/tasks/${id}`);
}
