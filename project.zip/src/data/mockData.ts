import { ProductivityMetric, TaskItem } from '../types';

const today = new Date();
const isoDate = (offset: number) => {
  const date = new Date(today);
  date.setDate(today.getDate() + offset);
  return date.toISOString().slice(0, 10);
};

export const mockTasks: TaskItem[] = [
  { id: 'task-1', title: 'Plan weekly focus', description: 'Pick the three outcomes that matter most and block focus time.', category: 'Planning', dueDate: isoDate(0), priority: 'high', status: 'inProgress', createdAt: isoDate(-3) },
  { id: 'task-2', title: 'Review project notes', description: 'Summarize recent decisions and turn loose notes into next actions.', category: 'Work', dueDate: isoDate(0), priority: 'medium', status: 'todo', createdAt: isoDate(-2) },
  { id: 'task-3', title: 'Send status update', description: 'Share progress, risks, and blockers with the team before lunch.', category: 'Communication', dueDate: isoDate(1), priority: 'high', status: 'todo', createdAt: isoDate(-1) },
  { id: 'task-4', title: 'Clean task backlog', description: 'Archive stale items and label tasks that are still actionable.', category: 'Admin', dueDate: isoDate(2), priority: 'low', status: 'todo', createdAt: isoDate(-6) },
  { id: 'task-5', title: 'Prepare demo checklist', description: 'Confirm demo data, device setup, and backup talking points.', category: 'Launch', dueDate: isoDate(3), priority: 'medium', status: 'inProgress', createdAt: isoDate(-4) },
  { id: 'task-6', title: 'Reflect on wins', description: 'Capture completed work and lessons for the weekly review.', category: 'Personal', dueDate: isoDate(-1), priority: 'low', status: 'done', createdAt: isoDate(-7) },
  { id: 'task-7', title: 'Draft feature brief', description: 'Write a one-page brief with user value, constraints, and scope.', category: 'Product', dueDate: isoDate(4), priority: 'high', status: 'todo', createdAt: isoDate(-1) },
  { id: 'task-8', title: 'Triage inbox', description: 'Process unread mail into reply, delegate, schedule, or archive.', category: 'Admin', dueDate: isoDate(0), priority: 'medium', status: 'done', createdAt: isoDate(-2) },
  { id: 'task-9', title: 'Update learning list', description: 'Prioritize two articles and one course section for the weekend.', category: 'Growth', dueDate: isoDate(5), priority: 'low', status: 'todo', createdAt: isoDate(-5) },
  { id: 'task-10', title: 'Schedule deep work', description: 'Reserve uninterrupted calendar slots for important creative work.', category: 'Planning', dueDate: isoDate(1), priority: 'medium', status: 'inProgress', createdAt: isoDate(-3) },
];

export const productivityMetrics: ProductivityMetric[] = [
  { id: 'metric-1', label: 'Completion rate', value: '68%', trend: '+12% this week', tone: 'success', icon: 'trending-up-outline' },
  { id: 'metric-2', label: 'Focus sessions', value: '9', trend: '3 more than last week', tone: 'primary', icon: 'timer-outline' },
  { id: 'metric-3', label: 'High priority', value: '3', trend: 'Needs attention', tone: 'warning', icon: 'flame-outline' },
  { id: 'metric-4', label: 'Tasks due today', value: '3', trend: 'Updated live', tone: 'info', icon: 'today-outline' },
];
