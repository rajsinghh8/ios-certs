import { AppNotification, Project, Task, TeamMember } from '../types';

export const teamMembers: TeamMember[] = [
  { id: 'm1', name: 'Maya Chen', role: 'Product Designer', initials: 'MC', color: '#7C3AED' },
  { id: 'm2', name: 'Noah Wilson', role: 'Engineering Lead', initials: 'NW', color: '#0891B2' },
  { id: 'm3', name: 'Ava Patel', role: 'Mobile Engineer', initials: 'AP', color: '#DB2777' },
  { id: 'm4', name: 'Leo Martin', role: 'QA Engineer', initials: 'LM', color: '#D97706' },
];

export const projects: Project[] = [
  { id: 'p1', name: 'Mobile experience', description: 'A refined mobile workflow for the next release.', status: 'Active', progress: 72, dueDate: 'Jun 28', memberIds: ['m1', 'm2', 'm3'] },
  { id: 'p2', name: 'Analytics workspace', description: 'Team reporting and decision-ready dashboards.', status: 'Planning', progress: 32, dueDate: 'Jul 12', memberIds: ['m1', 'm2'] },
  { id: 'p3', name: 'Platform migration', description: 'Modernize the shared project platform.', status: 'At risk', progress: 48, dueDate: 'Jun 20', memberIds: ['m2', 'm3', 'm4'] },
  { id: 'p4', name: 'Design system', description: 'Reusable components and visual guidelines.', status: 'Complete', progress: 100, dueDate: 'May 30', memberIds: ['m1', 'm3'] },
];

export const tasks: Task[] = [
  { id: 't1', projectId: 'p1', title: 'Polish onboarding flow', description: 'Review edge cases and handoff details.', status: 'In progress', priority: 'High', assigneeId: 'm1', dueDate: 'Jun 18' },
  { id: 't2', projectId: 'p1', title: 'Implement dashboard cards', description: 'Build responsive KPI and progress cards.', status: 'To do', priority: 'Medium', assigneeId: 'm3', dueDate: 'Jun 21' },
  { id: 't3', projectId: 'p2', title: 'Define reporting events', description: 'Document analytics event properties.', status: 'Done', priority: 'Low', assigneeId: 'm2', dueDate: 'Jun 14' },
  { id: 't4', projectId: 'p3', title: 'Validate migration plan', description: 'Confirm the production cutover checklist.', status: 'In progress', priority: 'High', assigneeId: 'm4', dueDate: 'Jun 19' },
  { id: 't5', projectId: 'p1', title: 'Run accessibility pass', description: 'Test contrast and keyboard navigation.', status: 'To do', priority: 'Medium', assigneeId: 'm4', dueDate: 'Jun 24' },
];

export const notifications: AppNotification[] = [
  { id: 'n1', title: 'Task assigned to you', detail: 'Polish onboarding flow needs your review.', kind: 'task', referenceId: 't1', isRead: false, createdAt: '10m ago' },
  { id: 'n2', title: 'Project progress updated', detail: 'Mobile experience is now 72% complete.', kind: 'project', referenceId: 'p1', isRead: false, createdAt: '2h ago' },
  { id: 'n3', title: 'Task completed', detail: 'Define reporting events was marked done.', kind: 'task', referenceId: 't3', isRead: true, createdAt: 'Yesterday' },
];
