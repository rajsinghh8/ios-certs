// MOCK DATA — placeholder records for local development only.
// Replace with real API data before production use.
import {
  Activity,
  AppNotification,
  AppSettings,
  Project,
  Task,
  TeamMember,
  User,
} from '../types';

const DAY_MS = 24 * 60 * 60 * 1000;
const HOUR_MS = 60 * 60 * 1000;

// MOCK: dates are generated relative to "now" so seeded data never looks stale.
const daysFromNow = (days: number): string => new Date(Date.now() + days * DAY_MS).toISOString();
const hoursAgo = (hours: number): string => new Date(Date.now() - hours * HOUR_MS).toISOString();

export const mockUsers: User[] = [
  { id: 'u1', name: 'Admin User', email: 'admin@example.com', password: 'password123', role: 'admin' },
  { id: 'u2', name: 'Demo User', email: 'demo@example.com', password: 'password123', role: 'user' },
];

export const mockTeamMembers: TeamMember[] = [
  { id: 'm1', name: 'Olivia Martin', email: 'olivia@example.com', role: 'Product Manager', availability: 'Available' },
  { id: 'm2', name: 'Liam Johnson', email: 'liam@example.com', role: 'iOS Engineer', availability: 'Busy' },
  { id: 'm3', name: 'Emma Williams', email: 'emma@example.com', role: 'Android Engineer', availability: 'Available' },
  { id: 'm4', name: 'Noah Brown', email: 'noah@example.com', role: 'Designer', availability: 'Away' },
  { id: 'm5', name: 'Ava Davis', email: 'ava@example.com', role: 'QA Engineer', availability: 'Available' },
  { id: 'm6', name: 'Lucas Garcia', email: 'lucas@example.com', role: 'Backend Engineer', availability: 'Busy' },
];

export const mockProjects: Project[] = [
  {
    id: 'p1',
    name: 'Mobile App Redesign',
    description: 'Refresh the customer mobile app with a new navigation model and visual language.',
    status: 'Active',
    ownerId: 'u1',
    memberIds: ['m1', 'm2', 'm3', 'm4'],
    startDate: daysFromNow(-30),
    endDate: daysFromNow(45),
    createdAt: daysFromNow(-31),
  },
  {
    id: 'p2',
    name: 'API Platform v2',
    description: 'Migrate public endpoints to the new gateway and add rate limiting.',
    status: 'Active',
    ownerId: 'u1',
    memberIds: ['m1', 'm6', 'm5'],
    startDate: daysFromNow(-60),
    endDate: daysFromNow(20),
    createdAt: daysFromNow(-62),
  },
  {
    id: 'p3',
    name: 'Marketing Website',
    description: 'Launch the new marketing site with localized landing pages.',
    status: 'Planning',
    ownerId: 'u2',
    memberIds: ['m1', 'm4'],
    startDate: daysFromNow(5),
    endDate: daysFromNow(90),
    createdAt: daysFromNow(-3),
  },
  {
    id: 'p4',
    name: 'Analytics Dashboard',
    description: 'Internal analytics for sales and support teams. Currently paused for budget review.',
    status: 'On Hold',
    ownerId: 'u2',
    memberIds: ['m2', 'm5', 'm6'],
    startDate: daysFromNow(-90),
    endDate: daysFromNow(10),
    createdAt: daysFromNow(-95),
  },
];

export const mockTasks: Task[] = [
  { id: 't1', projectId: 'p1', title: 'Design onboarding flow', description: 'Create wireframes and hi-fi screens for the 3-step onboarding.', status: 'Done', priority: 'High', assigneeId: 'm4', dueDate: daysFromNow(-10), createdAt: daysFromNow(-28) },
  { id: 't2', projectId: 'p1', title: 'Implement tab navigation', description: 'Bottom tabs with nested stacks for iOS and Android.', status: 'In Progress', priority: 'High', assigneeId: 'm2', dueDate: daysFromNow(3), createdAt: daysFromNow(-20) },
  { id: 't3', projectId: 'p1', title: 'Accessibility audit', description: 'Check contrast, touch targets and screen reader labels.', status: 'To Do', priority: 'Medium', assigneeId: 'm5', dueDate: daysFromNow(14), createdAt: daysFromNow(-15) },
  { id: 't4', projectId: 'p1', title: 'Android back-button handling', description: 'Ensure hardware back behaves correctly in modal flows.', status: 'In Progress', priority: 'Medium', assigneeId: 'm3', dueDate: daysFromNow(6), createdAt: daysFromNow(-12) },
  { id: 't5', projectId: 'p1', title: 'Update app store screenshots', description: 'Refresh listing assets once the redesign ships.', status: 'To Do', priority: 'Low', assigneeId: 'm4', dueDate: daysFromNow(40), createdAt: daysFromNow(-8) },
  { id: 't6', projectId: 'p2', title: 'Set up API gateway', description: 'Provision gateway and route legacy traffic.', status: 'Done', priority: 'High', assigneeId: 'm6', dueDate: daysFromNow(-20), createdAt: daysFromNow(-55) },
  { id: 't7', projectId: 'p2', title: 'Add rate limiting', description: 'Token bucket limits per API key.', status: 'In Progress', priority: 'High', assigneeId: 'm6', dueDate: daysFromNow(2), createdAt: daysFromNow(-25) },
  { id: 't8', projectId: 'p2', title: 'Write migration guide', description: 'Document breaking changes for partners.', status: 'To Do', priority: 'Medium', assigneeId: 'm1', dueDate: daysFromNow(9), createdAt: daysFromNow(-18) },
  { id: 't9', projectId: 'p2', title: 'Load test v2 endpoints', description: 'Run 10k rps soak test against staging.', status: 'To Do', priority: 'High', assigneeId: 'm5', dueDate: daysFromNow(-2), createdAt: daysFromNow(-14) },
  { id: 't10', projectId: 'p3', title: 'Define site map', description: 'Agree on page hierarchy and URL structure.', status: 'In Progress', priority: 'Medium', assigneeId: 'm1', dueDate: daysFromNow(7), createdAt: daysFromNow(-2) },
  { id: 't11', projectId: 'p3', title: 'Design hero section', description: 'Explore three hero variants for A/B testing.', status: 'To Do', priority: 'Low', assigneeId: 'm4', dueDate: daysFromNow(20), createdAt: daysFromNow(-2) },
  { id: 't12', projectId: 'p4', title: 'Build revenue chart', description: 'Monthly revenue with drill-down by region.', status: 'Done', priority: 'Medium', assigneeId: 'm2', dueDate: daysFromNow(-40), createdAt: daysFromNow(-80) },
  { id: 't13', projectId: 'p4', title: 'Connect support data source', description: 'Sync ticket data nightly.', status: 'To Do', priority: 'High', assigneeId: 'm6', dueDate: daysFromNow(12), createdAt: daysFromNow(-30) },
  { id: 't14', projectId: 'p4', title: 'QA export to CSV', description: 'Verify exports across locales.', status: 'To Do', priority: 'Low', assigneeId: 'm5', dueDate: daysFromNow(25), createdAt: daysFromNow(-22) },
];

export const mockNotifications: AppNotification[] = [
  { id: 'n1', type: 'task', message: 'Liam Johnson moved "Implement tab navigation" to In Progress', relatedEntityType: 'task', relatedEntityId: 't2', isRead: false, createdAt: hoursAgo(1) },
  { id: 'n2', type: 'task', message: 'You were assigned "Load test v2 endpoints"', relatedEntityType: 'task', relatedEntityId: 't9', isRead: false, createdAt: hoursAgo(3) },
  { id: 'n3', type: 'project', message: 'Marketing Website was created', relatedEntityType: 'project', relatedEntityId: 'p3', isRead: false, createdAt: hoursAgo(20) },
  { id: 'n4', type: 'team', message: 'Ava Davis joined API Platform v2', relatedEntityType: 'project', relatedEntityId: 'p2', isRead: true, createdAt: hoursAgo(30) },
  { id: 'n5', type: 'task', message: 'Noah Brown completed "Design onboarding flow"', relatedEntityType: 'task', relatedEntityId: 't1', isRead: true, createdAt: hoursAgo(50) },
  { id: 'n6', type: 'project', message: 'Analytics Dashboard was put On Hold', relatedEntityType: 'project', relatedEntityId: 'p4', isRead: true, createdAt: hoursAgo(72) },
  { id: 'n7', type: 'task', message: '"Load test v2 endpoints" is overdue', relatedEntityType: 'task', relatedEntityId: 't9', isRead: false, createdAt: hoursAgo(5) },
];

export const mockActivities: Activity[] = [
  { id: 'a1', projectId: 'p1', userName: 'Liam Johnson', description: 'started "Implement tab navigation"', timestamp: hoursAgo(1) },
  { id: 'a2', projectId: 'p2', userName: 'Olivia Martin', description: 'assigned "Load test v2 endpoints" to Ava Davis', timestamp: hoursAgo(3) },
  { id: 'a3', projectId: 'p3', userName: 'Demo User', description: 'created project Marketing Website', timestamp: hoursAgo(20) },
  { id: 'a4', projectId: 'p2', userName: 'Lucas Garcia', description: 'added Ava Davis to the team', timestamp: hoursAgo(30) },
  { id: 'a5', projectId: 'p1', userName: 'Noah Brown', description: 'completed "Design onboarding flow"', timestamp: hoursAgo(50) },
  { id: 'a6', projectId: 'p4', userName: 'Demo User', description: 'set project status to On Hold', timestamp: hoursAgo(72) },
  { id: 'a7', projectId: 'p1', userName: 'Emma Williams', description: 'commented on "Android back-button handling"', timestamp: hoursAgo(80) },
  { id: 'a8', projectId: 'p2', userName: 'Lucas Garcia', description: 'completed "Set up API gateway"', timestamp: hoursAgo(120) },
  { id: 'a9', projectId: 'p4', userName: 'Liam Johnson', description: 'completed "Build revenue chart"', timestamp: hoursAgo(150) },
  { id: 'a10', projectId: 'p1', userName: 'Olivia Martin', description: 'created project Mobile App Redesign', timestamp: hoursAgo(200) },
  { id: 'a11', projectId: 'p3', userName: 'Noah Brown', description: 'created "Design hero section"', timestamp: hoursAgo(220) },
];

export const mockSettings: AppSettings = {
  pushNotifications: true,
  emailDigest: false,
  taskReminders: true,
  compactLists: false,
};
