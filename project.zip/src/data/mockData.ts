import { Appointment, Location, ScheduleOverride, Service, StaffMember, User, WaitlistEntry, WeeklySchedule } from '../types';

export const demoUsers: User[] = [
  { id: 'u1', name: 'Operator', email: 'operator@example.com', password: 'password123', role: 'operator' },
];

export const locations: Location[] = [
  { id: 'loc1', name: 'Downtown Studio', city: 'Chicago', timezone: 'America/Chicago', address: '120 Market Street' },
  { id: 'loc2', name: 'Westside Clinic', city: 'Los Angeles', timezone: 'America/Los_Angeles', address: '44 Sunset Avenue' },
  { id: 'loc3', name: 'North Spa', city: 'New York', timezone: 'America/New_York', address: '88 Madison Lane' },
];

export const staff: StaffMember[] = [
  { id: 'st1', name: 'Avery Brooks', locationId: 'loc1', serviceIds: ['svc1', 'svc2', 'svc4'], color: '#0F766E' },
  { id: 'st2', name: 'Mia Chen', locationId: 'loc1', serviceIds: ['svc2', 'svc3'], color: '#2563EB' },
  { id: 'st3', name: 'Noah Rivera', locationId: 'loc2', serviceIds: ['svc1', 'svc3', 'svc5'], color: '#F97316' },
  { id: 'st4', name: 'Sofia Patel', locationId: 'loc2', serviceIds: ['svc2', 'svc4', 'svc5'], color: '#16A34A' },
  { id: 'st5', name: 'Eli Johnson', locationId: 'loc3', serviceIds: ['svc1', 'svc4'], color: '#D97706' },
  { id: 'st6', name: 'Harper Stone', locationId: 'loc3', serviceIds: ['svc3', 'svc5'], color: '#DC2626' },
];

export const services: Service[] = [
  { id: 'svc1', name: 'Signature Haircut', durationMinutes: 45, priceCents: 4999, staffIds: ['st1', 'st3', 'st5'] },
  { id: 'svc2', name: 'Deep Tissue Massage', durationMinutes: 60, priceCents: 8999, staffIds: ['st1', 'st2', 'st4'] },
  { id: 'svc3', name: 'Wellness Consultation', durationMinutes: 30, priceCents: 3999, staffIds: ['st2', 'st3', 'st6'] },
  { id: 'svc4', name: 'Color Touch Up', durationMinutes: 90, priceCents: 12999, staffIds: ['st1', 'st4', 'st5'] },
  { id: 'svc5', name: 'Facial Treatment', durationMinutes: 75, priceCents: 10999, staffIds: ['st3', 'st4', 'st6'] },
];

const weekdayBlocks = {
  0: [],
  1: [{ start: '09:00', end: '12:00' }, { start: '13:00', end: '17:00' }],
  2: [{ start: '09:00', end: '12:00' }, { start: '13:00', end: '17:00' }],
  3: [{ start: '10:00', end: '14:00' }, { start: '15:00', end: '18:00' }],
  4: [{ start: '09:00', end: '12:00' }, { start: '13:00', end: '17:00' }],
  5: [{ start: '09:00', end: '15:00' }],
  6: [{ start: '10:00', end: '14:00' }],
};

export const weeklySchedules: WeeklySchedule[] = staff.map((member) => ({
  staffId: member.id,
  blocksByDay: weekdayBlocks,
}));

export const scheduleOverrides: ScheduleOverride[] = [
  { id: 'ov1', staffId: 'st1', date: '2026-08-03', type: 'custom_hours', blocks: [{ start: '09:00', end: '13:00' }], note: 'Leaving early' },
  { id: 'ov2', staffId: 'st3', date: '2026-08-05', type: 'day_off', blocks: [], note: 'Vacation day' },
];

export const appointments: Appointment[] = [
  { id: 'apt1', customerName: 'Grace Lee', customerEmail: 'grace@example.com', locationId: 'loc1', serviceId: 'svc1', staffId: 'st1', date: '2026-08-03', startTime: '09:00', endTime: '09:45', status: 'confirmed', createdAt: '2026-07-01T10:00:00.000Z' },
  { id: 'apt2', customerName: 'Owen Miller', customerEmail: 'owen@example.com', locationId: 'loc1', serviceId: 'svc2', staffId: 'st2', date: '2026-08-03', startTime: '10:00', endTime: '11:00', status: 'confirmed', createdAt: '2026-07-02T10:00:00.000Z' },
  { id: 'apt3', customerName: 'Lina Ross', customerEmail: 'lina@example.com', locationId: 'loc2', serviceId: 'svc5', staffId: 'st4', date: '2026-08-04', startTime: '13:00', endTime: '14:15', status: 'confirmed', createdAt: '2026-07-03T10:00:00.000Z' },
  { id: 'apt4', customerName: 'Ben Carter', customerEmail: 'ben@example.com', locationId: 'loc3', serviceId: 'svc4', staffId: 'st5', date: '2026-07-20', startTime: '09:00', endTime: '10:30', status: 'completed', createdAt: '2026-07-01T10:00:00.000Z' },
  { id: 'apt5', customerName: 'Isla Moore', customerEmail: 'isla@example.com', locationId: 'loc2', serviceId: 'svc3', staffId: 'st3', date: '2026-07-18', startTime: '11:00', endTime: '11:30', status: 'no_show', createdAt: '2026-07-01T10:00:00.000Z' },
  { id: 'apt6', customerName: 'Theo Green', customerEmail: 'theo@example.com', locationId: 'loc1', serviceId: 'svc2', staffId: 'st1', date: '2026-08-06', startTime: '13:00', endTime: '14:00', status: 'confirmed', createdAt: '2026-07-04T10:00:00.000Z' },
  { id: 'apt7', customerName: 'Nora King', customerEmail: 'nora@example.com', locationId: 'loc3', serviceId: 'svc3', staffId: 'st6', date: '2026-08-06', startTime: '15:00', endTime: '15:30', status: 'cancelled', createdAt: '2026-07-04T10:00:00.000Z' },
  { id: 'apt8', customerName: 'Mason Hall', customerEmail: 'mason@example.com', locationId: 'loc2', serviceId: 'svc1', staffId: 'st3', date: '2026-08-07', startTime: '09:00', endTime: '09:45', status: 'confirmed', createdAt: '2026-07-05T10:00:00.000Z' },
];

export const waitlist: WaitlistEntry[] = [
  { id: 'w1', customerName: 'Priya Singh', customerEmail: 'priya@example.com', locationId: 'loc1', serviceId: 'svc2', staffId: 'st1', date: '2026-08-06', notified: false, createdAt: '2026-07-07T10:00:00.000Z' },
  { id: 'w2', customerName: 'Amir Khan', customerEmail: 'amir@example.com', locationId: 'loc2', serviceId: 'svc5', date: '2026-08-04', notified: false, createdAt: '2026-07-08T10:00:00.000Z' },
  { id: 'w3', customerName: 'Zoe Kim', customerEmail: 'zoe@example.com', locationId: 'loc3', serviceId: 'svc4', staffId: 'st5', date: '2026-08-08', notified: true, createdAt: '2026-07-09T10:00:00.000Z' },
];
