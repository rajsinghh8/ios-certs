import { Appointment, Location, ScheduleOverride, Service, StaffMember, User, WaitlistEntry, WeeklyScheduleDay } from '../types';

export const demoUsers: User[] = [
  { id: 'u1', name: 'Operator', email: 'operator@example.com', password: 'password123', role: 'operator' },
];

export const locations: Location[] = [
  { id: 'loc1', name: 'Downtown Studio', city: 'Chicago', timezone: 'America/Chicago', address: '120 Market Street' },
  { id: 'loc2', name: 'Westside Clinic', city: 'Los Angeles', timezone: 'America/Los_Angeles', address: '88 Ocean Avenue' },
  { id: 'loc3', name: 'Uptown Salon', city: 'New York', timezone: 'America/New_York', address: '401 Madison Road' },
];

export const staffMembers: StaffMember[] = [
  { id: 'st1', name: 'Maya Chen', locationId: 'loc1', title: 'Senior Stylist', serviceIds: ['svc1', 'svc2', 'svc4'] },
  { id: 'st2', name: 'Jordan Ellis', locationId: 'loc1', title: 'Massage Therapist', serviceIds: ['svc3', 'svc5'] },
  { id: 'st3', name: 'Sofia Rivera', locationId: 'loc2', title: 'Wellness Specialist', serviceIds: ['svc3', 'svc5', 'svc6'] },
  { id: 'st4', name: 'Noah Brooks', locationId: 'loc2', title: 'Color Expert', serviceIds: ['svc1', 'svc2'] },
  { id: 'st5', name: 'Avery Stone', locationId: 'loc3', title: 'Clinical Aesthetician', serviceIds: ['svc4', 'svc6'] },
  { id: 'st6', name: 'Priya Shah', locationId: 'loc3', title: 'Lead Stylist', serviceIds: ['svc1', 'svc2', 'svc4'] },
];

export const services: Service[] = [
  { id: 'svc1', name: 'Haircut', durationMinutes: 45, priceCents: 4999, staffIds: ['st1', 'st4', 'st6'] },
  { id: 'svc2', name: 'Color Refresh', durationMinutes: 90, priceCents: 12999, staffIds: ['st1', 'st4', 'st6'] },
  { id: 'svc3', name: 'Therapeutic Massage', durationMinutes: 60, priceCents: 8999, staffIds: ['st2', 'st3'] },
  { id: 'svc4', name: 'Facial Treatment', durationMinutes: 50, priceCents: 7999, staffIds: ['st1', 'st5', 'st6'] },
  { id: 'svc5', name: 'Deep Tissue Session', durationMinutes: 75, priceCents: 10999, staffIds: ['st2', 'st3'] },
  { id: 'svc6', name: 'Skin Consultation', durationMinutes: 30, priceCents: 3999, staffIds: ['st3', 'st5'] },
];

const workdays: WeeklyScheduleDay[] = staffMembers.flatMap((staff) => ([1, 2, 3, 4, 5] as const).map((weekday) => ({
  staffId: staff.id,
  weekday,
  blocks: weekday === 3 ? [{ start: '09:00', end: '12:00' }, { start: '13:00', end: '17:00' }] : [{ start: '09:00', end: '17:00' }],
})));

export const weeklySchedules: WeeklyScheduleDay[] = [
  ...workdays,
  { staffId: 'st1', weekday: 6, blocks: [{ start: '10:00', end: '14:00' }] },
  { staffId: 'st3', weekday: 6, blocks: [{ start: '10:00', end: '15:00' }] },
];

export const scheduleOverrides: ScheduleOverride[] = [
  { id: 'ov1', staffId: 'st1', date: '2026-08-03', type: 'customHours', blocks: [{ start: '09:00', end: '13:00' }], note: 'Leaving early' },
  { id: 'ov2', staffId: 'st3', date: '2026-08-04', type: 'dayOff', blocks: [], note: 'Vacation day' },
];

export const appointments: Appointment[] = [
  { id: 'appt1', locationId: 'loc1', serviceId: 'svc1', staffId: 'st1', customerName: 'Emma Carter', customerEmail: 'emma@example.com', date: '2026-08-03', startTime: '09:00', endTime: '09:45', status: 'confirmed', createdAt: '2026-07-20T09:00:00.000Z' },
  { id: 'appt2', locationId: 'loc1', serviceId: 'svc3', staffId: 'st2', customerName: 'Liam Green', customerEmail: 'liam@example.com', date: '2026-08-03', startTime: '10:00', endTime: '11:00', status: 'confirmed', createdAt: '2026-07-20T10:00:00.000Z' },
  { id: 'appt3', locationId: 'loc2', serviceId: 'svc2', staffId: 'st4', customerName: 'Olivia North', customerEmail: 'olivia@example.com', date: '2026-08-04', startTime: '13:00', endTime: '14:30', status: 'confirmed', createdAt: '2026-07-21T11:00:00.000Z' },
  { id: 'appt4', locationId: 'loc3', serviceId: 'svc4', staffId: 'st5', customerName: 'Mason Hall', customerEmail: 'mason@example.com', date: '2026-07-20', startTime: '11:00', endTime: '11:50', status: 'completed', createdAt: '2026-07-10T11:00:00.000Z' },
  { id: 'appt5', locationId: 'loc3', serviceId: 'svc1', staffId: 'st6', customerName: 'Ava Price', customerEmail: 'ava@example.com', date: '2026-07-21', startTime: '14:00', endTime: '14:45', status: 'noShow', createdAt: '2026-07-10T12:00:00.000Z' },
  { id: 'appt6', locationId: 'loc2', serviceId: 'svc6', staffId: 'st3', customerName: 'Ethan Fox', customerEmail: 'ethan@example.com', date: '2026-08-05', startTime: '09:00', endTime: '09:30', status: 'confirmed', createdAt: '2026-07-22T12:00:00.000Z' },
];

export const waitlistEntries: WaitlistEntry[] = [
  { id: 'wl1', locationId: 'loc1', serviceId: 'svc1', staffId: 'st1', customerName: 'Nora Bell', customerEmail: 'nora@example.com', date: '2026-08-03', createdAt: '2026-07-24T08:00:00.000Z', notified: false },
  { id: 'wl2', locationId: 'loc2', serviceId: 'svc3', customerName: 'Henry West', customerEmail: 'henry@example.com', date: '2026-08-04', createdAt: '2026-07-24T09:00:00.000Z', notified: false },
  { id: 'wl3', locationId: 'loc3', serviceId: 'svc4', staffId: 'st5', customerName: 'Mila Young', customerEmail: 'mila@example.com', date: '2026-08-06', createdAt: '2026-07-24T10:00:00.000Z', notified: true },
];
