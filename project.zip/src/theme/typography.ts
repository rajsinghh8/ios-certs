import { TextStyle } from 'react-native';
import { colors } from './colors';

// Inter font families loaded in App.tsx via @expo-google-fonts/inter.
export const fonts = {
  regular: 'Inter-Regular',
  medium: 'Inter-Medium',
  semibold: 'Inter-SemiBold',
  bold: 'Inter-Bold',
} as const;

export const typography = {
  heading1: {
    fontFamily: fonts.bold,
    fontSize: 30,
    lineHeight: 36,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
  },
  heading2: {
    fontFamily: fonts.bold,
    fontSize: 24,
    lineHeight: 29,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
  },
  heading3: {
    fontFamily: fonts.semibold,
    fontSize: 18,
    lineHeight: 22,
    fontWeight: '600',
    letterSpacing: -0.3,
    color: colors.textPrimary,
  },
  body: {
    fontFamily: fonts.regular,
    fontSize: 15,
    lineHeight: 21,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textPrimary,
  },
  bodyStrong: {
    fontFamily: fonts.semibold,
    fontSize: 15,
    lineHeight: 21,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
  },
  caption: {
    fontFamily: fonts.regular,
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textDisabled,
  },
  captionStrong: {
    fontFamily: fonts.semibold,
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  label: {
    fontFamily: fonts.semibold,
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '600',
    letterSpacing: 1.2,
    color: colors.textDisabled,
    textTransform: 'uppercase',
  },
} satisfies Record<string, TextStyle>;
