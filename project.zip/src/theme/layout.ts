import { Platform, ViewStyle } from 'react-native';
import { colors } from './colors';

// Shared screen-root style: fills the viewport and never overflows the web preview frame.
export const screenRoot: ViewStyle = {
  flex: 1,
  backgroundColor: colors.background,
  ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}),
};
