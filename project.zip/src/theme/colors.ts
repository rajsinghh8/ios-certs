export const colors = {
  primary: '#2563EB',
  primaryDark: '#1D4ED8',
  primaryLight: '#DBEAFE',
  accent: '#0891B2',
  background: '#F8FAFC',
  surface: '#FFFFFF',
  card: '#FFFFFF',
  border: '#E2E8F0',
  textPrimary: '#0F172A',
  textSecondary: '#475569',
  textDisabled: '#94A3B8',
  textInverse: '#FFFFFF',
  success: '#16A34A',
  warning: '#D97706',
  error: '#DC2626',
  info: '#0891B2',
  shadowColor: '#000000',
} as const;

export type Colors = typeof colors;
