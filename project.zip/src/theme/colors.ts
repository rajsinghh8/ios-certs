export const colors = {
  primary: '#007AFF',
  primaryDark: '#0A58C9',
  primaryLight: '#E5F1FF',
  accent: '#5856D6',
  background: '#F2F2F7',
  surface: '#FFFFFF',
  card: '#FFFFFF',
  border: '#E5E5EA',
  textPrimary: '#000000',
  textSecondary: '#3C3C43',
  textDisabled: '#8E8E93',
  textInverse: '#FFFFFF',
  success: '#34C759',
  warning: '#FF9500',
  error: '#FF3B30',
  info: '#007AFF',
  shadowColor: '#000000',
} as const;

export type Colors = typeof colors;
