import { Platform, ViewStyle } from 'react-native';
import { colors } from './colors';

export const cardShadow: ViewStyle = Platform.select<ViewStyle>({
  ios: {
    shadowColor: colors.shadowColor,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
  },
  android: { elevation: 4 },
  default: {},
}) as ViewStyle;

export const headerShadow: ViewStyle = Platform.select<ViewStyle>({
  ios: {
    shadowColor: colors.shadowColor,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 3,
  },
  android: { elevation: 4 },
  default: {},
}) as ViewStyle;
