// 4dp base grid helper: s(1) = 4, s(2) = 8, s(4) = 16
export const s = (n: number): number => n * 4;

export const xs = s(1);
export const sm = s(2);
export const md = s(4);
export const lg = s(6);
export const xl = s(8);
export const xxl = s(12);
