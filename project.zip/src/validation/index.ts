import { MIN_PASSWORD_LENGTH } from '../constants';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

export const validateRequired = (value: string, label: string): string =>
  value.trim().length === 0 ? `${label} is required` : '';

export const validateEmail = (value: string): string => {
  if (value.trim().length === 0) {
    return 'Email is required';
  }
  return EMAIL_PATTERN.test(value.trim()) ? '' : 'Enter a valid email address';
};

export const validatePassword = (value: string): string => {
  if (value.length === 0) {
    return 'Password is required';
  }
  return value.length >= MIN_PASSWORD_LENGTH
    ? ''
    : `Password must be at least ${MIN_PASSWORD_LENGTH} characters`;
};

export const validateMinLength = (value: string, label: string, min: number): string =>
  value.trim().length >= min ? '' : `${label} must be at least ${min} characters`;

export const validateDate = (value: string, label: string): string => {
  if (value.trim().length === 0) {
    return `${label} is required`;
  }
  if (!DATE_PATTERN.test(value.trim()) || Number.isNaN(new Date(value.trim()).getTime())) {
    return `${label} must be a valid date (YYYY-MM-DD)`;
  }
  return '';
};
