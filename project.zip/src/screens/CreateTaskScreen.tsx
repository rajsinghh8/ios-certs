import React, { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Toast from 'react-native-toast-message';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { screenRoot } from '../theme/layout';
import { Project, Task, TaskPriority, TaskStatus, TeamMember } from '../types';
import { createTask, getProjects, getTasks, getTeamMembers, updateTask } from '../data/store';
import { TASK_PRIORITIES, TASK_STATUSES } from '../constants';
import { validateDate, validateMinLength } from '../validation';
import { toDateInput } from '../utils/format';
import { HeaderBar } from '../components/HeaderBar';
import { TextField } from '../components/TextField';
import { ChipSelector } from '../components/ChipSelector';
import { PrimaryButton } from '../components/PrimaryButton';
import { ErrorMessage } from '../components/ErrorMessage';
import { LoadingState } from '../components/LoadingState';

interface CreateTaskScreenProps {
  route?: { params?: { projectId?: string; taskId?: string } };
}

const addDays = (days: number): string =>
  new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

export function CreateTaskScreen({ route }: CreateTaskScreenProps) {
  const presetProjectId = route?.params?.projectId;
  const editingId = route?.params?.taskId;
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'CreateTask'>>();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [projects, setProjects] = useState<Project[]>([]);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [existing, setExisting] = useState<Task | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [projectId, setProjectId] = useState<string | null>(presetProjectId ?? null);
  const [status, setStatus] = useState<TaskStatus>('To Do');
  const [priority, setPriority] = useState<TaskPriority>('Medium');
  const [assigneeId, setAssigneeId] = useState<string | null>(null);
  const [dueDate, setDueDate] = useState(addDays(7));

  useEffect(() => {
    const load = async () => {
      try {
        const [projectData, memberData, taskData] = await Promise.all([
          getProjects(),
          getTeamMembers(),
          getTasks(),
        ]);
        setProjects(projectData);
        setMembers(memberData);
        const found = editingId ? taskData.find((item) => item.id === editingId) : undefined;
        if (found) {
          setExisting(found);
          setTitle(found.title);
          setDescription(found.description);
          setProjectId(found.projectId);
          setStatus(found.status);
          setPriority(found.priority);
          setAssigneeId(found.assigneeId);
          setDueDate(toDateInput(found.dueDate));
        } else if (!presetProjectId && projectData.length > 0) {
          setProjectId(projectData[0].id);
        }
      } catch {
        setSubmitError('Could not load form data. Please close and try again.');
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [editingId, presetProjectId]);

  const selectedProject = projects.find((project) => project.id === projectId) ?? null;
  // Business rule: tasks can only be assigned to members already on the project.
  const assignableMembers = members.filter((member) => selectedProject?.memberIds.includes(member.id));

  const titleError = validateMinLength(title, 'Title', 3);
  const projectError = projectId ? '' : 'Choose a project';
  const dueError = validateDate(dueDate, 'Due date');
  const isValid = titleError === '' && projectError === '' && dueError === '';

  const handleProjectSelect = (value: string | null) => {
    setProjectId(value);
    const project = projects.find((item) => item.id === value);
    if (assigneeId && !project?.memberIds.includes(assigneeId)) {
      setAssigneeId(null);
    }
  };

  const handleSave = async () => {
    setHasSubmitted(true);
    if (!isValid || !projectId) {
      return;
    }
    setIsSaving(true);
    setSubmitError('');
    try {
      const values = {
        projectId,
        title: title.trim(),
        description: description.trim(),
        status,
        priority,
        assigneeId,
        dueDate: new Date(dueDate).toISOString(),
      };
      if (existing) {
        await updateTask(existing.id, values);
      } else {
        await createTask(values);
      }
      Toast.show({ type: 'success', text1: existing ? 'Task updated' : 'Task created' });
      navigation.goBack();
    } catch {
      setSubmitError('Could not save the task. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <HeaderBar title={existing ? 'Edit task' : 'New task'} onBack={() => navigation.goBack()} />
      {isLoading ? (
        <LoadingState />
      ) : (
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
        >
          <ScrollView
            contentContainerStyle={styles.content}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {submitError ? <ErrorMessage message={submitError} /> : null}
            <TextField
              label="Title"
              value={title}
              onChangeText={setTitle}
              placeholder="e.g. Write release notes"
              helper="At least 3 characters"
              error={hasSubmitted ? titleError : ''}
            />
            <TextField
              label="Description"
              value={description}
              onChangeText={setDescription}
              placeholder="Add more detail (optional)"
              multiline
            />
            <Text style={styles.label}>Project</Text>
            <View style={styles.group}>
              <ChipSelector
                options={projects.map((project) => project.id)}
                selected={projectId}
                onSelect={handleProjectSelect}
                getLabel={(id) => projects.find((project) => project.id === id)?.name ?? id}
              />
              {hasSubmitted && projectError ? <Text style={styles.error}>{projectError}</Text> : null}
            </View>
            <Text style={styles.label}>Status</Text>
            <View style={styles.group}>
              <ChipSelector
                options={TASK_STATUSES}
                selected={status}
                onSelect={(value) => setStatus(value ?? 'To Do')}
              />
            </View>
            <Text style={styles.label}>Priority</Text>
            <View style={styles.group}>
              <ChipSelector
                options={TASK_PRIORITIES}
                selected={priority}
                onSelect={(value) => setPriority(value ?? 'Medium')}
              />
            </View>
            <Text style={styles.label}>Assignee</Text>
            <View style={styles.group}>
              <ChipSelector
                options={assignableMembers.map((member) => member.id)}
                selected={assigneeId}
                onSelect={setAssigneeId}
                allLabel="Unassigned"
                getLabel={(id) => members.find((member) => member.id === id)?.name ?? id}
              />
            </View>
            <TextField
              label="Due date"
              value={dueDate}
              onChangeText={setDueDate}
              placeholder="YYYY-MM-DD"
              helper="Format: YYYY-MM-DD"
              error={hasSubmitted ? dueError : ''}
            />
            <PrimaryButton
              label={existing ? 'Save changes' : 'Create task'}
              onPress={handleSave}
              loading={isSaving}
              disabled={!isValid}
            />
            <View style={styles.gap} />
            <PrimaryButton label="Cancel" variant="secondary" onPress={() => navigation.goBack()} />
          </ScrollView>
        </KeyboardAvoidingView>
      )}
    </SafeAreaView>
  );
}

export default CreateTaskScreen;

const styles = StyleSheet.create({
  safe: {
    ...screenRoot,
  },
  flex: {
    flex: 1,
  },
  content: {
    padding: s(4),
    paddingBottom: s(12),
  },
  label: {
    ...typography.captionStrong,
    marginBottom: s(1),
  },
  group: {
    marginBottom: s(4),
  },
  error: {
    ...typography.caption,
    color: colors.error,
  },
  gap: {
    height: s(3),
  },
});
