import React, { useCallback, useState } from 'react';
import { Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { RouteProp, useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import HeaderBar from '../components/HeaderBar';
import { Appointment, Location, Service, StaffMember } from '../types';
import { getAppointments, getLocations, getServices, getStaff } from '../data/store';
import { RootStackParamList } from '../navigation';

export default function AppointmentDetailScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'AppointmentDetail'>>();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'AppointmentDetail'>>();
  const [appointment, setAppointment] = useState<Appointment | undefined>();
  const [locations, setLocations] = useState<Location[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);

  useFocusEffect(useCallback(() => {
    let active = true;
    Promise.all([getAppointments(), getLocations(), getServices(), getStaff()]).then(([a, l, svc, st]) => {
      if (active) { setAppointment(a.find((item) => item.id === route.params.id)); setLocations(l); setServices(svc); setStaff(st); }
    });
    return () => { active = false; };
  }, [route.params.id]));

  const service = services.find((item) => item.id === appointment?.serviceId);
  const location = locations.find((item) => item.id === appointment?.locationId);
  const member = staff.find((item) => item.id === appointment?.staffId);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Appointment" subtitle="Confirmed booking details" onBack={() => navigation.goBack()} />
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {appointment ? (
          <View style={styles.card}>
            <Text style={styles.title}>{appointment.customerName}</Text>
            <Text style={styles.row}>Email: {appointment.customerEmail}</Text>
            <Text style={styles.row}>Service: {service?.name ?? 'Service'} • ${(service ? service.priceCents / 100 : 0).toFixed(2)}</Text>
            <Text style={styles.row}>Staff: {member?.name ?? 'Staff'}</Text>
            <Text style={styles.row}>Location: {location?.name ?? 'Location'} ({location?.timezone ?? 'local'})</Text>
            <Text style={styles.row}>Time: {appointment.date} • {appointment.startTime}-{appointment.endTime}</Text>
            <Text style={styles.badge}>Status: {appointment.status.replace('_', ' ')}</Text>
          </View>
        ) : <Text style={styles.empty}>Appointment not found.</Text>}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}) },
  scroll: { flex: 1 },
  content: { padding: s(4) },
  card: { borderRadius: s(3), backgroundColor: colors.card, padding: s(4), ...Platform.select({ ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 6 }, android: { elevation: 4 }, default: {} }) },
  title: { fontFamily: 'Inter-Bold', fontSize: 24, lineHeight: 29, fontWeight: '700', letterSpacing: -0.5, color: colors.textPrimary, marginBottom: s(3) },
  row: { fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', letterSpacing: 0.2, color: colors.textSecondary, marginBottom: s(2) },
  badge: { marginTop: s(3), fontFamily: 'Inter-SemiBold', fontSize: 15, lineHeight: 21, fontWeight: '600', letterSpacing: 0.2, color: colors.primaryDark },
  empty: { fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', letterSpacing: 0.2, color: colors.textSecondary },
});
