import React, { useCallback, useMemo, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useFocusEffect } from '@react-navigation/native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import HeaderBar from '../components/HeaderBar';
import Chip from '../components/Chip';
import PrimaryButton from '../components/PrimaryButton';
import { Appointment, Location, ScheduleOverride, Service, StaffMember, WeeklySchedule } from '../types';
import { createAppointment, getAppointments, getLocations, getOverrides, getSchedules, getServices, getStaff } from '../data/store';

const toMinutes = (time: string) => { const [h, m] = time.split(':').map(Number); return h * 60 + m; };
const toTime = (minutes: number) => `${String(Math.floor(minutes / 60)).padStart(2, '0')}:${String(minutes % 60).padStart(2, '0')}`;
const addDays = (days: number) => { const d = new Date(); d.setDate(d.getDate() + days); return d.toISOString().slice(0, 10); };
const overlaps = (aStart: number, aEnd: number, bStart: number, bEnd: number) => aStart < bEnd && bStart < aEnd;

export default function BookAppointmentScreen() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [schedules, setSchedules] = useState<WeeklySchedule[]>([]);
  const [overrides, setOverrides] = useState<ScheduleOverride[]>([]);
  const [locationId, setLocationId] = useState('');
  const [serviceId, setServiceId] = useState('');
  const [staffId, setStaffId] = useState('any');
  const [date, setDate] = useState(addDays(7));
  const [selectedTime, setSelectedTime] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [message, setMessage] = useState('');

  useFocusEffect(useCallback(() => {
    let active = true;
    Promise.all([getLocations(), getServices(), getStaff(), getAppointments(), getSchedules(), getOverrides()]).then(([l, svc, st, apt, sch, ov]) => {
      if (active) {
        setLocations(l); setServices(svc); setStaff(st); setAppointments(apt); setSchedules(sch); setOverrides(ov);
        setLocationId((prev) => prev || l[0]?.id || ''); setServiceId((prev) => prev || svc[0]?.id || '');
      }
    });
    return () => { active = false; };
  }, []));

  const service = services.find((sItem) => sItem.id === serviceId);
  const location = locations.find((lItem) => lItem.id === locationId);
  const eligibleStaff = staff.filter((member) => member.locationId === locationId && member.serviceIds.includes(serviceId));

  const slots = useMemo(() => {
    if (!service || !location) return [];
    const candidateStaff = staffId === 'any' ? eligibleStaff : eligibleStaff.filter((m) => m.id === staffId);
    const results: { time: string; staffId: string }[] = [];
    const day = new Date(`${date}T12:00:00`).getDay();
    const now = new Date();
    candidateStaff.forEach((member) => {
      const override = overrides.find((o) => o.staffId === member.id && o.date === date);
      const blocks = override ? override.blocks : schedules.find((sItem) => sItem.staffId === member.id)?.blocksByDay[day] ?? [];
      blocks.forEach((block) => {
        for (let start = toMinutes(block.start); start + service.durationMinutes <= toMinutes(block.end); start += 15) {
          const end = start + service.durationMinutes;
          const startDate = new Date(`${date}T${toTime(start)}:00`);
          if (startDate.getTime() < now.getTime()) continue;
          const conflict = appointments.some((apt) => apt.staffId === member.id && apt.date === date && apt.status === 'confirmed' && overlaps(start, end, toMinutes(apt.startTime), toMinutes(apt.endTime)));
          if (!conflict) results.push({ time: toTime(start), staffId: member.id });
        }
      });
    });
    const unique = new Map<string, { time: string; staffId: string }>();
    results.forEach((r) => { if (!unique.has(r.time)) unique.set(r.time, r); });
    return Array.from(unique.values()).sort((a, b) => a.time.localeCompare(b.time));
  }, [appointments, date, eligibleStaff, location, overrides, schedules, service, staffId]);

  const submit = async () => {
    if (!service || !location || !selectedTime || !customerName.trim() || !customerEmail.trim()) {
      setMessage('Choose a complete booking and enter customer details.');
      return;
    }
    const slot = slots.find((item) => item.time === selectedTime);
    if (!slot) {
      setMessage('That time is no longer available.');
      return;
    }
    const startMinutes = toMinutes(selectedTime);
    const endMinutes = startMinutes + service.durationMinutes;
    const latestAppointments = await getAppointments();
    const conflict = latestAppointments.some((apt) => apt.staffId === slot.staffId && apt.date === date && apt.status === 'confirmed' && overlaps(startMinutes, endMinutes, toMinutes(apt.startTime), toMinutes(apt.endTime)));
    if (conflict) {
      setAppointments(latestAppointments);
      setMessage('That time overlaps an existing booking. Back-to-back appointments are allowed, but overlapping appointments are not.');
      return;
    }
    const saved = await createAppointment({ customerName: customerName.trim(), customerEmail: customerEmail.trim(), locationId, serviceId, staffId: slot.staffId, date, startTime: selectedTime, endTime: toTime(endMinutes) });
    setAppointments((prev) => [...prev, saved]);
    setSelectedTime('');
    setMessage(`Confirmed for ${date} at ${saved.startTime}.`);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Browse & book" subtitle="Open times are spaced in 15-minute steps" />
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <Text style={styles.label}>Location</Text><View style={styles.wrap}>{locations.map((item) => <Chip key={item.id} label={`${item.name} (${item.city})`} selected={locationId === item.id} onPress={() => { setLocationId(item.id); setStaffId('any'); setSelectedTime(''); }} />)}</View>
          <Text style={styles.label}>Service</Text><View style={styles.wrap}>{services.map((item) => <Chip key={item.id} label={`${item.name} $${(item.priceCents / 100).toFixed(2)}`} selected={serviceId === item.id} onPress={() => { setServiceId(item.id); setStaffId('any'); setSelectedTime(''); }} />)}</View>
          <Text style={styles.label}>Staff</Text><View style={styles.wrap}><Chip label="Anyone available" selected={staffId === 'any'} onPress={() => { setStaffId('any'); setSelectedTime(''); }} />{eligibleStaff.map((item) => <Chip key={item.id} label={item.name} selected={staffId === item.id} onPress={() => { setStaffId(item.id); setSelectedTime(''); }} />)}</View>
          <Text style={styles.label}>Day</Text><View style={styles.wrap}>{[1, 2, 3, 4, 5, 6, 7].map((d) => { const day = addDays(d); return <Chip key={day} label={day} selected={date === day} onPress={() => { setDate(day); setSelectedTime(''); }} />; })}</View>
          <Text style={styles.label}>Open times {location ? `(${location.timezone})` : ''}</Text><Text style={styles.helper}>Times are offered every 15 minutes, and each appointment must fit without overlapping another booking.</Text><View style={styles.wrap}>{slots.length ? slots.slice(0, 28).map((slot) => <Chip key={`${slot.time}-${slot.staffId}`} label={slot.time} selected={selectedTime === slot.time} onPress={() => setSelectedTime(slot.time)} />) : <Text style={styles.empty}>No open times. Add to waitlist from the Waitlist tab.</Text>}</View>
          <TextInput style={styles.input} value={customerName} onChangeText={setCustomerName} placeholder="Customer name" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} />
          <TextInput style={styles.input} value={customerEmail} onChangeText={setCustomerEmail} placeholder="Customer email" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} />
          {message ? <Text style={message.startsWith('Confirmed') ? styles.success : styles.error}>{message}</Text> : null}
          <PrimaryButton label="Confirm Appointment" onPress={submit} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}) },
  flex: { flex: 1 },
  scroll: { flex: 1 },
  content: { padding: s(4), paddingBottom: s(8) },
  label: { marginTop: s(3), marginBottom: s(2), fontFamily: 'Inter-Bold', fontSize: 16, lineHeight: 19, fontWeight: '700', letterSpacing: -0.5, color: colors.textPrimary },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', minHeight: s(10) },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, backgroundColor: colors.surface, paddingHorizontal: s(3), marginTop: s(3), fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', letterSpacing: 0.2, color: colors.textPrimary },
  helper: { marginBottom: s(2), fontFamily: 'Inter-Regular', fontSize: 13, lineHeight: 18, fontWeight: '400', letterSpacing: 0.2, color: colors.textSecondary },
  empty: { fontFamily: 'Inter-Regular', fontSize: 14, lineHeight: 20, fontWeight: '400', letterSpacing: 0.2, color: colors.textSecondary },
  success: { marginVertical: s(3), fontFamily: 'Inter-SemiBold', fontSize: 14, lineHeight: 20, fontWeight: '600', letterSpacing: 0.2, color: colors.success },
  error: { marginVertical: s(3), fontFamily: 'Inter-Medium', fontSize: 14, lineHeight: 20, fontWeight: '500', letterSpacing: 0.2, color: colors.error },
});
