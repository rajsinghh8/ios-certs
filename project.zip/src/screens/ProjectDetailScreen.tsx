import React, { useCallback, useState } from 'react';
import { FlatList, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { screenRoot } from '../theme/layout';
import { cardShadow } from '../theme/shadows';
import { useRefreshOnFocus } from '../hooks/useRefreshOnFocus';
import { Project, Task, TaskPriority, TaskStatus, TeamMember } from '../types';
import { getProjects, getTasks, getTeamMembers } from '../data/store';
import { TASK_PRIORITIES, TASK_STATUSES } from '../constants';
import { getProjectProgress } from '../utils/progress';
import { formatDate } from '../utils/format';
import { HeaderBar } from '../components/HeaderBar';
import { Badge } from '../components/Badge';
import { ProgressBar } from '../components/ProgressBar';
import { ChipSelector } from '../components/ChipSelector';
import { TaskListItem } from '../components/TaskListItem';
import { Avatar } from '../components/Avatar';
import { EmptyState } from '../components/EmptyState';
import { LoadingState } from '../components/LoadingState';
import { ErrorMessage } from '../components/ErrorMessage';
import { PrimaryButton } from '../components/PrimaryButton';

interface ProjectDetailScreenProps {
  route: { params: { projectId: string } };
}

type DetailTab = 'Tasks' | 'Team';
const DETAIL_TABS: DetailTab[] = ['Tasks', 'Team'];

export function ProjectDetailScreen({ route }: ProjectDetailScreenProps) {
  const { projectId } = route.params;
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'ProjectDetail'>>();
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [project, setProject] = useState<Project | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [activeTab, setActiveTab] = useState<DetailTab>('Tasks');
  const [statusFilter, setStatusFilter] = useState<TaskStatus | null>(null);
  const [priorityFilter, setPriorityFilter] = useState<TaskPriority | null>(null);

  const loadData = useCallback(async () => {
    try {
      const [projectData, taskData, memberData] = await Promise.all([
        getProjects(),
        getTasks(),
        getTeamMembers(),
      ]);
      setProject(projectData.find((item) => item.id === projectId) ?? null);
      setTasks(taskData.filter((task) => task.projectId === projectId));
      setMembers(memberData);
      setErrorMessage('');
    } catch {
      setErrorMessage('Could not load this project. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [projectId]);

  useRefreshOnFocus(loadData);

  const goBack = () => navigation.goBack();

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safe}>
        <HeaderBar title="Project" onBack={goBack} />
        <LoadingState label="Loading project…" />
      </SafeAreaView>
    );
  }

  if (!project) {
    return (
      <SafeAreaView style={styles.safe}>
        <HeaderBar title="Project" onBack={goBack} />
        <EmptyState
          icon="alert-circle-outline"
          title="Project not found"
          message={errorMessage || 'This project may have been removed.'}
          actionLabel="Go back"
          onAction={goBack}
        />
      </SafeAreaView>
    );
  }

  const progressPercent = getProjectProgress(tasks, project.id);
  const projectMembers = members.filter((member) => project.memberIds.includes(member.id));
  const memberName = (memberId: string | null) =>
    members.find((member) => member.id === memberId)?.name ?? 'Unassigned';
  const visibleTasks = tasks
    .filter((task) => statusFilter === null || task.status === statusFilter)
    .filter((task) => priorityFilter === null || task.priority === priorityFilter);

  const header = (
    <View>
      {errorMessage ? <ErrorMessage message={errorMessage} /> : null}
      <View style={styles.infoCard}>
        <Badge label={project.status} />
        <Text style={styles.description}>{project.description}</Text>
        <Text style={styles.dates}>
          {formatDate(project.startDate)} → {formatDate(project.endDate)}
        </Text>
        <View style={styles.progressRow}>
          <View style={styles.progressBar}>
            <ProgressBar percent={progressPercent} />
          </View>
          <Text style={styles.percent}>{progressPercent}%</Text>
        </View>
      </View>

      <View style={styles.tabs}>
        <ChipSelector
          options={DETAIL_TABS}
          selected={activeTab}
          onSelect={(tab) => setActiveTab(tab ?? 'Tasks')}
        />
      </View>

      {activeTab === 'Tasks' ? (
        <View style={styles.filters}>
          <Text style={styles.filterLabel}>Status</Text>
          <ChipSelector
            options={TASK_STATUSES}
            selected={statusFilter}
            onSelect={setStatusFilter}
            allLabel="All"
          />
          <Text style={styles.filterLabel}>Priority</Text>
          <ChipSelector
            options={TASK_PRIORITIES}
            selected={priorityFilter}
            onSelect={setPriorityFilter}
            allLabel="All"
          />
        </View>
      ) : null}
    </View>
  );

  const footer =
    activeTab === 'Team' ? (
      <View>
        {projectMembers.length === 0 ? (
          <EmptyState
            icon="people-outline"
            title="No team members"
            message="Edit the project to add people to this team."
          />
        ) : (
          projectMembers.map((member) => (
            <View key={member.id} style={styles.memberRow}>
              <Avatar name={member.name} size={40} />
              <View style={styles.memberText}>
                <Text style={styles.memberName}>{member.name}</Text>
                <Text style={styles.memberRole}>{member.role}</Text>
              </View>
            </View>
          ))
        )}
      </View>
    ) : null;

  return (
    <SafeAreaView style={styles.safe}>
      <HeaderBar
        title={project.name}
        onBack={goBack}
        rightIcon="create-outline"
        rightLabel="Edit project"
        onRightPress={() => navigation.navigate('CreateProject', { projectId: project.id })}
      />
      <FlatList
        data={activeTab === 'Tasks' ? visibleTasks : []}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={header}
        ListFooterComponent={
          <View>
            {footer}
            {activeTab === 'Tasks' ? (
              <View style={styles.addTask}>
                <PrimaryButton
                  label="Add task"
                  onPress={() => navigation.navigate('CreateTask', { projectId: project.id })}
                />
              </View>
            ) : null}
          </View>
        }
        ListEmptyComponent={
          activeTab === 'Tasks' ? (
            <EmptyState
              icon="checkbox-outline"
              title={tasks.length === 0 ? 'No tasks yet' : 'No matching tasks'}
              message={
                tasks.length === 0
                  ? 'Add the first task to this project.'
                  : 'Try changing the status or priority filter.'
              }
            />
          ) : null
        }
        renderItem={({ item }) => (
          <TaskListItem
            task={item}
            assigneeName={memberName(item.assigneeId)}
            onPress={() => navigation.navigate('TaskDetail', { taskId: item.id })}
          />
        )}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

export default ProjectDetailScreen;

const styles = StyleSheet.create({
  safe: {
    ...screenRoot,
  },
  listContent: {
    padding: s(4),
    paddingBottom: s(12),
  },
  infoCard: {
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    gap: s(3),
    ...cardShadow,
  },
  description: {
    ...typography.body,
    color: colors.textSecondary,
  },
  dates: {
    ...typography.caption,
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  progressBar: {
    flex: 1,
  },
  percent: {
    ...typography.captionStrong,
    marginLeft: s(2),
  },
  tabs: {
    marginTop: s(4),
  },
  filters: {
    marginBottom: s(3),
  },
  filterLabel: {
    ...typography.label,
    marginTop: s(2),
  },
  separator: {
    height: s(3),
  },
  addTask: {
    marginTop: s(5),
  },
  memberRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: s(3),
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  memberText: {
    marginLeft: s(3),
  },
  memberName: {
    ...typography.bodyStrong,
  },
  memberRole: {
    ...typography.caption,
  },
});
