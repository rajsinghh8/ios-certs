import React from 'react';
import { render } from '@testing-library/react-native';
import { NavigationContainer } from '@react-navigation/native';
import { CreateTaskScreen } from './CreateTaskScreen';

test('renders without crashing', () => {
  render(
    <NavigationContainer>
      <CreateTaskScreen />
    </NavigationContainer>,
  );
});
