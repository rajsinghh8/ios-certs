import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { EmptyState } from '../components/EmptyState';
import { FilterChip } from '../components/FilterChip';
import { HeaderBar } from '../components/HeaderBar';
import { TaskCard } from '../components/TaskCard';
import { getTasks, updateTask } from '../data/store';
import { RootStackParamList } from '../navigation';
import { TaskFilter, TaskItem } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

const filters: Array<{ key: TaskFilter; label: string }> = [
  { key: 'all', label: 'All' },
  { key: 'today', label: 'Today' },
  { key: 'inProgress', label: 'In progress' },
  { key: 'done', label: 'Done' },
];

export default function TasksScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<TaskFilter>('all');

  const loadTasks = useCallback(() => {
    let active = true;
    getTasks().then((items) => {
      if (active) setTasks(items);
    });
    return () => {
      active = false;
    };
  }, []);

  useFocusEffect(loadTasks);

  const filteredTasks = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    return tasks
      .filter((task) => {
        const matchesQuery = `${task.title} ${task.description} ${task.category}`.toLowerCase().includes(query.trim().toLowerCase());
        const matchesFilter = filter === 'all' || (filter === 'today' && task.dueDate === today) || task.status === filter;
        return matchesQuery && matchesFilter;
      })
      .sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  }, [filter, query, tasks]);

  const toggleTask = async (task: TaskItem) => {
    const nextStatus = task.status === 'done' ? 'todo' : 'done';
    setTasks((prev) => prev.map((item) => (item.id === task.id ? { ...item, status: nextStatus } : item)));
    await updateTask(task.id, { status: nextStatus });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Tasks" subtitle={`${filteredTasks.length} tasks shown`} rightLabel="Add" onRightPress={() => navigation.navigate('TaskForm', {})} />
      <View style={styles.searchWrap}>
        <Ionicons name="search-outline" size={s(5)} color={colors.textDisabled} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Search tasks"
          placeholderTextColor={colors.textDisabled}
          autoCapitalize="none"
          autoCorrect={false}
          returnKeyType="search"
          underlineColorAndroid="transparent"
          selectionColor={colors.primary}
          style={styles.searchInput}
        />
      </View>
      <View style={styles.filterShell}>
        <ScrollView horizontal directionalLockEnabled decelerationRate="fast" showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>
          {filters.map((item) => (
            <FilterChip key={item.key} label={item.label} selected={filter === item.key} onPress={() => setFilter(item.key)} />
          ))}
        </ScrollView>
      </View>
      <FlatList
        style={styles.list}
        data={filteredTasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <TaskCard task={item} onPress={() => navigation.navigate('TaskDetail', { id: item.id })} onToggle={() => toggleTask(item)} />}
        ItemSeparatorComponent={() => <View style={styles.listSeparator} />}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
        ListEmptyComponent={<EmptyState title="Nothing here" message="Try a different filter or create a focused task." actionLabel="Create task" onAction={() => navigation.navigate('TaskForm', {})} />}
      />
      <Pressable
        onPress={() => navigation.navigate('TaskForm', {})}
        android_ripple={{ color: 'rgba(255,255,255,0.18)', borderless: true }}
        style={({ pressed }) => [styles.fab, pressed && Platform.OS === 'ios' && styles.pressed]}
      >
        <Ionicons name="add" size={s(8)} color={colors.textInverse} />
      </Pressable>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  searchWrap: {
    minHeight: s(12),
    marginHorizontal: s(4),
    borderRadius: s(3),
    paddingHorizontal: s(4),
    backgroundColor: colors.surface,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    flexDirection: 'row',
    alignItems: 'center',
  },
  searchInput: {
    flex: 1,
    minHeight: s(12),
    marginLeft: s(2),
    fontFamily: 'Inter-Regular',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textPrimary,
  },
  filterShell: {
    minHeight: s(13),
  },
  filterRow: {
    paddingHorizontal: s(4),
    paddingVertical: s(3),
  },
  list: {
    flex: 1,
  },
  listContent: {
    paddingHorizontal: s(4),
    paddingBottom: s(24),
    flexGrow: 1,
  },
  listSeparator: {
    height: s(3),
  },
  fab: {
    position: 'absolute',
    right: s(5),
    bottom: s(6),
    width: s(14),
    height: s(14),
    borderRadius: s(7),
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    ...Platform.select({
      ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(2) }, shadowOpacity: 0.18, shadowRadius: s(3) },
      android: { elevation: 8 },
      default: {},
    }),
  },
  pressed: {
    opacity: 0.7,
  },
});
