import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useState } from 'react';
import { Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Chip } from '../components/Chip';
import { HeaderBar } from '../components/HeaderBar';
import { InfoCard } from '../components/InfoCard';
import { PrimaryButton } from '../components/PrimaryButton';
import { TextField } from '../components/TextField';
import { getScheduleOverrides, getStaff, getWeeklySchedules, saveScheduleOverride, saveWeeklySchedules } from '../data/store';
import { ScheduleOverride, StaffMember, Weekday, WeeklyScheduleDay } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

const weekdays: { id: Weekday; label: string }[] = [{ id: 1, label: 'Mon' }, { id: 2, label: 'Tue' }, { id: 3, label: 'Wed' }, { id: 4, label: 'Thu' }, { id: 5, label: 'Fri' }, { id: 6, label: 'Sat' }, { id: 0, label: 'Sun' }];

export default function StaffHoursScreen() {
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [weekly, setWeekly] = useState<WeeklyScheduleDay[]>([]);
  const [overrides, setOverrides] = useState<ScheduleOverride[]>([]);
  const [staffId, setStaffId] = useState('');
  const [weekday, setWeekday] = useState<Weekday>(1);
  const [blocks, setBlocks] = useState('09:00-17:00');
  const [date, setDate] = useState('2026-08-10');
  const [overrideType, setOverrideType] = useState<'dayOff' | 'customHours'>('customHours');
  const [overrideBlocks, setOverrideBlocks] = useState('09:00-13:00');
  const [note, setNote] = useState('');

  useEffect(() => { Promise.all([getStaff(), getWeeklySchedules(), getScheduleOverrides()]).then(([st, w, o]) => { setStaff(st); setWeekly(w); setOverrides(o); setStaffId(st[0]?.id ?? ''); }); }, []);

  const parseBlocks = (value: string) => value.split(',').map((part) => part.trim()).filter(Boolean).map((part) => {
    const [start, end] = part.split('-').map((item) => item.trim());
    return { start, end };
  }).filter((block) => block.start && block.end);

  const saveWeekly = async () => {
    const next = weekly.filter((row) => !(row.staffId === staffId && row.weekday === weekday));
    const row = { staffId, weekday, blocks: parseBlocks(blocks) };
    const saved = await saveWeeklySchedules([...next, row]);
    setWeekly(saved);
    setNote('Weekly hours saved.');
  };

  const saveOverride = async () => {
    const saved = await saveScheduleOverride({ staffId, date, type: overrideType, blocks: overrideType === 'dayOff' ? [] : parseBlocks(overrideBlocks), note: overrideType === 'dayOff' ? 'Full day off' : 'Custom hours' });
    setOverrides((prev) => [saved, ...prev.filter((item) => item.id !== saved.id)]);
    setNote('Date-specific override saved.');
  };

  const selectedStaff = staff.find((item) => item.id === staffId);
  const selectedBlocks = weekly.find((row) => row.staffId === staffId && row.weekday === weekday)?.blocks.map((b) => `${b.start}-${b.end}`).join(', ') ?? 'Closed';

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Staff hours" subtitle="Set weekly blocks and one-day overrides" />
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.section}>Staff member</Text>
        <View style={styles.row}>{staff.map((item) => <Chip key={item.id} label={item.name} selected={staffId === item.id} onPress={() => setStaffId(item.id)} />)}</View>
        <InfoCard title={selectedStaff?.name ?? 'Select staff'} subtitle={`Current selected day: ${selectedBlocks}`} meta="Use comma-separated blocks for split shifts" icon="time-outline" />
        <Text style={styles.section}>Weekly schedule</Text>
        <View style={styles.row}>{weekdays.map((item) => <Chip key={item.id} label={item.label} selected={weekday === item.id} onPress={() => setWeekday(item.id)} />)}</View>
        <TextField label="Working blocks" value={blocks} onChangeText={setBlocks} placeholder="09:00-12:00, 13:00-17:00" />
        <PrimaryButton label="Save weekly hours" onPress={saveWeekly} />
        <Text style={styles.section}>One-day override</Text>
        <TextField label="Date" value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" />
        <View style={styles.row}><Chip label="Custom hours" selected={overrideType === 'customHours'} onPress={() => setOverrideType('customHours')} /><Chip label="Full day off" selected={overrideType === 'dayOff'} onPress={() => setOverrideType('dayOff')} /></View>
        {overrideType === 'customHours' ? <TextField label="Override blocks" value={overrideBlocks} onChangeText={setOverrideBlocks} placeholder="09:00-13:00" /> : null}
        <PrimaryButton label="Save override" onPress={saveOverride} />
        {note ? <Text style={styles.note}>{note}</Text> : null}
        <Text style={styles.section}>Saved overrides</Text>
        {overrides.filter((item) => item.staffId === staffId).map((item) => <View key={item.id} style={styles.override}><Text style={styles.overrideText}>{item.date} · {item.type === 'dayOff' ? 'Day off' : item.blocks.map((b) => `${b.start}-${b.end}`).join(', ')}</Text></View>)}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  scroll: { flex: 1 },
  content: { padding: s(4), paddingBottom: s(8) },
  row: { flexDirection: 'row', flexWrap: 'wrap' },
  section: { fontFamily: 'Inter-Bold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '700', letterSpacing: 0.2, color: colors.textPrimary, marginTop: s(4), marginBottom: s(2) },
  note: { marginTop: s(3), fontFamily: 'Inter-Medium', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '500', letterSpacing: 0.2, color: colors.success },
  override: { padding: s(3), borderRadius: s(2), backgroundColor: colors.surface, borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, marginBottom: s(2) },
  overrideText: { fontFamily: 'Inter-Regular', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '400', letterSpacing: 0.2, color: colors.textPrimary },
});
