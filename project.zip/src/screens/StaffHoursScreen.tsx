import React, { useCallback, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { RouteProp, useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import HeaderBar from '../components/HeaderBar';
import PrimaryButton from '../components/PrimaryButton';
import Chip from '../components/Chip';
import { ScheduleOverride, StaffMember, TimeBlock, WeeklySchedule } from '../types';
import { getOverrides, getSchedules, getStaff, saveOverrides, saveSchedules } from '../data/store';
import { RootStackParamList } from '../navigation';

const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const parseBlocks = (text: string): TimeBlock[] => text.split(',').map((part) => part.trim()).filter(Boolean).map((part) => { const [start, end] = part.split('-'); return { start: start.trim(), end: end.trim() }; });
const blocksText = (blocks: TimeBlock[]) => blocks.map((b) => `${b.start}-${b.end}`).join(', ');

export default function StaffHoursScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'StaffHours'>>();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'StaffHours'>>();
  const [member, setMember] = useState<StaffMember | undefined>();
  const [schedule, setSchedule] = useState<WeeklySchedule | undefined>();
  const [schedules, setSchedules] = useState<WeeklySchedule[]>([]);
  const [overrides, setOverridesState] = useState<ScheduleOverride[]>([]);
  const [selectedDay, setSelectedDay] = useState(1);
  const [blocks, setBlocks] = useState('09:00-12:00, 13:00-17:00');
  const [date, setDate] = useState('2026-08-10');
  const [overrideBlocks, setOverrideBlocks] = useState('09:00-13:00');
  const [message, setMessage] = useState('');

  useFocusEffect(useCallback(() => { let active = true; Promise.all([getStaff(), getSchedules(), getOverrides()]).then(([st, sch, ov]) => { if (!active) return; setMember(st.find((i) => i.id === route.params.staffId)); setSchedules(sch); const current = sch.find((i) => i.staffId === route.params.staffId); setSchedule(current); setBlocks(blocksText(current?.blocksByDay[selectedDay] ?? [])); setOverridesState(ov.filter((i) => i.staffId === route.params.staffId)); }); return () => { active = false; }; }, [route.params.staffId, selectedDay]));

  const saveWeekly = async () => { const current = schedule ?? { staffId: route.params.staffId, blocksByDay: { 0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: [] } }; const nextSchedule = { ...current, blocksByDay: { ...current.blocksByDay, [selectedDay]: parseBlocks(blocks) } }; const next = schedules.some((i) => i.staffId === route.params.staffId) ? schedules.map((i) => i.staffId === route.params.staffId ? nextSchedule : i) : [...schedules, nextSchedule]; setSchedules(next); setSchedule(nextSchedule); await saveSchedules(next); setMessage('Weekly hours saved.'); };
  const addOverride = async (type: 'day_off' | 'custom_hours') => { const all = await getOverrides(); const item: ScheduleOverride = { id: `ov${Date.now()}`, staffId: route.params.staffId, date, type, blocks: type === 'day_off' ? [] : parseBlocks(overrideBlocks), note: type === 'day_off' ? 'Day off' : 'Different hours' }; const next = [...all, item]; await saveOverrides(next); setOverridesState((prev) => [...prev, item]); setMessage('Date override saved.'); };

  return (
    <SafeAreaView style={styles.safe}><StatusBar style="dark" /><HeaderBar title="Staff hours" subtitle={member?.name} onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <View style={styles.form}><Text style={styles.label}>Weekly day</Text><View style={styles.wrap}>{dayNames.map((name, index) => <Chip key={name} label={name} selected={selectedDay === index} onPress={() => { setSelectedDay(index); setBlocks(blocksText(schedule?.blocksByDay[index] ?? [])); }} />)}</View>
        <TextInput style={styles.input} value={blocks} onChangeText={setBlocks} placeholder="09:00-12:00, 13:00-17:00" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} /><PrimaryButton label="Save Weekly Blocks" onPress={saveWeekly} />
        <Text style={styles.label}>Date override</Text><TextInput style={styles.input} value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} /><TextInput style={styles.input} value={overrideBlocks} onChangeText={setOverrideBlocks} placeholder="09:00-13:00" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} />
        <View style={styles.actions}><PrimaryButton label="Mark Day Off" onPress={() => addOverride('day_off')} variant="secondary" style={styles.actionButton} /><PrimaryButton label="Save Custom" onPress={() => addOverride('custom_hours')} style={styles.actionButton} /></View>{message ? <Text style={styles.success}>{message}</Text> : null}</View>
        <FlatList style={styles.list} contentContainerStyle={styles.listContent} data={overrides} keyExtractor={(item) => item.id} renderItem={({ item }) => <Text style={styles.override}>{item.date}: {item.type === 'day_off' ? 'Day off' : blocksText(item.blocks)}</Text>} ItemSeparatorComponent={() => <View style={styles.separator} />} showsVerticalScrollIndicator={false} removeClippedSubviews={Platform.OS === 'android'} initialNumToRender={10} maxToRenderPerBatch={10} windowSize={5} />
      </KeyboardAvoidingView></SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}) },
  flex: { flex: 1 },
  form: { padding: s(4), backgroundColor: colors.surface },
  label: { marginTop: s(2), marginBottom: s(2), fontFamily: 'Inter-Bold', fontSize: 16, lineHeight: 19, fontWeight: '700', letterSpacing: -0.5, color: colors.textPrimary },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', minHeight: s(10) },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, backgroundColor: colors.surface, paddingHorizontal: s(3), marginBottom: s(3), fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', letterSpacing: 0.2, color: colors.textPrimary },
  actions: { flexDirection: 'row', gap: s(2) },
  actionButton: { flex: 1 },
  success: { marginTop: s(3), fontFamily: 'Inter-SemiBold', fontSize: 14, lineHeight: 20, fontWeight: '600', letterSpacing: 0.2, color: colors.success },
  list: { flex: 1 },
  listContent: { padding: s(4), paddingBottom: s(8) },
  override: { minHeight: s(10), fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', letterSpacing: 0.2, color: colors.textSecondary, paddingVertical: s(2) },
  separator: { height: StyleSheet.hairlineWidth, backgroundColor: colors.border },
});
