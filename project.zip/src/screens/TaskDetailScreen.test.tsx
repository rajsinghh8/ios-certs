import React from 'react';
import { render } from '@testing-library/react-native';
import { NavigationContainer } from '@react-navigation/native';
import { TaskDetailScreen } from './TaskDetailScreen';

test('renders without crashing', () => {
  render(
    <NavigationContainer>
      <TaskDetailScreen route={{ params: { taskId: 't1' } } as any} />
    </NavigationContainer>,
  );
});
