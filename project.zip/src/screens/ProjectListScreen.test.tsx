import React from 'react';
import { render } from '@testing-library/react-native';
import { NavigationContainer } from '@react-navigation/native';
import { ProjectListScreen } from './ProjectListScreen';

test('renders without crashing', () => {
  render(
    <NavigationContainer>
      <ProjectListScreen />
    </NavigationContainer>,
  );
});
