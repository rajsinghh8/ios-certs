import React, { useCallback, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CommonActions, useNavigation } from '@react-navigation/native';
import type { TabScreenNavigation } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { screenRoot } from '../theme/layout';
import { cardShadow } from '../theme/shadows';
import { useRefreshOnFocus } from '../hooks/useRefreshOnFocus';
import { AppSettings, Session } from '../types';
import { getSession, getSettings, logout, updateSettings } from '../data/store';
import { confirmAction } from '../utils/confirm';
import { HeaderBar } from '../components/HeaderBar';
import { Avatar } from '../components/Avatar';
import { SettingsToggle } from '../components/SettingsToggle';
import { PrimaryButton } from '../components/PrimaryButton';
import { LoadingState } from '../components/LoadingState';
import { ErrorMessage } from '../components/ErrorMessage';

export function SettingsScreen() {
  const navigation = useNavigation<TabScreenNavigation>();
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [session, setSession] = useState<Session | null>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);

  const loadData = useCallback(async () => {
    try {
      const [sessionData, settingsData] = await Promise.all([getSession(), getSettings()]);
      setSession(sessionData);
      setSettings(settingsData);
      setErrorMessage('');
    } catch {
      setErrorMessage('Could not load settings. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useRefreshOnFocus(loadData);

  const handleToggle = async (key: keyof AppSettings, value: boolean) => {
    if (!settings) {
      return;
    }
    const previous = settings;
    setSettings({ ...settings, [key]: value });
    try {
      await updateSettings({ [key]: value });
    } catch {
      setSettings(previous);
      setErrorMessage('Could not save your preference.');
    }
  };

  const handleLogout = () => {
    confirmAction('Log out', 'Are you sure you want to log out?', 'Log out', async () => {
      try {
        await logout();
        // The tab navigator can't handle this reset, so it bubbles up to the root stack.
        navigation.dispatch(CommonActions.reset({ index: 0, routes: [{ name: 'Login' }] }));
      } catch {
        setErrorMessage('Could not log out. Please try again.');
      }
    });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <HeaderBar title="Settings" />
      {isLoading || !settings ? (
        <LoadingState label="Loading settings…" />
      ) : (
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          {errorMessage ? <ErrorMessage message={errorMessage} /> : null}

          <Text style={styles.sectionLabel}>Profile</Text>
          <View style={[styles.card, styles.profileRow]}>
            <Avatar name={session?.name ?? 'User'} size={56} />
            <View style={styles.profileText}>
              <Text style={styles.name}>{session?.name ?? 'Signed-out user'}</Text>
              <Text style={styles.caption}>{session?.email ?? ''}</Text>
              <Text style={styles.role}>{session?.role === 'admin' ? 'Administrator' : 'Member'}</Text>
            </View>
          </View>

          <Text style={styles.sectionLabel}>Notifications</Text>
          <View style={styles.card}>
            <SettingsToggle
              label="Push notifications"
              description="Alerts for task and project updates"
              value={settings.pushNotifications}
              onValueChange={(value) => handleToggle('pushNotifications', value)}
            />
            <View style={styles.divider} />
            <SettingsToggle
              label="Email digest"
              description="A daily summary of activity"
              value={settings.emailDigest}
              onValueChange={(value) => handleToggle('emailDigest', value)}
            />
            <View style={styles.divider} />
            <SettingsToggle
              label="Task reminders"
              description="Remind me before tasks are due"
              value={settings.taskReminders}
              onValueChange={(value) => handleToggle('taskReminders', value)}
            />
          </View>

          <Text style={styles.sectionLabel}>Preferences</Text>
          <View style={styles.card}>
            <SettingsToggle
              label="Compact lists"
              description="Show more items per screen"
              value={settings.compactLists}
              onValueChange={(value) => handleToggle('compactLists', value)}
            />
          </View>

          <View style={styles.logout}>
            <PrimaryButton label="Log out" variant="danger" onPress={handleLogout} />
          </View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

export default SettingsScreen;

const styles = StyleSheet.create({
  safe: {
    ...screenRoot,
  },
  content: {
    padding: s(4),
    paddingBottom: s(8),
  },
  sectionLabel: {
    ...typography.label,
    marginTop: s(4),
    marginBottom: s(2),
  },
  card: {
    paddingHorizontal: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    ...cardShadow,
  },
  profileRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: s(4),
  },
  profileText: {
    marginLeft: s(4),
    flex: 1,
  },
  name: {
    ...typography.heading3,
  },
  caption: {
    ...typography.caption,
  },
  role: {
    ...typography.captionStrong,
    color: colors.primary,
    marginTop: s(1),
  },
  divider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.border,
  },
  logout: {
    marginTop: s(8),
  },
});
