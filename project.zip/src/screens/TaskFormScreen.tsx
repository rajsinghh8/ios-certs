import React, { useCallback, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { RouteProp, useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { FilterChip } from '../components/FilterChip';
import { HeaderBar } from '../components/HeaderBar';
import { createTask, getTasks, updateTask } from '../data/store';
import { RootStackParamList } from '../navigation';
import { TaskItem, TaskPriority, TaskStatus } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type TaskFormRoute = RouteProp<RootStackParamList, 'TaskForm'>;

const priorityOptions: TaskPriority[] = ['low', 'medium', 'high'];
const statusOptions: TaskStatus[] = ['todo', 'inProgress', 'done'];

const statusLabel = (status: TaskStatus) => {
  if (status === 'inProgress') return 'In progress';
  if (status === 'done') return 'Done';
  return 'To do';
};

export default function TaskFormScreen() {
  const route = useRoute<TaskFormRoute>();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const editingId = route.params?.id;
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Planning');
  const [dueDate, setDueDate] = useState(new Date().toISOString().slice(0, 10));
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [status, setStatus] = useState<TaskStatus>('todo');
  const [error, setError] = useState('');

  const loadExisting = useCallback(() => {
    let active = true;
    if (!editingId) return () => undefined;
    getTasks().then((items) => {
      const task = items.find((item) => item.id === editingId);
      if (task && active) {
        setTitle(task.title);
        setDescription(task.description);
        setCategory(task.category);
        setDueDate(task.dueDate);
        setPriority(task.priority);
        setStatus(task.status);
      }
    });
    return () => {
      active = false;
    };
  }, [editingId]);

  useFocusEffect(loadExisting);

  const submit = async () => {
    if (!title.trim()) {
      setError('Add a clear task title.');
      return;
    }
    if (!description.trim()) {
      setError('Add a short description.');
      return;
    }
    const payload: Omit<TaskItem, 'id' | 'createdAt'> = {
      title: title.trim(),
      description: description.trim(),
      category: category.trim() || 'General',
      dueDate: dueDate.trim() || new Date().toISOString().slice(0, 10),
      priority,
      status,
    };
    if (editingId) {
      await updateTask(editingId, payload);
    } else {
      await createTask(payload);
    }
    navigation.goBack();
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView style={styles.keyboard} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <HeaderBar title={editingId ? 'Edit task' : 'New task'} showBack onBack={() => navigation.goBack()} />
        <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          {error ? <Text style={styles.errorText}>{error}</Text> : null}
          <Text style={styles.label}>Title</Text>
          <TextInput
            value={title}
            onChangeText={(value) => {
              setTitle(value);
              setError('');
            }}
            placeholder="What needs to be done?"
            placeholderTextColor={colors.textDisabled}
            autoCapitalize="sentences"
            autoCorrect
            returnKeyType="next"
            underlineColorAndroid="transparent"
            selectionColor={colors.primary}
            style={styles.input}
          />
          <Text style={styles.label}>Description</Text>
          <TextInput
            value={description}
            onChangeText={(value) => {
              setDescription(value);
              setError('');
            }}
            placeholder="Add helpful context"
            placeholderTextColor={colors.textDisabled}
            autoCapitalize="sentences"
            autoCorrect
            returnKeyType="done"
            underlineColorAndroid="transparent"
            selectionColor={colors.primary}
            multiline
            style={[styles.input, styles.textArea]}
          />
          <Text style={styles.label}>Category</Text>
          <TextInput
            value={category}
            onChangeText={setCategory}
            placeholder="Planning"
            placeholderTextColor={colors.textDisabled}
            autoCapitalize="words"
            autoCorrect={false}
            returnKeyType="done"
            underlineColorAndroid="transparent"
            selectionColor={colors.primary}
            style={styles.input}
          />
          <Text style={styles.label}>Due date</Text>
          <TextInput
            value={dueDate}
            onChangeText={setDueDate}
            placeholder="YYYY-MM-DD"
            placeholderTextColor={colors.textDisabled}
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="done"
            underlineColorAndroid="transparent"
            selectionColor={colors.primary}
            style={styles.input}
          />
          <Text style={styles.label}>Priority</Text>
          <View style={styles.chipRow}>
            {priorityOptions.map((item) => <FilterChip key={item} label={item} selected={priority === item} onPress={() => setPriority(item)} />)}
          </View>
          <Text style={styles.label}>Status</Text>
          <View style={styles.chipRow}>
            {statusOptions.map((item) => <FilterChip key={item} label={statusLabel(item)} selected={status === item} onPress={() => setStatus(item)} />)}
          </View>
          <Pressable
            onPress={submit}
            android_ripple={{ color: 'rgba(255,255,255,0.16)', borderless: false }}
            style={({ pressed }) => [styles.submitButton, pressed && Platform.OS === 'ios' && styles.pressed]}
          >
            <Text style={styles.submitText}>{editingId ? 'Save changes' : 'Create task'}</Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  keyboard: {
    flex: 1,
  },
  scroll: {
    flex: 1,
  },
  content: {
    paddingHorizontal: s(4),
    paddingBottom: s(10),
  },
  errorText: {
    marginBottom: s(3),
    padding: s(3),
    borderRadius: s(2),
    backgroundColor: colors.surface,
    fontFamily: 'Inter-SemiBold',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.error,
  },
  label: {
    marginTop: s(4),
    marginBottom: s(2),
    fontFamily: 'Inter-SemiBold',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
  },
  input: {
    minHeight: s(13),
    borderRadius: s(3),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    paddingHorizontal: s(4),
    paddingVertical: s(3),
    fontFamily: 'Inter-Regular',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textPrimary,
  },
  textArea: {
    minHeight: s(28),
    textAlignVertical: 'top',
  },
  chipRow: {
    minHeight: s(11),
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  submitButton: {
    minHeight: s(13),
    marginTop: s(8),
    borderRadius: s(3),
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressed: {
    opacity: 0.7,
  },
  submitText: {
    fontFamily: 'Inter-Bold',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '700',
    letterSpacing: 0.2,
    color: colors.textInverse,
  },
});
