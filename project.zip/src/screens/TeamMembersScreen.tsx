import React, { useCallback, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Toast from 'react-native-toast-message';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { screenRoot } from '../theme/layout';
import { cardShadow } from '../theme/shadows';
import { useRefreshOnFocus } from '../hooks/useRefreshOnFocus';
import { Availability, Task, TeamMember } from '../types';
import { addTeamMember, getTasks, getTeamMembers, removeTeamMember } from '../data/store';
import { AVAILABILITIES } from '../constants';
import { validateEmail, validateMinLength } from '../validation';
import { confirmAction } from '../utils/confirm';
import { HeaderBar } from '../components/HeaderBar';
import { SearchBar } from '../components/SearchBar';
import { TeamMemberCard } from '../components/TeamMemberCard';
import { TextField } from '../components/TextField';
import { ChipSelector } from '../components/ChipSelector';
import { PrimaryButton } from '../components/PrimaryButton';
import { EmptyState } from '../components/EmptyState';
import { LoadingState } from '../components/LoadingState';
import { ErrorMessage } from '../components/ErrorMessage';

export function TeamMembersScreen() {
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [searchText, setSearchText] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('');
  const [availability, setAvailability] = useState<Availability>('Available');

  const loadData = useCallback(async () => {
    try {
      const [memberData, taskData] = await Promise.all([getTeamMembers(), getTasks()]);
      setMembers(memberData);
      setTasks(taskData);
      setErrorMessage('');
    } catch {
      setErrorMessage('Could not load team members. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useRefreshOnFocus(loadData);

  const nameError = validateMinLength(name, 'Name', 2);
  const emailError = validateEmail(email);
  const roleError = validateMinLength(role, 'Role', 2);
  const isValid = nameError === '' && emailError === '' && roleError === '';

  const resetForm = () => {
    setName('');
    setEmail('');
    setRole('');
    setAvailability('Available');
    setHasSubmitted(false);
  };

  const handleAdd = async () => {
    setHasSubmitted(true);
    if (!isValid) {
      return;
    }
    try {
      const created = await addTeamMember({
        name: name.trim(),
        email: email.trim(),
        role: role.trim(),
        availability,
      });
      setMembers((previous) => [...previous, created]);
      Toast.show({ type: 'success', text1: `${created.name} added to the team` });
      resetForm();
      setIsFormOpen(false);
    } catch {
      setErrorMessage('Could not add the team member. Please try again.');
    }
  };

  const handleRemove = (member: TeamMember) => {
    confirmAction('Remove member', `Remove ${member.name} from the team?`, 'Remove', async () => {
      try {
        await removeTeamMember(member.id);
        setMembers((previous) => previous.filter((item) => item.id !== member.id));
        setTasks((previous) =>
          previous.map((task) => (task.assigneeId === member.id ? { ...task, assigneeId: null } : task)),
        );
      } catch {
        setErrorMessage('Could not remove the team member. Please try again.');
      }
    });
  };

  const visibleMembers = members.filter((member) => {
    const query = searchText.trim().toLowerCase();
    return member.name.toLowerCase().includes(query) || member.role.toLowerCase().includes(query);
  });

  return (
    <SafeAreaView style={styles.safe}>
      <HeaderBar
        title="Team"
        rightIcon={isFormOpen ? 'close' : 'person-add-outline'}
        rightLabel={isFormOpen ? 'Close form' : 'Add team member'}
        onRightPress={() => setIsFormOpen((previous) => !previous)}
      />
      {isLoading ? (
        <LoadingState label="Loading team…" />
      ) : (
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
        >
          <FlatList
            data={visibleMembers}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.listContent}
            keyboardShouldPersistTaps="handled"
            ListHeaderComponent={
              <View style={styles.header}>
                {errorMessage ? <ErrorMessage message={errorMessage} /> : null}
                {isFormOpen ? (
                  <View style={styles.form}>
                    <TextField
                      label="Name"
                      value={name}
                      onChangeText={setName}
                      placeholder="Full name"
                      error={hasSubmitted ? nameError : ''}
                    />
                    <TextField
                      label="Email"
                      value={email}
                      onChangeText={setEmail}
                      placeholder="name@example.com"
                      keyboardType="email-address"
                      error={hasSubmitted ? emailError : ''}
                    />
                    <TextField
                      label="Role"
                      value={role}
                      onChangeText={setRole}
                      placeholder="e.g. Designer"
                      helper="At least 2 characters"
                      error={hasSubmitted ? roleError : ''}
                    />
                    <View style={styles.chips}>
                      <ChipSelector
                        options={AVAILABILITIES}
                        selected={availability}
                        onSelect={(value) => setAvailability(value ?? 'Available')}
                      />
                    </View>
                    <PrimaryButton label="Add member" onPress={handleAdd} disabled={!isValid && hasSubmitted} />
                  </View>
                ) : null}
                <SearchBar value={searchText} onChangeText={setSearchText} placeholder="Search by name or role" />
              </View>
            }
            ListEmptyComponent={
              <EmptyState
                icon="people-outline"
                title={members.length === 0 ? 'No team members' : 'No matches'}
                message={
                  members.length === 0
                    ? 'Add your first team member with the button above.'
                    : 'Try a different search term.'
                }
              />
            }
            renderItem={({ item }) => (
              <TeamMemberCard
                member={item}
                assignedTaskCount={tasks.filter((task) => task.assigneeId === item.id).length}
                onRemove={() => handleRemove(item)}
              />
            )}
            ItemSeparatorComponent={() => <View style={styles.separator} />}
            showsVerticalScrollIndicator={false}
            removeClippedSubviews={Platform.OS === 'android'}
            initialNumToRender={10}
            maxToRenderPerBatch={10}
            windowSize={5}
          />
        </KeyboardAvoidingView>
      )}
    </SafeAreaView>
  );
}

export default TeamMembersScreen;

const styles = StyleSheet.create({
  safe: {
    ...screenRoot,
  },
  flex: {
    flex: 1,
  },
  listContent: {
    padding: s(4),
    paddingBottom: s(8),
  },
  header: {
    marginBottom: s(4),
    gap: s(3),
  },
  form: {
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    ...cardShadow,
  },
  chips: {
    marginBottom: s(4),
  },
  separator: {
    height: s(3),
  },
});
