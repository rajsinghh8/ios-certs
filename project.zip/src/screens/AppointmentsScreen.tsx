import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Chip } from '../components/Chip';
import { HeaderBar } from '../components/HeaderBar';
import { InfoCard } from '../components/InfoCard';
import { PrimaryButton } from '../components/PrimaryButton';
import { getAppointments, getLocations, getServices, getStaff, getWaitlist, updateAppointmentStatus, saveWaitlistEntry } from '../data/store';
import { Appointment, AppointmentStatus, Location, Service, StaffMember, WaitlistEntry } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

const terminal: AppointmentStatus[] = ['cancelled', 'completed', 'noShow'];
const isPast = (appt: Appointment) => new Date(`${appt.date}T${appt.endTime}:00`).getTime() < Date.now();
const canCancel = (appt: Appointment) => new Date(`${appt.date}T${appt.startTime}:00`).getTime() - Date.now() > 24 * 60 * 60 * 1000 && !terminal.includes(appt.status);

export default function AppointmentsScreen() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [waitlist, setWaitlist] = useState<WaitlistEntry[]>([]);
  const [filter, setFilter] = useState<AppointmentStatus | 'all'>('all');
  const [note, setNote] = useState('');

  useEffect(() => { Promise.all([getAppointments(), getLocations(), getServices(), getStaff(), getWaitlist()]).then(([a, l, sv, st, w]) => { setAppointments(a); setLocations(l); setServices(sv); setStaff(st); setWaitlist(w); }); }, []);

  const rows = useMemo(() => appointments.filter((item) => filter === 'all' || item.status === filter).sort((a, b) => `${b.date}${b.startTime}`.localeCompare(`${a.date}${a.startTime}`)), [appointments, filter]);
  const nameFor = (list: { id: string; name: string }[], id: string) => list.find((item) => item.id === id)?.name ?? 'Unknown';

  const setStatus = async (appt: Appointment, status: AppointmentStatus) => {
    const updated = await updateAppointmentStatus(appt.id, status);
    if (updated) setAppointments((prev) => prev.map((item) => (item.id === appt.id ? updated : item)));
    if (status === 'cancelled') {
      const firstWaiting = waitlist.filter((w) => w.date === appt.date && w.serviceId === appt.serviceId && (!w.staffId || w.staffId === appt.staffId) && !w.notified).sort((a, b) => a.createdAt.localeCompare(b.createdAt))[0];
      if (firstWaiting) {
        const changed = await saveWaitlistEntry({ ...firstWaiting, notified: true });
        setWaitlist((prev) => prev.map((item) => (item.id === changed.id ? changed : item)));
        setNote(`${firstWaiting.customerName} was notified from the waitlist.`);
      } else setNote('Cancelled. No matching waitlist entries needed notification.');
    }
  };

  const renderItem = ({ item }: { item: Appointment }) => {
    const loc = locations.find((l) => l.id === item.locationId);
    return (
      <View style={styles.cardWrap}>
        <InfoCard title={`${item.customerName} · ${nameFor(services, item.serviceId)}`} subtitle={`${item.date} ${item.startTime}-${item.endTime} · ${nameFor(staff, item.staffId)}`} meta={`${loc?.name ?? 'Location'} · ${item.status}`} icon="calendar-outline" />
        <View style={styles.actions}>
          <PrimaryButton label="Cancel" variant="danger" disabled={!canCancel(item)} onPress={() => setStatus(item, 'cancelled')} />
          <View style={styles.actionGap} />
          <PrimaryButton label="Complete" variant="secondary" disabled={!isPast(item) || terminal.includes(item.status)} onPress={() => setStatus(item, 'completed')} />
          <View style={styles.actionGap} />
          <PrimaryButton label="No-show" variant="secondary" disabled={!isPast(item) || terminal.includes(item.status)} onPress={() => setStatus(item, 'noShow')} />
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="All appointments" subtitle="Filter, cancel, complete, and no-show appointments" />
      <View style={styles.filters}>{(['all', 'confirmed', 'cancelled', 'completed', 'noShow'] as const).map((f) => <Chip key={f} label={f} selected={filter === f} onPress={() => setFilter(f)} />)}</View>
      {note ? <Text style={styles.note}>{note}</Text> : null}
      <FlatList data={rows} keyExtractor={(item) => item.id} renderItem={renderItem} contentContainerStyle={styles.list} ItemSeparatorComponent={() => <View style={styles.separator} />} showsVerticalScrollIndicator={false} removeClippedSubviews={Platform.OS === 'android'} initialNumToRender={10} maxToRenderPerBatch={10} windowSize={5} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  filters: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: s(4), paddingTop: s(4) },
  list: { padding: s(4), paddingBottom: s(8) },
  cardWrap: { flex: 1 },
  actions: { flexDirection: 'row', marginTop: s(2) },
  actionGap: { width: s(2) },
  separator: { height: s(3) },
  note: { marginHorizontal: s(4), marginTop: s(2), fontFamily: 'Inter-Medium', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '500', letterSpacing: 0.2, color: colors.info },
});
