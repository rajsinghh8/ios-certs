import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import HeaderBar from '../components/HeaderBar';
import Chip from '../components/Chip';
import InfoCard from '../components/InfoCard';
import PrimaryButton from '../components/PrimaryButton';
import { Appointment, AppointmentStatus, Location, Service, StaffMember } from '../types';
import { getAppointments, getLocations, getServices, getStaff, getWaitlist, saveAppointments, saveWaitlist } from '../data/store';
import { RootStackParamList } from '../navigation';

const dateTime = (apt: Appointment) => new Date(`${apt.date}T${apt.endTime}:00`);
const canCancel = (apt: Appointment) => apt.status === 'confirmed' && new Date(`${apt.date}T${apt.startTime}:00`).getTime() - Date.now() > 24 * 60 * 60 * 1000;
const canFinalize = (apt: Appointment) => apt.status === 'confirmed' && dateTime(apt).getTime() < Date.now();

export default function AppointmentsScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'MainTabs'>>();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [filter, setFilter] = useState<AppointmentStatus | 'all'>('all');
  const [notice, setNotice] = useState('');

  useFocusEffect(useCallback(() => {
    let active = true;
    Promise.all([getAppointments(), getLocations(), getServices(), getStaff()]).then(([a, l, svc, st]) => {
      if (active) { setAppointments(a); setLocations(l); setServices(svc); setStaff(st); }
    });
    return () => { active = false; };
  }, []));

  const filtered = useMemo(() => appointments.filter((a) => filter === 'all' || a.status === filter).sort((a, b) => `${a.date}${a.startTime}`.localeCompare(`${b.date}${b.startTime}`)), [appointments, filter]);
  const label = (apt: Appointment) => `${services.find((sItem) => sItem.id === apt.serviceId)?.name ?? 'Service'} with ${staff.find((m) => m.id === apt.staffId)?.name ?? 'Staff'}`;
  const meta = (apt: Appointment) => `${locations.find((l) => l.id === apt.locationId)?.name ?? 'Location'} • ${apt.status.replace('_', ' ')}`;

  const updateStatus = async (apt: Appointment, status: AppointmentStatus) => {
    if (status === 'cancelled' && !canCancel(apt)) {
      setNotice('Cancellation is not allowed because this appointment is less than 24 hours away or is no longer confirmed.');
      return;
    }
    setNotice('');
    const next = appointments.map((item) => item.id === apt.id ? { ...item, status } : item);
    setAppointments(next);
    await saveAppointments(next);
    if (status === 'cancelled') {
      const waiters = await getWaitlist();
      const idx = waiters.findIndex((w) => w.date === apt.date && w.serviceId === apt.serviceId && (!w.staffId || w.staffId === apt.staffId));
      if (idx >= 0) {
        const notified = waiters.map((w, index) => index === idx ? { ...w, notified: true } : w);
        await saveWaitlist(notified);
      }
    }
  };

  const renderItem = ({ item }: { item: Appointment }) => (
    <View style={styles.itemWrap}>
      <InfoCard title={item.customerName} subtitle={`${item.date} • ${item.startTime}-${item.endTime} • ${label(item)}`} meta={meta(item)} icon="calendar-outline" onPress={() => navigation.navigate('AppointmentDetail', { id: item.id })} />
      {item.status === 'confirmed' ? (
        <View style={styles.actions}>
          <PrimaryButton label="Cancel" onPress={() => updateStatus(item, 'cancelled')} variant={canCancel(item) ? 'danger' : 'secondary'} style={styles.actionButton} />
          <PrimaryButton label="Complete" onPress={() => updateStatus(item, 'completed')} disabled={!canFinalize(item)} variant="secondary" style={styles.actionButton} />
          <PrimaryButton label="No-show" onPress={() => updateStatus(item, 'no_show')} disabled={!canFinalize(item)} variant="secondary" style={styles.actionButton} />
        </View>
      ) : null}
    </View>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="All appointments" subtitle="Cancel with 24+ hours notice or finalize past bookings" />
      {notice ? <Text style={styles.notice}>{notice}</Text> : null}
      <View style={styles.filters}>{(['all', 'confirmed', 'completed', 'cancelled', 'no_show'] as const).map((f) => <Chip key={f} label={f.replace('_', ' ')} selected={filter === f} onPress={() => setFilter(f)} />)}</View>
      <FlatList style={styles.list} contentContainerStyle={styles.listContent} data={filtered} keyExtractor={(item) => item.id} renderItem={renderItem} ItemSeparatorComponent={() => <View style={styles.separator} />} showsVerticalScrollIndicator={false} removeClippedSubviews={Platform.OS === 'android'} initialNumToRender={10} maxToRenderPerBatch={10} windowSize={5} ListEmptyComponent={<Text style={styles.empty}>No appointments match this filter.</Text>} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}) },
  filters: { flexDirection: 'row', flexWrap: 'wrap', padding: s(4), paddingBottom: s(2), minHeight: s(14) },
  list: { flex: 1 },
  listContent: { padding: s(4), paddingTop: s(2), paddingBottom: s(8) },
  itemWrap: { minHeight: s(32) },
  actions: { flexDirection: 'row', gap: s(2), marginBottom: s(3) },
  actionButton: { flex: 1, minHeight: s(10), paddingHorizontal: s(2) },
  separator: { height: StyleSheet.hairlineWidth, backgroundColor: colors.border },
  empty: { fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', letterSpacing: 0.2, color: colors.textSecondary, padding: s(4) },
});
