import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Chip } from '../components/Chip';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { TextField } from '../components/TextField';
import { getAppointments, getLocations, getScheduleOverrides, getServices, getStaff, getWeeklySchedules, saveAppointment } from '../data/store';
import { Appointment, Location, ScheduleOverride, Service, StaffMember, TimeBlock, WeeklyScheduleDay } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

const toMinutes = (time: string) => {
  const [hours, minutes] = time.split(':').map(Number);
  return hours * 60 + minutes;
};
const toTime = (minutes: number) => `${Math.floor(minutes / 60).toString().padStart(2, '0')}:${(minutes % 60).toString().padStart(2, '0')}`;
const formatPrice = (cents: number) => `$${(cents / 100).toFixed(2)}`;
const addDays = (offset: number) => {
  const date = new Date();
  date.setDate(date.getDate() + offset);
  return date.toISOString().slice(0, 10);
};
const overlaps = (aStart: number, aEnd: number, bStart: number, bEnd: number) => aStart < bEnd && bStart < aEnd;

export default function BookingScreen() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [weekly, setWeekly] = useState<WeeklyScheduleDay[]>([]);
  const [overrides, setOverrides] = useState<ScheduleOverride[]>([]);
  const [locationId, setLocationId] = useState('');
  const [serviceId, setServiceId] = useState('');
  const [staffId, setStaffId] = useState('anyone');
  const [date, setDate] = useState(addDays(7));
  const [time, setTime] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    Promise.all([getLocations(), getServices(), getStaff(), getAppointments(), getWeeklySchedules(), getScheduleOverrides()]).then(([l, sRows, st, a, w, o]) => {
      setLocations(l); setServices(sRows); setStaff(st); setAppointments(a); setWeekly(w); setOverrides(o);
      setLocationId(l[0]?.id ?? ''); setServiceId(sRows[0]?.id ?? '');
    });
  }, []);

  const selectedService = services.find((item) => item.id === serviceId);
  const selectedLocation = locations.find((item) => item.id === locationId);
  const eligibleStaff = staff.filter((person) => person.locationId === locationId && person.serviceIds.includes(serviceId));
  const days = useMemo(() => Array.from({ length: 10 }, (_, index) => addDays(index + 1)), []);

  const staffBlocks = (personId: string): TimeBlock[] => {
    const override = overrides.find((row) => row.staffId === personId && row.date === date);
    if (override) return override.type === 'dayOff' ? [] : override.blocks;
    const weekday = new Date(`${date}T12:00:00`).getDay() as WeeklyScheduleDay['weekday'];
    return weekly.find((row) => row.staffId === personId && row.weekday === weekday)?.blocks ?? [];
  };

  const slots = useMemo(() => {
    if (!selectedService) return [];
    const candidates = staffId === 'anyone' ? eligibleStaff : eligibleStaff.filter((person) => person.id === staffId);
    const now = new Date();
    return candidates.flatMap((person) => staffBlocks(person.id).flatMap((block) => {
      const start = toMinutes(block.start);
      const end = toMinutes(block.end);
      const values: { id: string; staffId: string; staffName: string; time: string }[] = [];
      for (let cursor = start; cursor + selectedService.durationMinutes <= end; cursor += 15) {
        const slotTime = toTime(cursor);
        const slotDate = new Date(`${date}T${slotTime}:00`);
        const blocked = appointments.some((appt) => appt.staffId === person.id && appt.date === date && appt.status === 'confirmed' && overlaps(cursor, cursor + selectedService.durationMinutes, toMinutes(appt.startTime), toMinutes(appt.endTime)));
        if (!blocked && slotDate.getTime() > now.getTime()) values.push({ id: `${person.id}-${slotTime}`, staffId: person.id, staffName: person.name, time: slotTime });
      }
      return values;
    })).sort((a, b) => a.time.localeCompare(b.time));
  }, [appointments, date, eligibleStaff, selectedService, staffId, weekly, overrides]);

  const book = async () => {
    setMessage('');
    const slot = slots.find((item) => item.id === time);
    if (!selectedService || !selectedLocation || !slot || !customerName.trim() || !customerEmail.trim()) {
      setMessage('Choose all booking details and enter customer contact information.');
      return;
    }
    const start = toMinutes(slot.time);
    const appt = await saveAppointment({ locationId, serviceId, staffId: slot.staffId, customerName: customerName.trim(), customerEmail: customerEmail.trim(), date, startTime: slot.time, endTime: toTime(start + selectedService.durationMinutes), status: 'confirmed' });
    setAppointments((prev) => [...prev, appt]);
    setTime('');
    setMessage(`Confirmed ${selectedService.name} with ${slot.staffName} at ${slot.time} in ${selectedLocation.city}.`);
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Browse & book" subtitle="Pick location, service, staff, day, and open time" />
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.section}>Location</Text>
        <View style={styles.row}>{locations.map((item) => <Chip key={item.id} label={`${item.name} · ${item.city}`} selected={locationId === item.id} onPress={() => { setLocationId(item.id); setStaffId('anyone'); setTime(''); }} />)}</View>
        <Text style={styles.section}>Service</Text>
        <View style={styles.row}>{services.map((item) => <Chip key={item.id} label={`${item.name} · ${formatPrice(item.priceCents)}`} selected={serviceId === item.id} onPress={() => { setServiceId(item.id); setStaffId('anyone'); setTime(''); }} />)}</View>
        <Text style={styles.section}>Staff</Text>
        <View style={styles.row}><Chip label="Anyone available" selected={staffId === 'anyone'} onPress={() => { setStaffId('anyone'); setTime(''); }} />{eligibleStaff.map((item) => <Chip key={item.id} label={item.name} selected={staffId === item.id} onPress={() => { setStaffId(item.id); setTime(''); }} />)}</View>
        <Text style={styles.section}>Day</Text>
        <View style={styles.row}>{days.map((item) => <Chip key={item} label={item.slice(5)} selected={date === item} onPress={() => { setDate(item); setTime(''); }} />)}</View>
        <Text style={styles.section}>Open times</Text>
        <FlatList
          data={slots}
          keyExtractor={(item) => item.id}
          horizontal
          directionalLockEnabled={true}
          decelerationRate="fast"
          showsHorizontalScrollIndicator={false}
          removeClippedSubviews={Platform.OS === 'android'}
          initialNumToRender={10}
          maxToRenderPerBatch={10}
          windowSize={5}
          ItemSeparatorComponent={() => <View style={styles.slotGap} />}
          renderItem={({ item }) => <Chip label={`${item.time} · ${item.staffName}`} selected={time === item.id} onPress={() => setTime(item.id)} />}
          ListEmptyComponent={<Text style={styles.empty}>No open times for this selection. Add a waitlist entry from the Waitlist tab.</Text>}
        />
        <View style={styles.form}>
          <TextField label="Customer name" value={customerName} onChangeText={setCustomerName} placeholder="Customer name" />
          <TextField label="Customer email" value={customerEmail} onChangeText={setCustomerEmail} placeholder="customer@email.com" autoCapitalize="none" keyboardType="email-address" />
          <PrimaryButton label="Confirm appointment" onPress={book} />
          {message ? <Text style={[styles.message, message.startsWith('Confirmed') && styles.success]}>{message}</Text> : null}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  scroll: { flex: 1 },
  content: { padding: s(4), paddingBottom: s(8) },
  section: { fontFamily: 'Inter-Bold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '700', letterSpacing: 0.2, color: colors.textPrimary, marginTop: s(4), marginBottom: s(2) },
  row: { flexDirection: 'row', flexWrap: 'wrap' },
  form: { marginTop: s(4), padding: s(4), borderRadius: s(3), backgroundColor: colors.surface, borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  empty: { width: s(64), fontFamily: 'Inter-Regular', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '400', letterSpacing: 0.2, color: colors.textSecondary },
  slotGap: { width: s(2) },
  message: { marginTop: s(3), fontFamily: 'Inter-Medium', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '500', letterSpacing: 0.2, color: colors.error },
  success: { color: colors.success },
});
