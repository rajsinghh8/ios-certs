import React, { useCallback, useState } from 'react';
import { FlatList, Platform, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { TabScreenNavigation } from '../navigation';
import { s } from '../theme/spacing';
import { screenRoot } from '../theme/layout';
import { useRefreshOnFocus } from '../hooks/useRefreshOnFocus';
import { Project, ProjectStatus, Task } from '../types';
import { getProjects, getTasks } from '../data/store';
import { PROJECT_STATUSES } from '../constants';
import { getProjectProgress } from '../utils/progress';
import { HeaderBar } from '../components/HeaderBar';
import { SearchBar } from '../components/SearchBar';
import { ChipSelector } from '../components/ChipSelector';
import { ProjectCard } from '../components/ProjectCard';
import { EmptyState } from '../components/EmptyState';
import { LoadingState } from '../components/LoadingState';
import { ErrorMessage } from '../components/ErrorMessage';
import { FloatingButton } from '../components/FloatingButton';

export function ProjectListScreen() {
  const navigation = useNavigation<TabScreenNavigation>();
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [projects, setProjects] = useState<Project[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [searchText, setSearchText] = useState('');
  const [statusFilter, setStatusFilter] = useState<ProjectStatus | null>(null);

  const loadData = useCallback(async () => {
    try {
      const [projectData, taskData] = await Promise.all([getProjects(), getTasks()]);
      setProjects(projectData);
      setTasks(taskData);
      setErrorMessage('');
    } catch {
      setErrorMessage('Could not load projects. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useRefreshOnFocus(loadData);

  const visibleProjects = projects
    .filter((project) => statusFilter === null || project.status === statusFilter)
    .filter((project) => project.name.toLowerCase().includes(searchText.trim().toLowerCase()));

  return (
    <SafeAreaView style={styles.safe}>
      <HeaderBar title="Projects" />
      {isLoading ? (
        <LoadingState label="Loading projects…" />
      ) : (
        <View style={styles.flex}>
          <FlatList
            data={visibleProjects}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.listContent}
            ListHeaderComponent={
              <View style={styles.filters}>
                {errorMessage ? <ErrorMessage message={errorMessage} /> : null}
                <SearchBar value={searchText} onChangeText={setSearchText} placeholder="Search projects" />
                <ChipSelector
                  options={PROJECT_STATUSES}
                  selected={statusFilter}
                  onSelect={setStatusFilter}
                  allLabel="All"
                />
              </View>
            }
            ListEmptyComponent={
              <EmptyState
                icon="folder-open-outline"
                title={projects.length === 0 ? 'No projects yet' : 'No matching projects'}
                message={
                  projects.length === 0
                    ? 'Create your first project to start organizing tasks.'
                    : 'Try a different search or status filter.'
                }
                actionLabel={projects.length === 0 ? 'Create project' : undefined}
                onAction={() => navigation.navigate('CreateProject')}
              />
            }
            renderItem={({ item }) => (
              <ProjectCard
                project={item}
                progressPercent={getProjectProgress(tasks, item.id)}
                taskCount={tasks.filter((task) => task.projectId === item.id).length}
                onPress={() => navigation.navigate('ProjectDetail', { projectId: item.id })}
              />
            )}
            ItemSeparatorComponent={() => <View style={styles.separator} />}
            showsVerticalScrollIndicator={false}
            removeClippedSubviews={Platform.OS === 'android'}
            initialNumToRender={10}
            maxToRenderPerBatch={10}
            windowSize={5}
          />
          <FloatingButton
            onPress={() => navigation.navigate('CreateProject')}
            accessibilityLabel="Create project"
          />
        </View>
      )}
    </SafeAreaView>
  );
}

export default ProjectListScreen;

const styles = StyleSheet.create({
  safe: {
    ...screenRoot,
  },
  flex: {
    flex: 1,
  },
  listContent: {
    padding: s(4),
    paddingBottom: s(24),
  },
  filters: {
    gap: s(2),
    marginBottom: s(4),
  },
  separator: {
    height: s(3),
  },
});
