import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { TextField } from '../components/TextField';
import { signup } from '../data/store';
import { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type Props = { navigation: NativeStackNavigationProp<RootStackParamList, 'Signup'> };

export default function SignupScreen({ navigation }: Props) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const submit = async () => {
    setError('');
    if (!name.trim() || !email.trim() || !password.trim()) {
      setError('All fields are required.');
      return;
    }
    if (!email.includes('@')) {
      setError('Enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    const session = await signup(name.trim(), email.trim(), password);
    if (session) navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] });
    else setError('Account could not be created.');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Create account" subtitle="Start managing appointments right away" onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={styles.keyboard} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <View style={styles.content}>
          <TextField label="Full name" value={name} onChangeText={setName} placeholder="Your name" />
          <TextField label="Email" value={email} onChangeText={setEmail} placeholder="you@business.com" autoCapitalize="none" keyboardType="email-address" />
          <TextField label="Password" value={password} onChangeText={setPassword} placeholder="At least 6 characters" secureTextEntry />
          {error ? <Text style={styles.error}>{error}</Text> : null}
          <PrimaryButton label="Create account" onPress={submit} />
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  keyboard: { flex: 1 },
  content: { flex: 1, padding: s(4), paddingTop: s(6) },
  error: { fontFamily: 'Inter-Medium', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '500', letterSpacing: 0.2, color: colors.error, marginBottom: s(3) },
});
