import React, { useCallback, useState } from 'react';
import { FlatList, Platform, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { TabScreenNavigation } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { screenRoot } from '../theme/layout';
import { useRefreshOnFocus } from '../hooks/useRefreshOnFocus';
import { AppNotification } from '../types';
import { deleteNotification, getNotifications, markNotificationsRead } from '../data/store';
import { confirmAction } from '../utils/confirm';
import { HeaderBar } from '../components/HeaderBar';
import { ChipSelector } from '../components/ChipSelector';
import { NotificationItem } from '../components/NotificationItem';
import { EmptyState } from '../components/EmptyState';
import { LoadingState } from '../components/LoadingState';
import { ErrorMessage } from '../components/ErrorMessage';

type NotificationFilter = 'All' | 'Unread';
const FILTERS: NotificationFilter[] = ['All', 'Unread'];

export function NotificationsScreen() {
  const navigation = useNavigation<TabScreenNavigation>();
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [filter, setFilter] = useState<NotificationFilter>('All');

  const loadData = useCallback(async () => {
    try {
      setNotifications(await getNotifications());
      setErrorMessage('');
    } catch {
      setErrorMessage('Could not load notifications. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useRefreshOnFocus(loadData);

  const unreadCount = notifications.filter((item) => !item.isRead).length;
  const visibleNotifications = notifications.filter((item) => filter === 'All' || !item.isRead);

  const handleMarkAllRead = async () => {
    try {
      await markNotificationsRead('all');
      setNotifications((previous) => previous.map((item) => ({ ...item, isRead: true })));
    } catch {
      setErrorMessage('Could not mark notifications as read.');
    }
  };

  const handleOpen = async (notification: AppNotification) => {
    if (!notification.isRead) {
      setNotifications((previous) =>
        previous.map((item) => (item.id === notification.id ? { ...item, isRead: true } : item)),
      );
      try {
        await markNotificationsRead([notification.id]);
      } catch {
        setErrorMessage('Could not mark the notification as read.');
      }
    }
    if (notification.relatedEntityType === 'task') {
      navigation.navigate('TaskDetail', { taskId: notification.relatedEntityId });
    } else if (notification.relatedEntityType === 'project') {
      navigation.navigate('ProjectDetail', { projectId: notification.relatedEntityId });
    }
  };

  const handleDelete = (notification: AppNotification) => {
    confirmAction('Delete notification', 'This notification will be removed.', 'Delete', async () => {
      try {
        await deleteNotification(notification.id);
        setNotifications((previous) => previous.filter((item) => item.id !== notification.id));
      } catch {
        setErrorMessage('Could not delete the notification.');
      }
    });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <HeaderBar
        title={unreadCount > 0 ? `Notifications (${unreadCount})` : 'Notifications'}
        rightIcon="checkmark-done"
        rightLabel="Mark all read"
        onRightPress={unreadCount > 0 ? handleMarkAllRead : undefined}
      />
      {isLoading ? (
        <LoadingState label="Loading notifications…" />
      ) : (
        <FlatList
          data={visibleNotifications}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          ListHeaderComponent={
            <View style={styles.header}>
              {errorMessage ? <ErrorMessage message={errorMessage} /> : null}
              <ChipSelector options={FILTERS} selected={filter} onSelect={(value) => setFilter(value ?? 'All')} />
            </View>
          }
          ListEmptyComponent={
            <EmptyState
              icon="notifications-off-outline"
              title={filter === 'Unread' ? 'All caught up' : 'No notifications'}
              message={
                filter === 'Unread'
                  ? 'You have no unread notifications.'
                  : 'Task and project updates will show up here.'
              }
            />
          }
          renderItem={({ item }) => (
            <NotificationItem
              notification={item}
              onPress={() => handleOpen(item)}
              onDelete={() => handleDelete(item)}
            />
          )}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
          showsVerticalScrollIndicator={false}
          removeClippedSubviews={Platform.OS === 'android'}
          initialNumToRender={10}
          maxToRenderPerBatch={10}
          windowSize={5}
        />
      )}
    </SafeAreaView>
  );
}

export default NotificationsScreen;

const styles = StyleSheet.create({
  safe: {
    ...screenRoot,
  },
  listContent: {
    paddingBottom: s(8),
  },
  header: {
    paddingHorizontal: s(4),
    paddingVertical: s(2),
    backgroundColor: colors.surface,
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.border,
  },
});
