import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { HeaderBar } from '../components/HeaderBar';
import { getTasks } from '../data/store';
import { TaskItem } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface StatRow {
  id: string;
  label: string;
  value: string;
  icon: keyof typeof Ionicons.glyphMap;
  tone: string;
}

export default function StatsScreen() {
  const [tasks, setTasks] = useState<TaskItem[]>([]);

  const loadTasks = useCallback(() => {
    let active = true;
    getTasks().then((items) => {
      if (active) setTasks(items);
    });
    return () => {
      active = false;
    };
  }, []);

  useFocusEffect(loadTasks);

  const stats = useMemo<StatRow[]>(() => {
    const today = new Date().toISOString().slice(0, 10);
    const done = tasks.filter((task) => task.status === 'done').length;
    return [
      { id: 's1', label: 'Total tasks', value: String(tasks.length), icon: 'albums-outline', tone: colors.primary },
      { id: 's2', label: 'Completed', value: String(done), icon: 'checkmark-done-outline', tone: colors.success },
      { id: 's3', label: 'Due today', value: String(tasks.filter((task) => task.dueDate === today).length), icon: 'today-outline', tone: colors.info },
      { id: 's4', label: 'High priority', value: String(tasks.filter((task) => task.priority === 'high' && task.status !== 'done').length), icon: 'flame-outline', tone: colors.warning },
    ];
  }, [tasks]);

  const completionPercent = tasks.length ? Math.round((tasks.filter((task) => task.status === 'done').length / tasks.length) * 100) : 0;

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Stats" subtitle="Simple signals for your workload" />
      <View style={styles.summaryCard}>
        <Text style={styles.summaryLabel}>OVERALL COMPLETION</Text>
        <Text style={styles.summaryValue}>{completionPercent}%</Text>
        <View style={styles.progressTrack}>
          <View style={[styles.progressFill, { width: `${completionPercent}%` }]} />
        </View>
      </View>
      <FlatList
        style={styles.list}
        data={stats}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.statCard}>
            <View style={[styles.statIcon, { backgroundColor: colors.primaryLight }]}>
              <Ionicons name={item.icon} size={s(6)} color={item.tone} />
            </View>
            <View style={styles.statTextGroup}>
              <Text style={styles.statLabel}>{item.label}</Text>
              <Text style={styles.statHint}>Calculated from your current task list</Text>
            </View>
            <Text style={styles.statValue}>{item.value}</Text>
          </View>
        )}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  summaryCard: {
    marginHorizontal: s(4),
    marginBottom: s(4),
    borderRadius: s(4),
    padding: s(5),
    backgroundColor: colors.primaryDark,
  },
  summaryLabel: {
    fontFamily: 'Inter-Bold',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '700',
    letterSpacing: 1.2,
    color: colors.primaryLight,
  },
  summaryValue: {
    marginTop: s(2),
    fontFamily: 'Inter-Bold',
    fontSize: s(10),
    lineHeight: 48,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textInverse,
  },
  progressTrack: {
    height: s(3),
    marginTop: s(4),
    borderRadius: s(2),
    backgroundColor: colors.primary,
    overflow: 'hidden',
  },
  progressFill: {
    height: s(3),
    borderRadius: s(2),
    backgroundColor: colors.accent,
  },
  list: {
    flex: 1,
  },
  listContent: {
    paddingHorizontal: s(4),
    paddingBottom: s(8),
  },
  statCard: {
    minHeight: s(20),
    borderRadius: s(3),
    padding: s(4),
    backgroundColor: colors.card,
    flexDirection: 'row',
    alignItems: 'center',
    ...Platform.select({
      ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(1) }, shadowOpacity: 0.08, shadowRadius: s(2) },
      android: { elevation: 4 },
      default: {},
    }),
  },
  statIcon: {
    width: s(12),
    height: s(12),
    borderRadius: s(6),
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: s(3),
  },
  statTextGroup: {
    flex: 1,
  },
  statLabel: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
  },
  statHint: {
    marginTop: s(1),
    fontFamily: 'Inter-Regular',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  statValue: {
    fontFamily: 'Inter-Bold',
    fontSize: s(7),
    lineHeight: 33.6,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
  },
  separator: {
    height: s(3),
  },
});
