import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { PrimaryButton } from '../components/PrimaryButton';
import { TextField } from '../components/TextField';
import { login } from '../data/store';
import { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type Props = { navigation: NativeStackNavigationProp<RootStackParamList, 'Login'> };

export default function LoginScreen({ navigation }: Props) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError('');
    if (!email.trim() || !password.trim()) {
      setError('Enter an email and password to continue.');
      return;
    }
    setBusy(true);
    const session = await login(email.trim(), password);
    setBusy(false);
    if (!session) {
      setError('Invalid email or password');
      return;
    }
    navigation.replace('MainTabs');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView style={styles.keyboard} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <View style={styles.content}>
          <View style={styles.logo}><Text style={styles.logoText}>IPA</Text></View>
          <Text style={styles.title}>Welcome back</Text>
          <Text style={styles.subtitle}>Sign in to manage booking, staff hours, locations, services, and waitlists.</Text>
          <TextField label="Email" value={email} onChangeText={setEmail} placeholder="you@business.com" autoCapitalize="none" keyboardType="email-address" />
          <TextField label="Password" value={password} onChangeText={setPassword} placeholder="Password" secureTextEntry />
          {error ? <Text style={styles.error}>{error}</Text> : null}
          <PrimaryButton label={busy ? 'Signing in...' : 'Sign in'} onPress={submit} disabled={busy} />
          <Pressable
            onPress={() => navigation.navigate('Signup')}
            android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
            style={({ pressed }) => [styles.signupLink, pressed && Platform.OS === 'ios' && styles.pressed]}
          >
            <Text style={styles.signupText}>Create account</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  keyboard: { flex: 1 },
  content: { flex: 1, justifyContent: 'center', padding: s(6) },
  logo: { width: s(16), height: s(16), borderRadius: s(8), backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginBottom: s(6), alignSelf: 'center' },
  logoText: { fontFamily: 'Inter-Bold', fontSize: s(6), lineHeight: s(6) * 1.2, fontWeight: '700', letterSpacing: -0.5, color: colors.textInverse },
  title: { fontFamily: 'Inter-Bold', fontSize: s(8), lineHeight: s(8) * 1.2, fontWeight: '700', letterSpacing: -0.5, color: colors.textPrimary, textAlign: 'center' },
  subtitle: { fontFamily: 'Inter-Regular', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '400', letterSpacing: 0.2, color: colors.textSecondary, textAlign: 'center', marginTop: s(2), marginBottom: s(8) },
  error: { fontFamily: 'Inter-Medium', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '500', letterSpacing: 0.2, color: colors.error, marginBottom: s(3) },
  signupLink: { minHeight: s(12), alignItems: 'center', justifyContent: 'center', marginTop: s(3), borderRadius: s(2) },
  signupText: { fontFamily: 'Inter-SemiBold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '600', letterSpacing: 0.2, color: colors.primary },
  pressed: { opacity: 0.7 },
});
