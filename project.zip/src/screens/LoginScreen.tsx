import React, { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { screenRoot } from '../theme/layout';
import { TextField } from '../components/TextField';
import { PrimaryButton } from '../components/PrimaryButton';
import { ErrorMessage } from '../components/ErrorMessage';
import { login } from '../data/store';
import { validateEmail, validatePassword } from '../validation';

export function LoginScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Login'>>();
  // MOCK: prefilled with the demo admin login — remove before wiring a real backend.
  const [email, setEmail] = useState('admin@example.com');
  // MOCK: prefilled with the demo admin login — remove before wiring a real backend.
  const [password, setPassword] = useState('password123');
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [loginError, setLoginError] = useState('');

  const emailError = validateEmail(email);
  const passwordError = validatePassword(password);
  const isValid = emailError === '' && passwordError === '';

  const handleLogin = async () => {
    setHasSubmitted(true);
    if (!isValid) {
      return;
    }
    setIsLoading(true);
    setLoginError('');
    try {
      const session = await login(email, password);
      if (!session) {
        setLoginError('Invalid email or password');
        return;
      }
      navigation.replace('MainTabs');
    } catch {
      setLoginError('Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.logo}>
            <Ionicons name="checkmark-done" size={36} color={colors.textInverse} />
          </View>
          <Text style={styles.title}>Welcome back</Text>
          <Text style={styles.subtitle}>Sign in to manage your projects and tasks</Text>

          {loginError ? <ErrorMessage message={loginError} /> : null}

          <TextField
            label="Email"
            value={email}
            onChangeText={setEmail}
            placeholder="you@example.com"
            keyboardType="email-address"
            error={hasSubmitted ? emailError : ''}
          />
          <TextField
            label="Password"
            value={password}
            onChangeText={setPassword}
            placeholder="Your password"
            secureTextEntry
            helper="At least 6 characters"
            error={hasSubmitted ? passwordError : ''}
          />

          <Pressable
            onPress={() => navigation.navigate('ForgotPassword')}
            accessibilityRole="link"
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            style={styles.forgot}
          >
            <Text style={styles.forgotText}>Forgot password?</Text>
          </Pressable>

          <PrimaryButton label="Sign in" onPress={handleLogin} loading={isLoading} disabled={!isValid} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

export default LoginScreen;

const styles = StyleSheet.create({
  safe: {
    ...screenRoot,
    backgroundColor: colors.surface,
  },
  flex: {
    flex: 1,
  },
  content: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: s(6),
  },
  logo: {
    width: s(18),
    height: s(18),
    borderRadius: s(5),
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    marginBottom: s(6),
  },
  title: {
    ...typography.heading1,
    textAlign: 'center',
  },
  subtitle: {
    ...typography.body,
    color: colors.textDisabled,
    textAlign: 'center',
    marginTop: s(1),
    marginBottom: s(8),
  },
  forgot: {
    alignSelf: 'flex-end',
    marginBottom: s(5),
  },
  forgotText: {
    ...typography.captionStrong,
    color: colors.primary,
  },
});
