import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import PrimaryButton from '../components/PrimaryButton';
import { RootStackParamList } from '../navigation';
import { login } from '../data/store';

export default function LoginScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Login'>>();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const submit = async () => {
    if (!email.trim() || !password.trim()) {
      setError('Enter an email and password.');
      return;
    }
    const session = await login(email.trim(), password);
    if (!session) {
      setError('Invalid email or password');
      return;
    }
    navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <View style={styles.hero}>
          <Text style={styles.title}>BookBetter</Text>
          <Text style={styles.subtitle}>Appointments, staff hours, services, and waitlists in one place.</Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Sign in</Text>
          <TextInput style={styles.input} value={email} onChangeText={setEmail} placeholder="Email" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} />
          <TextInput style={styles.input} value={password} onChangeText={setPassword} placeholder="Password" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} secureTextEntry returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} />
          {error ? <Text style={styles.error}>{error}</Text> : null}
          <PrimaryButton label="Log In" onPress={submit} />
          <Pressable onPress={() => navigation.navigate('Signup')} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.link, pressed && Platform.OS === 'ios' && styles.pressed]}>
            <Text style={styles.linkText}>Create account</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}) },
  container: { flex: 1, padding: s(4), justifyContent: 'center' },
  hero: { marginBottom: s(8) },
  title: { fontFamily: 'Inter-Bold', fontSize: 34, lineHeight: 41, fontWeight: '700', letterSpacing: -0.5, color: colors.primaryDark },
  subtitle: { marginTop: s(2), fontFamily: 'Inter-Regular', fontSize: 16, lineHeight: 22, fontWeight: '400', letterSpacing: 0.2, color: colors.textSecondary },
  card: { borderRadius: s(3), backgroundColor: colors.card, padding: s(5), ...Platform.select({ ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 6 }, android: { elevation: 4 }, default: {} }) },
  cardTitle: { marginBottom: s(4), fontFamily: 'Inter-Bold', fontSize: 24, lineHeight: 29, fontWeight: '700', letterSpacing: -0.5, color: colors.textPrimary },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, backgroundColor: colors.surface, paddingHorizontal: s(3), marginBottom: s(3), fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', letterSpacing: 0.2, color: colors.textPrimary },
  error: { marginBottom: s(3), fontFamily: 'Inter-Medium', fontSize: 13, lineHeight: 18, fontWeight: '500', letterSpacing: 0.2, color: colors.error },
  link: { minHeight: s(11), alignItems: 'center', justifyContent: 'center', marginTop: s(2) },
  linkText: { fontFamily: 'Inter-SemiBold', fontSize: 15, lineHeight: 21, fontWeight: '600', letterSpacing: 0.2, color: colors.primary },
  pressed: { opacity: 0.7 },
});
