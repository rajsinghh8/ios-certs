import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { screenRoot } from '../theme/layout';
import { HeaderBar } from '../components/HeaderBar';
import { TextField } from '../components/TextField';
import { PrimaryButton } from '../components/PrimaryButton';
import { validateEmail } from '../validation';

export function ForgotPasswordScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'ForgotPassword'>>();
  const [email, setEmail] = useState('');
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [isSent, setIsSent] = useState(false);

  const emailError = validateEmail(email);

  const handleSend = () => {
    setHasSubmitted(true);
    if (emailError !== '') {
      return;
    }
    // MOCK: no reset email is actually sent — a real backend call goes here.
    setIsSent(true);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <HeaderBar title="Reset password" onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <View style={styles.content}>
          <Text style={styles.body}>
            Enter the email linked to your account and we will send you a link to reset your password.
          </Text>
          <TextField
            label="Email"
            value={email}
            onChangeText={setEmail}
            placeholder="you@example.com"
            keyboardType="email-address"
            error={hasSubmitted ? emailError : ''}
          />
          {isSent ? (
            <Text style={styles.success}>If an account exists for {email.trim()}, a reset link is on its way.</Text>
          ) : null}
          <PrimaryButton label="Send reset link" onPress={handleSend} disabled={emailError !== '' && hasSubmitted} />
          <View style={styles.spacer} />
          <PrimaryButton label="Back to sign in" variant="secondary" onPress={() => navigation.goBack()} />
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

export default ForgotPasswordScreen;

const styles = StyleSheet.create({
  safe: {
    ...screenRoot,
  },
  flex: {
    flex: 1,
  },
  content: {
    padding: s(5),
  },
  body: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: s(5),
  },
  success: {
    ...typography.captionStrong,
    color: colors.success,
    marginBottom: s(4),
  },
  spacer: {
    height: s(3),
  },
});
