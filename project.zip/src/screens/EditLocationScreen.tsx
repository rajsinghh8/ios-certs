import React, { useCallback, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { RouteProp, useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import HeaderBar from '../components/HeaderBar';
import PrimaryButton from '../components/PrimaryButton';
import { getLocations, saveLocation } from '../data/store';
import { RootStackParamList } from '../navigation';

export default function EditLocationScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'EditLocation'>>();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'EditLocation'>>();
  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [timezone, setTimezone] = useState('America/Chicago');
  const [address, setAddress] = useState('');
  const [error, setError] = useState('');

  useFocusEffect(useCallback(() => { let active = true; getLocations().then((items) => { const item = items.find((i) => i.id === route.params?.id); if (active && item) { setName(item.name); setCity(item.city); setTimezone(item.timezone); setAddress(item.address); } }); return () => { active = false; }; }, [route.params?.id]));

  const submit = async () => {
    if (!name.trim() || !city.trim() || !timezone.trim() || !address.trim()) { setError('Complete every field.'); return; }
    await saveLocation({ id: route.params?.id, name: name.trim(), city: city.trim(), timezone: timezone.trim(), address: address.trim() });
    navigation.goBack();
  };

  return (
    <SafeAreaView style={styles.safe}><StatusBar style="dark" /><HeaderBar title={route.params?.id ? 'Edit location' : 'Add location'} onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}><ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
        <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="Location name" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} />
        <TextInput style={styles.input} value={city} onChangeText={setCity} placeholder="City" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} />
        <TextInput style={styles.input} value={timezone} onChangeText={setTimezone} placeholder="Timezone" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} />
        <TextInput style={styles.input} value={address} onChangeText={setAddress} placeholder="Address" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} />
        {error ? <Text style={styles.error}>{error}</Text> : null}<PrimaryButton label="Save Location" onPress={submit} />
      </ScrollView></KeyboardAvoidingView></SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}) },
  flex: { flex: 1 },
  scroll: { flex: 1 },
  content: { padding: s(4), paddingBottom: s(8) },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, backgroundColor: colors.surface, paddingHorizontal: s(3), marginBottom: s(3), fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', letterSpacing: 0.2, color: colors.textPrimary },
  error: { marginBottom: s(3), fontFamily: 'Inter-Medium', fontSize: 13, lineHeight: 18, fontWeight: '500', letterSpacing: 0.2, color: colors.error },
});
