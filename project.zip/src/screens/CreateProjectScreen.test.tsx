import React from 'react';
import { render } from '@testing-library/react-native';
import { NavigationContainer } from '@react-navigation/native';
import { CreateProjectScreen } from './CreateProjectScreen';

test('renders without crashing', () => {
  render(
    <NavigationContainer>
      <CreateProjectScreen />
    </NavigationContainer>,
  );
});
