import React from 'react';
import { Text, Pressable, StyleSheet, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function NotFoundScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  return (
    <SafeAreaView style={styles.safe}>
      <Text style={styles.text}>Screen not found</Text>
      <Pressable onPress={() => navigation.goBack()} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.btn, pressed && Platform.OS === 'ios' && styles.pressed]}>
        <Text style={styles.btnText}>Go Back</Text>
      </Pressable>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}) },
  text: { fontSize: 18, lineHeight: 25, fontWeight: '500', letterSpacing: 0.2, color: colors.textPrimary, fontFamily: 'Inter-Medium' },
  btn: { marginTop: s(4), paddingHorizontal: s(6), paddingVertical: s(3), borderRadius: s(2), backgroundColor: colors.primary, minHeight: s(12) },
  btnText: { color: colors.textInverse, fontSize: 15, lineHeight: 21, fontWeight: '600', letterSpacing: 0.2, fontFamily: 'Inter-SemiBold' },
  pressed: { opacity: 0.7 },
});
