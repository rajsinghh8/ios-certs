import React from 'react';
import { Platform, Pressable, StyleSheet, Text } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../theme/colors'; import { s } from '../theme/spacing';
export default function NotFoundScreen() { const navigation = useNavigation(); return <SafeAreaView style={styles.safe}><Text style={styles.text}>Screen not found</Text><Pressable onPress={() => navigation.goBack()} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.button, pressed && Platform.OS === 'ios' && styles.pressed]}><Text style={styles.buttonText}>Return</Text></Pressable></SafeAreaView>; }
const styles = StyleSheet.create({ safe: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background }, text: { fontFamily: 'Inter-Medium', fontSize: s(4.5), lineHeight: s(5.5), letterSpacing: 0.2, color: colors.textPrimary }, button: { marginTop: s(4), paddingHorizontal: s(6), paddingVertical: s(3), borderRadius: s(2), backgroundColor: colors.primary }, buttonText: { fontFamily: 'Inter-SemiBold', fontSize: s(3.5), lineHeight: s(5), color: colors.textInverse }, pressed: { opacity: 0.7 } });
