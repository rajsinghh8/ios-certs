import React from 'react';
import { StyleSheet, Text } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { screenRoot } from '../theme/layout';
import { PrimaryButton } from '../components/PrimaryButton';

export function NotFoundScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();

  return (
    <SafeAreaView style={styles.safe}>
      <Text style={styles.text}>Screen not found</Text>
      <PrimaryButton label="Go Back" onPress={() => navigation.goBack()} />
    </SafeAreaView>
  );
}

export default NotFoundScreen;

const styles = StyleSheet.create({
  safe: {
    ...screenRoot,
    alignItems: 'center',
    justifyContent: 'center',
    gap: s(4),
  },
  text: {
    ...typography.heading3,
    color: colors.textPrimary,
  },
});
