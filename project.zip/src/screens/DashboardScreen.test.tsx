import React from 'react';
import { render } from '@testing-library/react-native';
import { NavigationContainer } from '@react-navigation/native';
import { DashboardScreen } from './DashboardScreen';

test('renders without crashing', () => {
  render(
    <NavigationContainer>
      <DashboardScreen />
    </NavigationContainer>,
  );
});
