import React, { useCallback, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useFocusEffect } from '@react-navigation/native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import HeaderBar from '../components/HeaderBar';
import Chip from '../components/Chip';
import InfoCard from '../components/InfoCard';
import PrimaryButton from '../components/PrimaryButton';
import { Location, Service, StaffMember, WaitlistEntry } from '../types';
import { createWaitlistEntry, getLocations, getServices, getStaff, getWaitlist } from '../data/store';

export default function WaitlistScreen() {
  const [entries, setEntries] = useState<WaitlistEntry[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [locationId, setLocationId] = useState('');
  const [serviceId, setServiceId] = useState('');
  const [staffId, setStaffId] = useState('any');
  const [date, setDate] = useState('2026-08-08');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [message, setMessage] = useState('');

  useFocusEffect(useCallback(() => { let active = true; Promise.all([getWaitlist(), getLocations(), getServices(), getStaff()]).then(([w, l, svc, st]) => { if (!active) return; setEntries(w); setLocations(l); setServices(svc); setStaff(st); setLocationId((prev) => prev || l[0]?.id || ''); setServiceId((prev) => prev || svc[0]?.id || ''); }); return () => { active = false; }; }, []));

  const eligible = staff.filter((m) => m.locationId === locationId && m.serviceIds.includes(serviceId));
  const submit = async () => { if (!customerName.trim() || !customerEmail.trim() || !locationId || !serviceId || !date.trim()) { setMessage('Complete the waitlist form.'); return; } const saved = await createWaitlistEntry({ customerName: customerName.trim(), customerEmail: customerEmail.trim(), locationId, serviceId, staffId: staffId === 'any' ? undefined : staffId, date: date.trim() }); setEntries((prev) => [...prev, saved]); setMessage('Added to waitlist.'); };
  const subtitle = (item: WaitlistEntry) => `${item.date} • ${services.find((sItem) => sItem.id === item.serviceId)?.name ?? 'Service'} • ${staff.find((m) => m.id === item.staffId)?.name ?? 'Anyone'}`;

  return (
    <SafeAreaView style={styles.safe}><StatusBar style="dark" /><HeaderBar title="Waitlist" subtitle="Longest waiting guest is notified after a matching cancellation" />
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <View style={styles.form}><Text style={styles.label}>Add someone</Text><View style={styles.wrap}>{locations.map((item) => <Chip key={item.id} label={item.name} selected={locationId === item.id} onPress={() => setLocationId(item.id)} />)}</View><View style={styles.wrap}>{services.map((item) => <Chip key={item.id} label={item.name} selected={serviceId === item.id} onPress={() => setServiceId(item.id)} />)}</View><View style={styles.wrap}><Chip label="Any staff" selected={staffId === 'any'} onPress={() => setStaffId('any')} />{eligible.map((item) => <Chip key={item.id} label={item.name} selected={staffId === item.id} onPress={() => setStaffId(item.id)} />)}</View>
        <TextInput style={styles.input} value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} /><TextInput style={styles.input} value={customerName} onChangeText={setCustomerName} placeholder="Customer name" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} /><TextInput style={styles.input} value={customerEmail} onChangeText={setCustomerEmail} placeholder="Customer email" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} />{message ? <Text style={message.startsWith('Added') ? styles.success : styles.error}>{message}</Text> : null}<PrimaryButton label="Add to Waitlist" onPress={submit} /></View>
        <FlatList style={styles.list} contentContainerStyle={styles.listContent} data={entries} keyExtractor={(item) => item.id} renderItem={({ item }) => <InfoCard title={item.customerName} subtitle={subtitle(item)} meta={item.notified ? 'Notified about an opening' : 'Waiting'} icon="notifications-outline" />} ItemSeparatorComponent={() => <View style={styles.separator} />} showsVerticalScrollIndicator={false} removeClippedSubviews={Platform.OS === 'android'} initialNumToRender={10} maxToRenderPerBatch={10} windowSize={5} />
      </KeyboardAvoidingView></SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}) },
  flex: { flex: 1 },
  form: { padding: s(4), backgroundColor: colors.surface, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  label: { marginBottom: s(2), fontFamily: 'Inter-Bold', fontSize: 16, lineHeight: 19, fontWeight: '700', letterSpacing: -0.5, color: colors.textPrimary },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', minHeight: s(9) },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, backgroundColor: colors.surface, paddingHorizontal: s(3), marginBottom: s(3), fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', letterSpacing: 0.2, color: colors.textPrimary },
  success: { marginBottom: s(3), fontFamily: 'Inter-SemiBold', fontSize: 14, lineHeight: 20, fontWeight: '600', letterSpacing: 0.2, color: colors.success },
  error: { marginBottom: s(3), fontFamily: 'Inter-Medium', fontSize: 14, lineHeight: 20, fontWeight: '500', letterSpacing: 0.2, color: colors.error },
  list: { flex: 1 },
  listContent: { padding: s(4), paddingBottom: s(8) },
  separator: { height: StyleSheet.hairlineWidth, backgroundColor: colors.border },
});
