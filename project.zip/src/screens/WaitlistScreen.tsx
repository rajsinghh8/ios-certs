import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Chip } from '../components/Chip';
import { HeaderBar } from '../components/HeaderBar';
import { InfoCard } from '../components/InfoCard';
import { PrimaryButton } from '../components/PrimaryButton';
import { TextField } from '../components/TextField';
import { getLocations, getServices, getStaff, getWaitlist, saveWaitlistEntry } from '../data/store';
import { Location, Service, StaffMember, WaitlistEntry } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function WaitlistScreen() {
  const [entries, setEntries] = useState<WaitlistEntry[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [locationId, setLocationId] = useState('');
  const [serviceId, setServiceId] = useState('');
  const [staffId, setStaffId] = useState('anyone');
  const [date, setDate] = useState('2026-08-08');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [note, setNote] = useState('');

  useEffect(() => { Promise.all([getWaitlist(), getLocations(), getServices(), getStaff()]).then(([w, l, sv, st]) => { setEntries(w); setLocations(l); setServices(sv); setStaff(st); setLocationId(l[0]?.id ?? ''); setServiceId(sv[0]?.id ?? ''); }); }, []);

  const eligibleStaff = staff.filter((person) => person.locationId === locationId && person.serviceIds.includes(serviceId));
  const rows = useMemo(() => entries.filter((item) => item.locationId === locationId || !locationId).sort((a, b) => a.createdAt.localeCompare(b.createdAt)), [entries, locationId]);
  const nameFor = (list: { id: string; name: string }[], id?: string) => id ? list.find((item) => item.id === id)?.name ?? 'Anyone' : 'Anyone';

  const add = async () => {
    setNote('');
    if (!customerName.trim() || !customerEmail.trim()) { setNote('Name and email are required.'); return; }
    const saved = await saveWaitlistEntry({ locationId, serviceId, staffId: staffId === 'anyone' ? undefined : staffId, customerName: customerName.trim(), customerEmail: customerEmail.trim(), date });
    setEntries((prev) => [...prev, saved]);
    setCustomerName(''); setCustomerEmail('');
    setNote('Waitlist entry added. Longest-waiting matching customer is notified when a cancellation opens a slot.');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Waitlist" subtitle="Track customers waiting for fully-booked days" />
      <KeyboardAvoidingView style={styles.keyboard} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <View style={styles.form}>
          <Text style={styles.section}>Add a waitlist entry</Text>
          <View style={styles.row}>{locations.map((item) => <Chip key={item.id} label={item.name} selected={locationId === item.id} onPress={() => { setLocationId(item.id); setStaffId('anyone'); }} />)}</View>
          <View style={styles.row}>{services.map((item) => <Chip key={item.id} label={item.name} selected={serviceId === item.id} onPress={() => { setServiceId(item.id); setStaffId('anyone'); }} />)}</View>
          <View style={styles.row}><Chip label="Anyone" selected={staffId === 'anyone'} onPress={() => setStaffId('anyone')} />{eligibleStaff.map((item) => <Chip key={item.id} label={item.name} selected={staffId === item.id} onPress={() => setStaffId(item.id)} />)}</View>
          <TextField label="Date" value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" />
          <TextField label="Customer name" value={customerName} onChangeText={setCustomerName} placeholder="Customer name" />
          <TextField label="Customer email" value={customerEmail} onChangeText={setCustomerEmail} placeholder="customer@email.com" autoCapitalize="none" keyboardType="email-address" />
          <PrimaryButton label="Add to waitlist" onPress={add} />
          {note ? <Text style={styles.note}>{note}</Text> : null}
        </View>
        <FlatList data={rows} keyExtractor={(item) => item.id} renderItem={({ item }) => <InfoCard title={item.customerName} subtitle={`${item.date} · ${nameFor(services, item.serviceId)} · ${nameFor(staff, item.staffId)}`} meta={item.notified ? 'Notified about an opening' : 'Waiting'} icon="notifications-outline" />} contentContainerStyle={styles.list} ItemSeparatorComponent={() => <View style={styles.separator} />} showsVerticalScrollIndicator={false} removeClippedSubviews={Platform.OS === 'android'} initialNumToRender={10} maxToRenderPerBatch={10} windowSize={5} />
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  keyboard: { flex: 1 },
  form: { margin: s(4), padding: s(4), borderRadius: s(3), backgroundColor: colors.surface, borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  row: { flexDirection: 'row', flexWrap: 'wrap' },
  section: { fontFamily: 'Inter-Bold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '700', letterSpacing: 0.2, color: colors.textPrimary, marginBottom: s(2) },
  list: { padding: s(4), paddingBottom: s(8) },
  separator: { height: s(3) },
  note: { marginTop: s(3), fontFamily: 'Inter-Medium', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '500', letterSpacing: 0.2, color: colors.success },
});
