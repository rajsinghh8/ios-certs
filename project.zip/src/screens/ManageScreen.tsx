import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Chip } from '../components/Chip';
import { HeaderBar } from '../components/HeaderBar';
import { InfoCard } from '../components/InfoCard';
import { PrimaryButton } from '../components/PrimaryButton';
import { TextField } from '../components/TextField';
import { getLocations, getServices, getStaff, saveLocation, saveService, saveStaff } from '../data/store';
import { Location, Service, StaffMember } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type Mode = 'locations' | 'services' | 'staff';

export default function ManageScreen() {
  const [mode, setMode] = useState<Mode>('locations');
  const [locations, setLocations] = useState<Location[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [name, setName] = useState('');
  const [detail, setDetail] = useState('');
  const [extra, setExtra] = useState('');
  const [note, setNote] = useState('');

  useEffect(() => { Promise.all([getLocations(), getServices(), getStaff()]).then(([l, sv, st]) => { setLocations(l); setServices(sv); setStaff(st); }); }, []);

  const rows = useMemo(() => {
    if (mode === 'locations') return locations.map((item) => ({ id: item.id, title: item.name, subtitle: `${item.city} · ${item.timezone}`, meta: item.address }));
    if (mode === 'services') return services.map((item) => ({ id: item.id, title: item.name, subtitle: `${item.durationMinutes} min · $${(item.priceCents / 100).toFixed(2)}`, meta: `${item.staffIds.length} trained staff` }));
    return staff.map((item) => ({ id: item.id, title: item.name, subtitle: item.title, meta: `${locations.find((l) => l.id === item.locationId)?.name ?? 'No location'} · ${item.serviceIds.length} services` }));
  }, [mode, locations, services, staff]);

  const save = async () => {
    setNote('');
    if (!name.trim()) { setNote('Name is required.'); return; }
    if (mode === 'locations') {
      const saved = await saveLocation({ name: name.trim(), city: detail.trim() || 'New City', timezone: extra.trim() || 'America/Chicago', address: 'New address' });
      setLocations((prev) => [...prev, saved]);
      setNote('Location added.');
    } else if (mode === 'services') {
      const priceCents = Math.round(Number(extra || '0') * 100);
      const saved = await saveService({ name: name.trim(), durationMinutes: Number(detail || '30'), priceCents, staffIds: staff.slice(0, 2).map((person) => person.id) });
      setServices((prev) => [...prev, saved]);
      setNote('Service added with exact cents pricing.');
    } else {
      const firstLocation = locations[0]?.id ?? 'loc1';
      const saved = await saveStaff({ name: name.trim(), title: detail.trim() || 'Team Member', locationId: firstLocation, serviceIds: services.slice(0, 2).map((service) => service.id) });
      setStaff((prev) => [...prev, saved]);
      setNote('Staff member added.');
    }
    setName(''); setDetail(''); setExtra('');
  };

  const labels = mode === 'locations' ? ['Location name', 'City', 'Timezone'] : mode === 'services' ? ['Service name', 'Duration minutes', 'Price dollars'] : ['Staff name', 'Title', 'Optional note'];

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Locations, services & staff" subtitle="Add and review operating setup" />
      <KeyboardAvoidingView style={styles.keyboard} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <View style={styles.tabs}><Chip label="Locations" selected={mode === 'locations'} onPress={() => setMode('locations')} /><Chip label="Services" selected={mode === 'services'} onPress={() => setMode('services')} /><Chip label="Staff" selected={mode === 'staff'} onPress={() => setMode('staff')} /></View>
        <View style={styles.form}>
          <TextField label={labels[0]} value={name} onChangeText={setName} placeholder={labels[0]} />
          <TextField label={labels[1]} value={detail} onChangeText={setDetail} placeholder={labels[1]} keyboardType={mode === 'services' ? 'number-pad' : 'default'} />
          <TextField label={labels[2]} value={extra} onChangeText={setExtra} placeholder={labels[2]} keyboardType={mode === 'services' ? 'decimal-pad' : 'default'} />
          <PrimaryButton label={`Add ${mode.slice(0, -1)}`} onPress={save} />
          {note ? <Text style={styles.note}>{note}</Text> : null}
        </View>
        <FlatList data={rows} keyExtractor={(item) => item.id} renderItem={({ item }) => <InfoCard title={item.title} subtitle={item.subtitle} meta={item.meta} icon={mode === 'locations' ? 'location-outline' : mode === 'services' ? 'pricetag-outline' : 'person-outline'} />} contentContainerStyle={styles.list} ItemSeparatorComponent={() => <View style={styles.separator} />} showsVerticalScrollIndicator={false} removeClippedSubviews={Platform.OS === 'android'} initialNumToRender={10} maxToRenderPerBatch={10} windowSize={5} />
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  keyboard: { flex: 1 },
  tabs: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: s(4), paddingTop: s(4) },
  form: { margin: s(4), marginBottom: s(2), padding: s(4), borderRadius: s(3), backgroundColor: colors.surface, borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  list: { padding: s(4), paddingBottom: s(8) },
  separator: { height: s(3) },
  note: { marginTop: s(3), fontFamily: 'Inter-Medium', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '500', letterSpacing: 0.2, color: colors.success },
});
