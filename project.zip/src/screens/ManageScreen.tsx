import React, { useCallback, useState } from 'react';
import { FlatList, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import HeaderBar from '../components/HeaderBar';
import InfoCard from '../components/InfoCard';
import Chip from '../components/Chip';
import { Location, Service, StaffMember } from '../types';
import { getLocations, getServices, getStaff } from '../data/store';
import { RootStackParamList } from '../navigation';

type Section = 'locations' | 'services' | 'staff';
type ManageRoute = 'EditLocation' | 'EditService' | 'EditStaff';
type ManageItem = { id: string; title: string; subtitle: string; meta: string; route: ManageRoute };

export default function ManageScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'MainTabs'>>();
  const [section, setSection] = useState<Section>('locations');
  const [locations, setLocations] = useState<Location[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);

  useFocusEffect(useCallback(() => {
    let active = true;
    Promise.all([getLocations(), getServices(), getStaff()]).then(([l, svc, st]) => { if (active) { setLocations(l); setServices(svc); setStaff(st); } });
    return () => { active = false; };
  }, []));

  const data: ManageItem[] = section === 'locations' ? locations.map((item) => ({ id: item.id, title: item.name, subtitle: `${item.city} • ${item.address}`, meta: item.timezone, route: 'EditLocation' })) : section === 'services' ? services.map((item) => ({ id: item.id, title: item.name, subtitle: `${item.durationMinutes} minutes • $${(item.priceCents / 100).toFixed(2)}`, meta: `${item.staffIds.length} trained staff`, route: 'EditService' })) : staff.map((item) => ({ id: item.id, title: item.name, subtitle: locations.find((l) => l.id === item.locationId)?.name ?? 'Location', meta: `${item.serviceIds.length} services`, route: 'EditStaff' }));

  const addRoute = section === 'locations' ? 'EditLocation' : section === 'services' ? 'EditService' : 'EditStaff';

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Manage" subtitle="Locations, services, staff, and hours" actionLabel="Add" onAction={() => navigation.navigate(addRoute, {})} />
      <View style={styles.filters}><Chip label="Locations" selected={section === 'locations'} onPress={() => setSection('locations')} /><Chip label="Services" selected={section === 'services'} onPress={() => setSection('services')} /><Chip label="Staff" selected={section === 'staff'} onPress={() => setSection('staff')} /></View>
      <FlatList style={styles.list} contentContainerStyle={styles.listContent} data={data} keyExtractor={(item) => item.id} renderItem={({ item }) => <InfoCard title={item.title} subtitle={item.subtitle} meta={item.meta} icon={section === 'locations' ? 'business-outline' : section === 'services' ? 'pricetag-outline' : 'people-outline'} onPress={() => navigation.navigate(item.route, { id: item.id })} onMore={section === 'staff' ? () => navigation.navigate('StaffHours', { staffId: item.id }) : () => navigation.navigate(item.route, { id: item.id })} />} ItemSeparatorComponent={() => <View style={styles.separator} />} showsVerticalScrollIndicator={false} removeClippedSubviews={Platform.OS === 'android'} initialNumToRender={10} maxToRenderPerBatch={10} windowSize={5} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}) },
  filters: { flexDirection: 'row', flexWrap: 'wrap', padding: s(4), paddingBottom: s(2), minHeight: s(14) },
  list: { flex: 1 },
  listContent: { padding: s(4), paddingTop: s(2), paddingBottom: s(8) },
  separator: { height: StyleSheet.hairlineWidth, backgroundColor: colors.border },
});
