import React, { useCallback, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { RouteProp, useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import HeaderBar from '../components/HeaderBar';
import PrimaryButton from '../components/PrimaryButton';
import Chip from '../components/Chip';
import { Location, Service } from '../types';
import { getLocations, getServices, getStaff, saveStaff } from '../data/store';
import { RootStackParamList } from '../navigation';

export default function EditStaffScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'EditStaff'>>();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'EditStaff'>>();
  const [locations, setLocations] = useState<Location[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [name, setName] = useState('');
  const [locationId, setLocationId] = useState('');
  const [serviceIds, setServiceIds] = useState<string[]>([]);
  const [error, setError] = useState('');

  useFocusEffect(useCallback(() => { let active = true; Promise.all([getLocations(), getServices(), getStaff()]).then(([l, svc, st]) => { if (!active) return; setLocations(l); setServices(svc); setLocationId((prev) => prev || l[0]?.id || ''); const item = st.find((i) => i.id === route.params?.id); if (item) { setName(item.name); setLocationId(item.locationId); setServiceIds(item.serviceIds); } }); return () => { active = false; }; }, [route.params?.id]));

  const toggleService = (id: string) => setServiceIds((prev) => prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]);
  const submit = async () => { if (!name.trim() || !locationId || serviceIds.length === 0) { setError('Add a name, location, and at least one service.'); return; } await saveStaff({ id: route.params?.id, name: name.trim(), locationId, serviceIds }); navigation.goBack(); };

  return (
    <SafeAreaView style={styles.safe}><StatusBar style="dark" /><HeaderBar title={route.params?.id ? 'Edit staff' : 'Add staff'} onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}><ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="Staff name" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} />
        <Text style={styles.label}>Location</Text><View style={styles.wrap}>{locations.map((item) => <Chip key={item.id} label={item.name} selected={locationId === item.id} onPress={() => setLocationId(item.id)} />)}</View>
        <Text style={styles.label}>Services trained for</Text><View style={styles.wrap}>{services.map((item) => <Chip key={item.id} label={item.name} selected={serviceIds.includes(item.id)} onPress={() => toggleService(item.id)} />)}</View>
        {error ? <Text style={styles.error}>{error}</Text> : null}<PrimaryButton label="Save Staff" onPress={submit} />
      </ScrollView></KeyboardAvoidingView></SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}) },
  flex: { flex: 1 },
  scroll: { flex: 1 },
  content: { padding: s(4), paddingBottom: s(8) },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, backgroundColor: colors.surface, paddingHorizontal: s(3), marginBottom: s(3), fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', letterSpacing: 0.2, color: colors.textPrimary },
  label: { marginTop: s(3), marginBottom: s(2), fontFamily: 'Inter-Bold', fontSize: 16, lineHeight: 19, fontWeight: '700', letterSpacing: -0.5, color: colors.textPrimary },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', minHeight: s(10) },
  error: { marginVertical: s(3), fontFamily: 'Inter-Medium', fontSize: 13, lineHeight: 18, fontWeight: '500', letterSpacing: 0.2, color: colors.error },
});
