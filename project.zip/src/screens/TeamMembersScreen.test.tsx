import React from 'react';
import { render } from '@testing-library/react-native';
import { NavigationContainer } from '@react-navigation/native';
import { TeamMembersScreen } from './TeamMembersScreen';

test('renders without crashing', () => {
  render(
    <NavigationContainer>
      <TeamMembersScreen />
    </NavigationContainer>,
  );
});
