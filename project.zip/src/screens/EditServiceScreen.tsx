import React, { useCallback, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { RouteProp, useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import HeaderBar from '../components/HeaderBar';
import PrimaryButton from '../components/PrimaryButton';
import Chip from '../components/Chip';
import { StaffMember } from '../types';
import { getServices, getStaff, saveService } from '../data/store';
import { RootStackParamList } from '../navigation';

export default function EditServiceScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'EditService'>>();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'EditService'>>();
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [name, setName] = useState('');
  const [duration, setDuration] = useState('60');
  const [price, setPrice] = useState('89.99');
  const [staffIds, setStaffIds] = useState<string[]>([]);
  const [error, setError] = useState('');

  useFocusEffect(useCallback(() => { let active = true; Promise.all([getServices(), getStaff()]).then(([svc, st]) => { if (!active) return; setStaff(st); const item = svc.find((i) => i.id === route.params?.id); if (item) { setName(item.name); setDuration(String(item.durationMinutes)); setPrice((item.priceCents / 100).toFixed(2)); setStaffIds(item.staffIds); } }); return () => { active = false; }; }, [route.params?.id]));

  const toggleStaff = (id: string) => setStaffIds((prev) => prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]);
  const submit = async () => { const minutes = Number(duration); const cents = Math.round(Number(price) * 100); if (!name.trim() || !Number.isFinite(minutes) || !Number.isFinite(cents) || staffIds.length === 0) { setError('Add name, duration, price, and trained staff.'); return; } await saveService({ id: route.params?.id, name: name.trim(), durationMinutes: minutes, priceCents: cents, staffIds }); navigation.goBack(); };

  return (
    <SafeAreaView style={styles.safe}><StatusBar style="dark" /><HeaderBar title={route.params?.id ? 'Edit service' : 'Add service'} onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}><ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="Service name" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} />
        <TextInput style={styles.input} value={duration} onChangeText={setDuration} placeholder="Duration minutes" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} keyboardType="number-pad" returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} />
        <TextInput style={styles.input} value={price} onChangeText={setPrice} placeholder="Price" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} keyboardType="decimal-pad" returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} />
        <Text style={styles.label}>Staff who can perform this service</Text><View style={styles.wrap}>{staff.map((item) => <Chip key={item.id} label={item.name} selected={staffIds.includes(item.id)} onPress={() => toggleStaff(item.id)} />)}</View>
        {error ? <Text style={styles.error}>{error}</Text> : null}<PrimaryButton label="Save Service" onPress={submit} />
      </ScrollView></KeyboardAvoidingView></SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}) },
  flex: { flex: 1 },
  scroll: { flex: 1 },
  content: { padding: s(4), paddingBottom: s(8) },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, backgroundColor: colors.surface, paddingHorizontal: s(3), marginBottom: s(3), fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', letterSpacing: 0.2, color: colors.textPrimary },
  label: { marginTop: s(3), marginBottom: s(2), fontFamily: 'Inter-Bold', fontSize: 16, lineHeight: 19, fontWeight: '700', letterSpacing: -0.5, color: colors.textPrimary },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', minHeight: s(10) },
  error: { marginVertical: s(3), fontFamily: 'Inter-Medium', fontSize: 13, lineHeight: 18, fontWeight: '500', letterSpacing: 0.2, color: colors.error },
});
