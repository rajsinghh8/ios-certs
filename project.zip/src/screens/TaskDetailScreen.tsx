import React, { useCallback, useState } from 'react';
import { Alert, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { RouteProp, useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { HeaderBar } from '../components/HeaderBar';
import { deleteTask, getTasks, updateTask } from '../data/store';
import { RootStackParamList } from '../navigation';
import { TaskItem, TaskStatus } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type TaskDetailRoute = RouteProp<RootStackParamList, 'TaskDetail'>;

const statusLabel = (status: TaskStatus) => {
  if (status === 'inProgress') return 'In progress';
  if (status === 'done') return 'Done';
  return 'To do';
};

export default function TaskDetailScreen() {
  const route = useRoute<TaskDetailRoute>();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const [task, setTask] = useState<TaskItem | null>(null);

  const loadTask = useCallback(() => {
    let active = true;
    getTasks().then((items) => {
      if (active) setTask(items.find((item) => item.id === route.params.id) ?? null);
    });
    return () => {
      active = false;
    };
  }, [route.params.id]);

  useFocusEffect(loadTask);

  const setStatus = async (status: TaskStatus) => {
    if (!task) return;
    const updated = { ...task, status };
    setTask(updated);
    await updateTask(task.id, { status });
  };

  const removeTask = async () => {
    if (!task) return;
    const performDelete = async () => {
      await deleteTask(task.id);
      navigation.goBack();
    };
    if (Platform.OS === 'web') {
      await performDelete();
      return;
    }
    Alert.alert('Delete task?', 'This removes the task from your list.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: performDelete },
    ]);
  };

  if (!task) {
    return (
      <SafeAreaView style={styles.safe}>
        <StatusBar style="dark" />
        <HeaderBar title="Task" showBack onBack={() => navigation.goBack()} />
        <View style={styles.centerState}>
          <Text style={styles.centerTitle}>Task not found</Text>
          <Text style={styles.centerText}>It may have been deleted or moved.</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Task detail" showBack onBack={() => navigation.goBack()} rightLabel="Edit" onRightPress={() => navigation.navigate('TaskForm', { id: task.id })} />
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.headerCard}>
          <View style={styles.iconCircle}>
            <Ionicons name={task.status === 'done' ? 'checkmark-done-outline' : 'flag-outline'} size={s(8)} color={colors.primary} />
          </View>
          <Text style={styles.title}>{task.title}</Text>
          <Text style={styles.description}>{task.description}</Text>
          <View style={styles.badgeRow}>
            <Text style={styles.badge}>{task.category}</Text>
            <Text style={styles.badge}>{task.priority.toUpperCase()}</Text>
            <Text style={styles.badge}>{statusLabel(task.status)}</Text>
          </View>
        </View>
        <View style={styles.infoCard}>
          <Text style={styles.sectionTitle}>Schedule</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Due date</Text>
            <Text style={styles.infoValue}>{task.dueDate}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Created</Text>
            <Text style={styles.infoValue}>{task.createdAt}</Text>
          </View>
        </View>
        <View style={styles.infoCard}>
          <Text style={styles.sectionTitle}>Status</Text>
          {(['todo', 'inProgress', 'done'] as TaskStatus[]).map((status) => (
            <Pressable
              key={status}
              onPress={() => setStatus(status)}
              android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
              style={({ pressed }) => [styles.statusRow, task.status === status && styles.statusRowSelected, pressed && Platform.OS === 'ios' && styles.pressed]}
            >
              <Text style={[styles.statusText, task.status === status && styles.statusTextSelected]}>{statusLabel(status)}</Text>
              {task.status === status ? <Ionicons name="checkmark-circle" size={s(5)} color={colors.primary} /> : null}
            </Pressable>
          ))}
        </View>
        <Pressable
          onPress={removeTask}
          android_ripple={{ color: 'rgba(239,68,68,0.12)', borderless: false }}
          style={({ pressed }) => [styles.deleteButton, pressed && Platform.OS === 'ios' && styles.pressed]}
        >
          <Text style={styles.deleteText}>Delete task</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  scroll: {
    flex: 1,
  },
  content: {
    padding: s(4),
    paddingBottom: s(10),
  },
  headerCard: {
    borderRadius: s(4),
    padding: s(5),
    backgroundColor: colors.card,
    alignItems: 'center',
    ...Platform.select({
      ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(1) }, shadowOpacity: 0.1, shadowRadius: s(2) },
      android: { elevation: 4 },
      default: {},
    }),
  },
  iconCircle: {
    width: s(18),
    height: s(18),
    borderRadius: s(9),
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: s(4),
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: s(7),
    lineHeight: 33.6,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
    textAlign: 'center',
  },
  description: {
    marginTop: s(3),
    fontFamily: 'Inter-Regular',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  badgeRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginTop: s(4),
  },
  badge: {
    marginHorizontal: s(1),
    marginBottom: s(2),
    paddingHorizontal: s(3),
    paddingVertical: s(2),
    borderRadius: s(5),
    backgroundColor: colors.primaryLight,
    fontFamily: 'Inter-Bold',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '700',
    letterSpacing: 1.2,
    color: colors.primary,
  },
  infoCard: {
    marginTop: s(4),
    borderRadius: s(3),
    padding: s(4),
    backgroundColor: colors.card,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: s(5),
    lineHeight: 24,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
    marginBottom: s(2),
  },
  infoRow: {
    minHeight: s(11),
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  infoLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  infoValue: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
  },
  statusRow: {
    minHeight: s(12),
    borderRadius: s(2),
    paddingHorizontal: s(3),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  statusRowSelected: {
    backgroundColor: colors.primaryLight,
  },
  statusText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  statusTextSelected: {
    color: colors.primary,
  },
  deleteButton: {
    minHeight: s(12),
    marginTop: s(5),
    borderRadius: s(3),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.error,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surface,
  },
  deleteText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.error,
  },
  centerState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: s(6),
  },
  centerTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: s(5),
    lineHeight: 24,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
  },
  centerText: {
    marginTop: s(2),
    fontFamily: 'Inter-Regular',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  pressed: {
    opacity: 0.7,
  },
});
