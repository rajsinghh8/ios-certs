import React, { useCallback, useState } from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Toast from 'react-native-toast-message';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { screenRoot } from '../theme/layout';
import { cardShadow } from '../theme/shadows';
import { useRefreshOnFocus } from '../hooks/useRefreshOnFocus';
import { Project, Task, TaskPriority, TaskStatus, TeamMember } from '../types';
import { deleteTask, getProjects, getTasks, getTeamMembers, updateTask } from '../data/store';
import { TASK_PRIORITIES, TASK_STATUSES } from '../constants';
import { confirmAction } from '../utils/confirm';
import { formatDate, isOverdue } from '../utils/format';
import { HeaderBar } from '../components/HeaderBar';
import { ChipSelector } from '../components/ChipSelector';
import { Avatar } from '../components/Avatar';
import { EmptyState } from '../components/EmptyState';
import { LoadingState } from '../components/LoadingState';
import { ErrorMessage } from '../components/ErrorMessage';
import { PrimaryButton } from '../components/PrimaryButton';

interface TaskDetailScreenProps {
  route: { params: { taskId: string } };
}

export function TaskDetailScreen({ route }: TaskDetailScreenProps) {
  const { taskId } = route.params;
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'TaskDetail'>>();
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [task, setTask] = useState<Task | null>(null);
  const [project, setProject] = useState<Project | null>(null);
  const [members, setMembers] = useState<TeamMember[]>([]);

  const loadData = useCallback(async () => {
    try {
      const [taskData, projectData, memberData] = await Promise.all([
        getTasks(),
        getProjects(),
        getTeamMembers(),
      ]);
      const found = taskData.find((item) => item.id === taskId) ?? null;
      setTask(found);
      setProject(found ? (projectData.find((item) => item.id === found.projectId) ?? null) : null);
      setMembers(memberData);
      setErrorMessage('');
    } catch {
      setErrorMessage('Could not load this task. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [taskId]);

  useRefreshOnFocus(loadData);

  const goBack = () => navigation.goBack();

  const applyChanges = async (changes: Partial<Task>) => {
    if (!task) {
      return;
    }
    const previous = task;
    setTask({ ...task, ...changes });
    try {
      const saved = await updateTask(task.id, changes);
      setTask(saved);
      setErrorMessage('');
    } catch {
      setTask(previous);
      setErrorMessage('Could not save your change. Please try again.');
    }
  };

  const handleDelete = () => {
    if (!task) {
      return;
    }
    confirmAction('Delete task', `Delete "${task.title}"? This cannot be undone.`, 'Delete', async () => {
      try {
        await deleteTask(task.id);
        Toast.show({ type: 'success', text1: 'Task deleted' });
        goBack();
      } catch {
        setErrorMessage('Could not delete the task. Please try again.');
      }
    });
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safe}>
        <HeaderBar title="Task" onBack={goBack} />
        <LoadingState label="Loading task…" />
      </SafeAreaView>
    );
  }

  if (!task) {
    return (
      <SafeAreaView style={styles.safe}>
        <HeaderBar title="Task" onBack={goBack} />
        <EmptyState
          icon="alert-circle-outline"
          title="Task not found"
          message={errorMessage || 'This task may have been deleted.'}
          actionLabel="Go back"
          onAction={goBack}
        />
      </SafeAreaView>
    );
  }

  const projectMembers = members.filter((member) => project?.memberIds.includes(member.id));
  const overdue = isOverdue(task.dueDate, task.status === 'Done');

  return (
    <SafeAreaView style={styles.safe}>
      <HeaderBar
        title="Task details"
        onBack={goBack}
        rightIcon="create-outline"
        rightLabel="Edit task"
        onRightPress={() => navigation.navigate('CreateTask', { taskId: task.id })}
      />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {errorMessage ? <ErrorMessage message={errorMessage} /> : null}

        <View style={styles.card}>
          <Text style={styles.projectName}>{project?.name ?? 'Unknown project'}</Text>
          <Text style={styles.title}>{task.title}</Text>
          <Text style={styles.description}>{task.description || 'No description provided.'}</Text>
          <View style={styles.dueRow}>
            <Ionicons
              name="calendar-outline"
              size={16}
              color={overdue ? colors.error : colors.textDisabled}
            />
            <Text style={[styles.dueText, overdue && styles.overdue]}>
              Due {formatDate(task.dueDate)}
              {overdue ? ' · Overdue' : ''}
            </Text>
          </View>
        </View>

        <Text style={styles.sectionLabel}>Status</Text>
        <ChipSelector<TaskStatus>
          options={TASK_STATUSES}
          selected={task.status}
          onSelect={(status) => {
            if (status) {
              applyChanges({ status });
            }
          }}
        />

        <Text style={styles.sectionLabel}>Priority</Text>
        <ChipSelector<TaskPriority>
          options={TASK_PRIORITIES}
          selected={task.priority}
          onSelect={(priority) => {
            if (priority) {
              applyChanges({ priority });
            }
          }}
        />

        <Text style={styles.sectionLabel}>Assignee</Text>
        <View style={styles.card}>
          <Pressable
            onPress={() => applyChanges({ assigneeId: null })}
            accessibilityRole="radio"
            accessibilityState={{ selected: task.assigneeId === null }}
            android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
            style={({ pressed }) => [styles.assigneeRow, pressed && Platform.OS === 'ios' && styles.pressed]}
          >
            <View style={styles.unassignedIcon}>
              <Ionicons name="person-outline" size={20} color={colors.textDisabled} />
            </View>
            <Text style={styles.unassignedName}>Unassigned</Text>
            {task.assigneeId === null ? <Ionicons name="checkmark" size={20} color={colors.primary} /> : null}
          </Pressable>
          {projectMembers.map((member) => (
            <Pressable
              key={member.id}
              onPress={() => applyChanges({ assigneeId: member.id })}
              accessibilityRole="radio"
              accessibilityState={{ selected: task.assigneeId === member.id }}
              android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
              style={({ pressed }) => [styles.assigneeRow, pressed && Platform.OS === 'ios' && styles.pressed]}
            >
              <Avatar name={member.name} size={40} />
              <View style={styles.assigneeText}>
                <Text style={styles.assigneeName}>{member.name}</Text>
                <Text style={styles.caption}>{member.role}</Text>
              </View>
              {task.assigneeId === member.id ? (
                <Ionicons name="checkmark" size={20} color={colors.primary} />
              ) : null}
            </Pressable>
          ))}
        </View>

        <View style={styles.deleteWrap}>
          <PrimaryButton label="Delete task" variant="danger" onPress={handleDelete} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

export default TaskDetailScreen;

const styles = StyleSheet.create({
  safe: {
    ...screenRoot,
  },
  content: {
    padding: s(4),
    paddingBottom: s(12),
  },
  card: {
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    ...cardShadow,
  },
  projectName: {
    ...typography.label,
  },
  title: {
    ...typography.heading2,
    marginTop: s(1),
  },
  description: {
    ...typography.body,
    color: colors.textSecondary,
    marginTop: s(2),
  },
  dueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: s(3),
  },
  dueText: {
    ...typography.captionStrong,
    marginLeft: s(2),
  },
  overdue: {
    color: colors.error,
  },
  sectionLabel: {
    ...typography.label,
    marginTop: s(5),
    marginBottom: s(2),
  },
  assigneeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: s(14),
    paddingVertical: s(1),
  },
  pressed: {
    opacity: 0.6,
  },
  unassignedIcon: {
    width: s(10),
    height: s(10),
    borderRadius: s(5),
    backgroundColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  assigneeText: {
    flex: 1,
    marginLeft: s(3),
  },
  assigneeName: {
    ...typography.bodyStrong,
  },
  unassignedName: {
    ...typography.bodyStrong,
    flex: 1,
    marginLeft: s(3),
  },
  caption: {
    ...typography.caption,
  },
  deleteWrap: {
    marginTop: s(6),
  },
});
