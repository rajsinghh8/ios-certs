import React from 'react';
import { render } from '@testing-library/react-native';
import { NavigationContainer } from '@react-navigation/native';
import { ProjectDetailScreen } from './ProjectDetailScreen';

test('renders without crashing', () => {
  render(
    <NavigationContainer>
      <ProjectDetailScreen route={{ params: { projectId: 'p1' } } as any} />
    </NavigationContainer>,
  );
});
