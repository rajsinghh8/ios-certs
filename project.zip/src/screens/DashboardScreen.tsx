import React, { useCallback, useState } from 'react';
import { FlatList, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useFocusEffect } from '@react-navigation/native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import HeaderBar from '../components/HeaderBar';
import InfoCard from '../components/InfoCard';
import { Appointment, StaffMember } from '../types';
import { getAppointments, getStaff } from '../data/store';

export default function DashboardScreen() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);

  useFocusEffect(useCallback(() => {
    let active = true;
    Promise.all([getAppointments(), getStaff()]).then(([a, st]) => {
      if (active) {
        setAppointments(a);
        setStaff(st);
      }
    });
    return () => { active = false; };
  }, []));

  const completed = appointments.filter((a) => a.status === 'completed').length;
  const noShows = appointments.filter((a) => a.status === 'no_show').length;
  const confirmed = appointments.filter((a) => a.status === 'confirmed').length;
  const busy = staff.map((member) => ({
    id: member.id,
    title: member.name,
    subtitle: `${appointments.filter((a) => a.staffId === member.id && a.status !== 'cancelled').length} active or finished bookings`,
    meta: member.locationId,
  }));

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Dashboard" subtitle="Recent appointment activity" />
      <View style={styles.statsRow}>
        <View style={styles.stat}><Text style={styles.statValue}>{completed}</Text><Text style={styles.statLabel}>Completed</Text></View>
        <View style={styles.stat}><Text style={styles.statValue}>{noShows}</Text><Text style={styles.statLabel}>No-shows</Text></View>
        <View style={styles.stat}><Text style={styles.statValue}>{confirmed}</Text><Text style={styles.statLabel}>Upcoming</Text></View>
      </View>
      <FlatList
        style={styles.list}
        contentContainerStyle={styles.listContent}
        data={busy}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <InfoCard title={item.title} subtitle={item.subtitle} meta="Staff utilization" icon="stats-chart-outline" />}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
        ListHeaderComponent={<Text style={styles.sectionTitle}>Busy staff</Text>}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}) },
  statsRow: { flexDirection: 'row', padding: s(4), gap: s(3) },
  stat: { flex: 1, minHeight: s(22), borderRadius: s(3), padding: s(3), backgroundColor: colors.card, justifyContent: 'center', ...Platform.select({ ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 6 }, android: { elevation: 4 }, default: {} }) },
  statValue: { fontFamily: 'Inter-Bold', fontSize: 28, lineHeight: 34, fontWeight: '700', letterSpacing: -0.5, color: colors.primary },
  statLabel: { marginTop: s(1), fontFamily: 'Inter-Medium', fontSize: 12, lineHeight: 17, fontWeight: '500', letterSpacing: 0.2, color: colors.textSecondary },
  list: { flex: 1 },
  listContent: { paddingHorizontal: s(4), paddingBottom: s(6) },
  sectionTitle: { marginBottom: s(3), fontFamily: 'Inter-Bold', fontSize: 18, lineHeight: 22, fontWeight: '700', letterSpacing: -0.5, color: colors.textPrimary },
  separator: { height: StyleSheet.hairlineWidth, backgroundColor: colors.border },
});
