import React, { useCallback, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { TabScreenNavigation } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { screenRoot } from '../theme/layout';
import { cardShadow } from '../theme/shadows';
import { useRefreshOnFocus } from '../hooks/useRefreshOnFocus';
import { Activity, Project, Task, TeamMember } from '../types';
import { getActivities, getProjects, getSession, getTasks, getTeamMembers } from '../data/store';
import { TASK_PRIORITIES, TASK_STATUSES } from '../constants';
import { getProjectProgress } from '../utils/progress';
import { formatRelativeTime } from '../utils/format';
import { KpiCard } from '../components/KpiCard';
import { ProgressBar } from '../components/ProgressBar';
import { getBadgeColor } from '../components/Badge';
import { Avatar } from '../components/Avatar';
import { LoadingState } from '../components/LoadingState';
import { ErrorMessage } from '../components/ErrorMessage';

export function DashboardScreen() {
  const navigation = useNavigation<TabScreenNavigation>();
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [projects, setProjects] = useState<Project[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [userName, setUserName] = useState('');

  const loadData = useCallback(async () => {
    try {
      const [projectData, taskData, memberData, activityData, session] = await Promise.all([
        getProjects(),
        getTasks(),
        getTeamMembers(),
        getActivities(),
        getSession(),
      ]);
      setProjects(projectData);
      setTasks(taskData);
      setMembers(memberData);
      setActivities(activityData);
      setUserName(session?.name ?? '');
      setErrorMessage('');
    } catch {
      setErrorMessage('Could not load the dashboard. Pull to retry by reopening this tab.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useRefreshOnFocus(loadData);

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safe}>
        <LoadingState label="Loading dashboard…" />
      </SafeAreaView>
    );
  }

  const activeTasks = tasks.filter((task) => task.status !== 'Done').length;
  const doneTasks = tasks.filter((task) => task.status === 'Done').length;
  const completionRate = tasks.length === 0 ? 0 : Math.round((doneTasks / tasks.length) * 100);
  const overdueTasks = tasks.filter(
    (task) => task.status !== 'Done' && new Date(task.dueDate).getTime() < Date.now(),
  ).length;
  const projectNameById = (projectId: string) =>
    projects.find((project) => project.id === projectId)?.name ?? 'Unknown project';

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.greeting}>{userName ? `Hello, ${userName.split(' ')[0]}` : 'Hello'}</Text>
        <Text style={styles.heading}>Dashboard</Text>

        {errorMessage ? <ErrorMessage message={errorMessage} /> : null}

        <View style={styles.kpiRow}>
          <KpiCard icon="folder" label="Projects" value={String(projects.length)} tint={colors.primary} />
          <KpiCard icon="list" label="Active tasks" value={String(activeTasks)} tint={colors.warning} />
        </View>
        <View style={styles.kpiRow}>
          <KpiCard icon="checkmark-circle" label="Completion" value={`${completionRate}%`} tint={colors.success} />
          <KpiCard icon="people" label="Team size" value={String(members.length)} tint={colors.accent} />
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Task statistics</Text>
          <Text style={styles.sectionLabel}>By status</Text>
          {TASK_STATUSES.map((status) => {
            const count = tasks.filter((task) => task.status === status).length;
            return (
              <View key={status} style={styles.statRow}>
                <Text style={styles.statLabel}>{status}</Text>
                <View style={styles.statBar}>
                  <ProgressBar
                    percent={tasks.length === 0 ? 0 : (count / tasks.length) * 100}
                    color={getBadgeColor(status)}
                  />
                </View>
                <Text style={styles.statCount}>{count}</Text>
              </View>
            );
          })}
          <Text style={[styles.sectionLabel, styles.sectionGap]}>By priority</Text>
          {TASK_PRIORITIES.map((priority) => {
            const count = tasks.filter((task) => task.priority === priority).length;
            return (
              <View key={priority} style={styles.statRow}>
                <Text style={styles.statLabel}>{priority}</Text>
                <View style={styles.statBar}>
                  <ProgressBar
                    percent={tasks.length === 0 ? 0 : (count / tasks.length) * 100}
                    color={getBadgeColor(priority)}
                  />
                </View>
                <Text style={styles.statCount}>{count}</Text>
              </View>
            );
          })}
          {overdueTasks > 0 ? (
            <Text style={styles.overdue}>
              {overdueTasks} overdue {overdueTasks === 1 ? 'task needs' : 'tasks need'} attention
            </Text>
          ) : null}
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Project progress</Text>
            <Pressable
              onPress={() => navigation.navigate('Projects')}
              accessibilityRole="link"
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <Text style={styles.link}>View all</Text>
            </Pressable>
          </View>
          {projects.map((project) => {
            const percent = getProjectProgress(tasks, project.id);
            return (
              <Pressable
                key={project.id}
                onPress={() => navigation.navigate('ProjectDetail', { projectId: project.id })}
                accessibilityRole="button"
                accessibilityLabel={`${project.name}, ${percent}% complete`}
                android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
                style={styles.projectRow}
              >
                <View style={styles.projectHeader}>
                  <Text style={styles.projectName} numberOfLines={1}>
                    {project.name}
                  </Text>
                  <Text style={styles.statCount}>{percent}%</Text>
                </View>
                <ProgressBar percent={percent} />
              </Pressable>
            );
          })}
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Recent activity</Text>
          {activities.length === 0 ? (
            <Text style={styles.emptyText}>No activity yet.</Text>
          ) : (
            activities.map((activity) => (
              <View key={activity.id} style={styles.activityRow}>
                <Avatar name={activity.userName} size={32} />
                <View style={styles.activityText}>
                  <Text style={styles.activityMessage}>
                    <Text style={styles.activityUser}>{activity.userName} </Text>
                    {activity.description}
                  </Text>
                  <Text style={styles.caption}>
                    {projectNameById(activity.projectId)} · {formatRelativeTime(activity.timestamp)}
                  </Text>
                </View>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

export default DashboardScreen;

const styles = StyleSheet.create({
  safe: {
    ...screenRoot,
  },
  content: {
    padding: s(4),
    paddingBottom: s(8),
  },
  greeting: {
    ...typography.caption,
  },
  heading: {
    ...typography.heading1,
    marginBottom: s(4),
  },
  kpiRow: {
    flexDirection: 'row',
    gap: s(3),
    marginBottom: s(3),
  },
  card: {
    padding: s(4),
    marginTop: s(3),
    borderRadius: s(3),
    backgroundColor: colors.card,
    ...cardShadow,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  cardTitle: {
    ...typography.heading3,
    marginBottom: s(3),
  },
  link: {
    ...typography.captionStrong,
    color: colors.primary,
    marginBottom: s(3),
  },
  sectionLabel: {
    ...typography.label,
    marginBottom: s(2),
  },
  sectionGap: {
    marginTop: s(4),
  },
  statRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: s(2),
  },
  statLabel: {
    ...typography.caption,
    width: s(22),
  },
  statBar: {
    flex: 1,
  },
  statCount: {
    ...typography.captionStrong,
    width: s(8),
    textAlign: 'right',
  },
  overdue: {
    ...typography.captionStrong,
    color: colors.error,
    marginTop: s(3),
  },
  projectRow: {
    paddingVertical: s(2),
  },
  projectHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: s(1),
  },
  projectName: {
    ...typography.body,
    flex: 1,
  },
  activityRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: s(3),
  },
  activityText: {
    flex: 1,
    marginLeft: s(3),
  },
  activityMessage: {
    ...typography.body,
  },
  activityUser: {
    ...typography.bodyStrong,
  },
  caption: {
    ...typography.caption,
  },
  emptyText: {
    ...typography.body,
    color: colors.textDisabled,
  },
});
