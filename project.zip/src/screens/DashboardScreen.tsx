import React, { useCallback, useState } from 'react';
import { FlatList, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { HeaderBar } from '../components/HeaderBar';
import { MetricCard } from '../components/MetricCard';
import { TaskCard } from '../components/TaskCard';
import { productivityMetrics } from '../data/mockData';
import { getTasks, updateTask } from '../data/store';
import { RootStackParamList } from '../navigation';
import { TaskItem } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function DashboardScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const [tasks, setTasks] = useState<TaskItem[]>([]);

  const loadTasks = useCallback(() => {
    let active = true;
    getTasks().then((items) => {
      if (active) setTasks(items);
    });
    return () => {
      active = false;
    };
  }, []);

  useFocusEffect(loadTasks);

  const today = new Date().toISOString().slice(0, 10);
  const todayTasks = tasks.filter((task) => task.dueDate === today && task.status !== 'done').slice(0, 4);
  const completedCount = tasks.filter((task) => task.status === 'done').length;
  const completionPercent = tasks.length ? Math.round((completedCount / tasks.length) * 100) : 0;

  const toggleTask = async (task: TaskItem) => {
    const nextStatus = task.status === 'done' ? 'todo' : 'done';
    setTasks((prev) => prev.map((item) => (item.id === task.id ? { ...item, status: nextStatus } : item)));
    await updateTask(task.id, { status: nextStatus });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Today" subtitle="A calm place to finish important work" rightLabel="New" onRightPress={() => navigation.navigate('TaskForm', {})} />
      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.heroCard}>
          <View style={styles.heroTextGroup}>
            <Text style={styles.eyebrow}>DAILY PROGRESS</Text>
            <Text style={styles.heroTitle}>{completionPercent}% complete</Text>
            <Text style={styles.heroBody}>Finish one focused task at a time. Your list updates as you complete work.</Text>
          </View>
          <View style={styles.heroIcon}>
            <Ionicons name="flash-outline" size={s(8)} color={colors.textInverse} />
          </View>
        </View>
        <Text style={styles.sectionTitle}>Insights</Text>
        <ScrollView horizontal directionalLockEnabled decelerationRate="fast" showsHorizontalScrollIndicator={false} contentContainerStyle={styles.metricsRow}>
          {productivityMetrics.map((metric) => (
            <MetricCard key={metric.id} metric={metric} />
          ))}
        </ScrollView>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Due today</Text>
          <Pressable
            onPress={() => navigation.navigate('MainTabs', { screen: 'Tasks' })}
            android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
            style={({ pressed }) => [styles.linkButton, pressed && Platform.OS === 'ios' && styles.pressed]}
          >
            <Text style={styles.linkText}>View all</Text>
          </Pressable>
        </View>
        <FlatList
          data={todayTasks}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <TaskCard task={item} onPress={() => navigation.navigate('TaskDetail', { id: item.id })} onToggle={() => toggleTask(item)} />}
          ItemSeparatorComponent={() => <View style={styles.listSeparator} />}
          scrollEnabled={false}
          showsVerticalScrollIndicator={false}
          removeClippedSubviews={Platform.OS === 'android'}
          initialNumToRender={10}
          maxToRenderPerBatch={10}
          windowSize={5}
          ListEmptyComponent={<Text style={styles.emptyText}>No open tasks due today. Add one or enjoy the space.</Text>}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: s(4),
    paddingBottom: s(8),
  },
  heroCard: {
    minHeight: s(44),
    borderRadius: s(4),
    padding: s(5),
    backgroundColor: colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: s(6),
    ...Platform.select({
      ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(2) }, shadowOpacity: 0.14, shadowRadius: s(3) },
      android: { elevation: 8 },
      default: {},
    }),
  },
  heroTextGroup: {
    flex: 1,
    paddingRight: s(4),
  },
  eyebrow: {
    fontFamily: 'Inter-Bold',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '700',
    letterSpacing: 1.2,
    color: colors.primaryLight,
  },
  heroTitle: {
    marginTop: s(2),
    fontFamily: 'Inter-Bold',
    fontSize: s(8),
    lineHeight: 38.4,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textInverse,
  },
  heroBody: {
    marginTop: s(2),
    fontFamily: 'Inter-Regular',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textInverse,
  },
  heroIcon: {
    width: s(16),
    height: s(16),
    borderRadius: s(8),
    backgroundColor: colors.primaryDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectionHeader: {
    minHeight: s(12),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: s(6),
    marginBottom: s(3),
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: s(5),
    lineHeight: 24,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
    marginBottom: s(3),
  },
  metricsRow: {
    paddingRight: s(1),
  },
  linkButton: {
    minHeight: s(9),
    paddingHorizontal: s(3),
    borderRadius: s(2),
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressed: {
    opacity: 0.7,
  },
  linkText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.primary,
  },
  listSeparator: {
    height: s(3),
  },
  emptyText: {
    fontFamily: 'Inter-Regular',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    textAlign: 'center',
    paddingVertical: s(6),
  },
});
