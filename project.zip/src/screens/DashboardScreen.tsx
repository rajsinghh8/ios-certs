import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { HeaderBar } from '../components/HeaderBar';
import { InfoCard } from '../components/InfoCard';
import { logout, getAppointments, getLocations, getServices, getStaff } from '../data/store';
import { RootStackParamList } from '../navigation';
import { Appointment, Location, Service, StaffMember } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type Props = { navigation: NativeStackNavigationProp<RootStackParamList, 'MainTabs'> };

export default function DashboardScreen({ navigation }: Props) {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [services, setServices] = useState<Service[]>([]);

  useEffect(() => { Promise.all([getAppointments(), getStaff(), getLocations(), getServices()]).then(([a, st, l, sv]) => { setAppointments(a); setStaff(st); setLocations(l); setServices(sv); }); }, []);

  const stats = useMemo(() => {
    const recentCutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
    return {
      recent: appointments.filter((item) => new Date(`${item.date}T${item.endTime}:00`).getTime() > recentCutoff).length,
      noShows: appointments.filter((item) => item.status === 'noShow').length,
      completed: appointments.filter((item) => item.status === 'completed').length,
    };
  }, [appointments]);

  const staffBusy = useMemo(() => staff.map((person) => ({ ...person, count: appointments.filter((appt) => appt.staffId === person.id && appt.status !== 'cancelled').length })).sort((a, b) => b.count - a.count), [appointments, staff]);

  const signOut = async () => {
    await logout();
    navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Dashboard" subtitle="Recent activity and staff utilization" rightLabel="Logout" onRightPress={signOut} />
      <View style={styles.statsRow}>
        <View style={styles.stat}><Text style={styles.statValue}>{stats.recent}</Text><Text style={styles.statLabel}>Recent</Text></View>
        <View style={styles.stat}><Text style={styles.statValue}>{stats.completed}</Text><Text style={styles.statLabel}>Completed</Text></View>
        <View style={styles.stat}><Text style={styles.statValue}>{stats.noShows}</Text><Text style={styles.statLabel}>No-shows</Text></View>
      </View>
      <Text style={styles.heading}>Business setup</Text>
      <View style={styles.summary}><Text style={styles.summaryText}>{locations.length} locations · {services.length} services · {staff.length} staff members</Text></View>
      <Text style={styles.heading}>Staff workload</Text>
      <FlatList
        data={staffBusy}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <InfoCard title={item.name} subtitle={item.title} meta={`${item.count} appointments on record`} icon="people-outline" />}
        contentContainerStyle={styles.list}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  statsRow: { flexDirection: 'row', padding: s(4), paddingBottom: s(2) },
  stat: { flex: 1, minHeight: s(20), borderRadius: s(3), backgroundColor: colors.primary, marginRight: s(2), alignItems: 'center', justifyContent: 'center', padding: s(3) },
  statValue: { fontFamily: 'Inter-Bold', fontSize: s(7), lineHeight: s(7) * 1.2, fontWeight: '700', letterSpacing: -0.5, color: colors.textInverse },
  statLabel: { fontFamily: 'Inter-Medium', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '500', letterSpacing: 0.2, color: colors.textInverse, marginTop: s(1) },
  heading: { fontFamily: 'Inter-Bold', fontSize: s(5), lineHeight: s(5) * 1.2, fontWeight: '700', letterSpacing: -0.5, color: colors.textPrimary, marginHorizontal: s(4), marginTop: s(4), marginBottom: s(2) },
  summary: { marginHorizontal: s(4), borderRadius: s(3), padding: s(4), backgroundColor: colors.primaryLight },
  summaryText: { fontFamily: 'Inter-SemiBold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '600', letterSpacing: 0.2, color: colors.primaryDark },
  list: { padding: s(4), paddingBottom: s(8) },
  separator: { height: s(3) },
});
