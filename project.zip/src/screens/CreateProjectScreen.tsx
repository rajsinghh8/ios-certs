import React, { useEffect, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Toast from 'react-native-toast-message';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { screenRoot } from '../theme/layout';
import { Project, ProjectStatus, TeamMember } from '../types';
import { createProject, getProjects, getSession, getTeamMembers, updateProject } from '../data/store';
import { PROJECT_STATUSES } from '../constants';
import { validateDate, validateMinLength } from '../validation';
import { toDateInput } from '../utils/format';
import { HeaderBar } from '../components/HeaderBar';
import { TextField } from '../components/TextField';
import { ChipSelector } from '../components/ChipSelector';
import { PrimaryButton } from '../components/PrimaryButton';
import { ErrorMessage } from '../components/ErrorMessage';
import { LoadingState } from '../components/LoadingState';

interface CreateProjectScreenProps {
  route?: { params?: { projectId?: string } };
}

const addDays = (days: number): string =>
  new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

export function CreateProjectScreen({ route }: CreateProjectScreenProps) {
  const editingId = route?.params?.projectId;
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'CreateProject'>>();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [existing, setExisting] = useState<Project | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<ProjectStatus>('Planning');
  const [startDate, setStartDate] = useState(addDays(0));
  const [endDate, setEndDate] = useState(addDays(30));
  const [memberIds, setMemberIds] = useState<string[]>([]);

  useEffect(() => {
    const load = async () => {
      try {
        const [memberData, projectData] = await Promise.all([getTeamMembers(), getProjects()]);
        setMembers(memberData);
        const found = editingId ? projectData.find((item) => item.id === editingId) : undefined;
        if (found) {
          setExisting(found);
          setName(found.name);
          setDescription(found.description);
          setStatus(found.status);
          setStartDate(toDateInput(found.startDate));
          setEndDate(toDateInput(found.endDate));
          setMemberIds(found.memberIds);
        }
      } catch {
        setSubmitError('Could not load form data. Please close and try again.');
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [editingId]);

  const nameError = validateMinLength(name, 'Project name', 3);
  const descriptionError = description.trim().length === 0 ? 'Description is required' : '';
  const startError = validateDate(startDate, 'Start date');
  const endError =
    validateDate(endDate, 'End date') ||
    (startError === '' && endDate < startDate ? 'End date must be on or after the start date' : '');
  const isValid = nameError === '' && descriptionError === '' && startError === '' && endError === '';

  const toggleMember = (memberId: string) => {
    setMemberIds((previous) =>
      previous.includes(memberId) ? previous.filter((id) => id !== memberId) : [...previous, memberId],
    );
  };

  const handleSave = async () => {
    setHasSubmitted(true);
    if (!isValid) {
      return;
    }
    setIsSaving(true);
    setSubmitError('');
    try {
      const values = {
        name: name.trim(),
        description: description.trim(),
        status,
        startDate: new Date(startDate).toISOString(),
        endDate: new Date(endDate).toISOString(),
        memberIds,
      };
      if (existing) {
        await updateProject(existing.id, values);
      } else {
        const session = await getSession();
        await createProject({ ...values, ownerId: session?.userId ?? 'u1' }); // MOCK: fallback owner when no session.
      }
      Toast.show({ type: 'success', text1: existing ? 'Project updated' : 'Project created' });
      navigation.goBack();
    } catch {
      setSubmitError('Could not save the project. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <HeaderBar
        title={existing ? 'Edit project' : 'New project'}
        onBack={() => navigation.goBack()}
      />
      {isLoading ? (
        <LoadingState />
      ) : (
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
        >
          <ScrollView
            contentContainerStyle={styles.content}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {submitError ? <ErrorMessage message={submitError} /> : null}
            <TextField
              label="Project name"
              value={name}
              onChangeText={setName}
              placeholder="e.g. Website relaunch"
              helper="At least 3 characters"
              error={hasSubmitted ? nameError : ''}
            />
            <TextField
              label="Description"
              value={description}
              onChangeText={setDescription}
              placeholder="What is this project about?"
              multiline
              error={hasSubmitted ? descriptionError : ''}
            />
            <Text style={styles.label}>Status</Text>
            <View style={styles.group}>
              <ChipSelector
                options={PROJECT_STATUSES}
                selected={status}
                onSelect={(value) => setStatus(value ?? 'Planning')}
              />
            </View>
            <TextField
              label="Start date"
              value={startDate}
              onChangeText={setStartDate}
              placeholder="YYYY-MM-DD"
              helper="Format: YYYY-MM-DD"
              error={hasSubmitted ? startError : ''}
            />
            <TextField
              label="End date"
              value={endDate}
              onChangeText={setEndDate}
              placeholder="YYYY-MM-DD"
              helper="Format: YYYY-MM-DD"
              error={hasSubmitted ? endError : ''}
            />
            <Text style={styles.label}>Team members</Text>
            <View style={styles.memberWrap}>
              {members.map((member) => {
                const isSelected = memberIds.includes(member.id);
                return (
                  <Pressable
                    key={member.id}
                    onPress={() => toggleMember(member.id)}
                    accessibilityRole="checkbox"
                    accessibilityState={{ checked: isSelected }}
                    android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
                    style={({ pressed }) => [
                      styles.memberChip,
                      isSelected && styles.memberChipActive,
                      pressed && Platform.OS === 'ios' && styles.pressed,
                    ]}
                  >
                    <Text style={[styles.memberText, isSelected && styles.memberTextActive]}>
                      {member.name}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
            <PrimaryButton
              label={existing ? 'Save changes' : 'Create project'}
              onPress={handleSave}
              loading={isSaving}
              disabled={!isValid}
            />
            <View style={styles.gap} />
            <PrimaryButton label="Cancel" variant="secondary" onPress={() => navigation.goBack()} />
          </ScrollView>
        </KeyboardAvoidingView>
      )}
    </SafeAreaView>
  );
}

export default CreateProjectScreen;

const styles = StyleSheet.create({
  safe: {
    ...screenRoot,
  },
  flex: {
    flex: 1,
  },
  content: {
    padding: s(4),
    paddingBottom: s(12),
  },
  label: {
    ...typography.captionStrong,
    marginBottom: s(1),
  },
  group: {
    marginBottom: s(4),
  },
  memberWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: s(2),
    marginTop: s(1),
    marginBottom: s(6),
  },
  memberChip: {
    minHeight: s(9),
    paddingHorizontal: s(4),
    borderRadius: s(5),
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  memberChipActive: {
    backgroundColor: colors.primaryLight,
    borderColor: colors.primary,
  },
  pressed: {
    opacity: 0.7,
  },
  memberText: {
    ...typography.captionStrong,
  },
  memberTextActive: {
    color: colors.primary,
  },
  gap: {
    height: s(3),
  },
});
