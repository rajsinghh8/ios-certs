import React from 'react';
import { render } from '@testing-library/react-native';
import { NavigationContainer } from '@react-navigation/native';
import { ForgotPasswordScreen } from './ForgotPasswordScreen';

test('renders without crashing', () => {
  render(
    <NavigationContainer>
      <ForgotPasswordScreen />
    </NavigationContainer>,
  );
});
