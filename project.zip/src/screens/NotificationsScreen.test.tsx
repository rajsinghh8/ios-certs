import React from 'react';
import { render } from '@testing-library/react-native';
import { NavigationContainer } from '@react-navigation/native';
import { NotificationsScreen } from './NotificationsScreen';

test('renders without crashing', () => {
  render(
    <NavigationContainer>
      <NotificationsScreen />
    </NavigationContainer>,
  );
});
