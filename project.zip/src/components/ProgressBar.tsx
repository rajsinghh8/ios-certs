import React from 'react';
import { StyleSheet, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface ProgressBarProps {
  percent: number;
  color?: string;
}

export function ProgressBar({ percent, color = colors.primary }: ProgressBarProps) {
  const clamped = Math.max(0, Math.min(100, percent));
  return (
    <View
      style={styles.track}
      accessibilityRole="progressbar"
      accessibilityValue={{ min: 0, max: 100, now: clamped }}
    >
      <View style={[styles.fill, { width: `${clamped}%`, backgroundColor: color }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  track: {
    height: s(2),
    borderRadius: s(1),
    backgroundColor: colors.border,
    overflow: 'hidden',
  },
  fill: {
    height: s(2),
    borderRadius: s(1),
  },
});
