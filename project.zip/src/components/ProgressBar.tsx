import React from 'react';
import { StyleSheet, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface ProgressBarProps {
  value: number;
}

export function ProgressBar({ value }: ProgressBarProps) {
  return <View style={styles.track}><View style={[styles.fill, { width: `${value}%` }]} /></View>;
}

const styles = StyleSheet.create({
  track: { height: s(2), borderRadius: s(1), backgroundColor: colors.border, overflow: 'hidden' },
  fill: { height: s(2), borderRadius: s(1), backgroundColor: colors.primary },
});
