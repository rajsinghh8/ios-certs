import React from 'react';
import { Platform, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface FloatingButtonProps {
  onPress: () => void;
  accessibilityLabel: string;
}

export function FloatingButton({ onPress, accessibilityLabel }: FloatingButtonProps) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      android_ripple={{ color: 'rgba(255,255,255,0.3)', borderless: true }}
      style={({ pressed }) => [styles.button, pressed && Platform.OS === 'ios' && styles.pressed]}
    >
      <Ionicons name="add" size={28} color={colors.textInverse} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    position: 'absolute',
    right: s(4),
    bottom: s(4),
    width: s(14),
    height: s(14),
    borderRadius: s(7),
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 8,
      },
      android: { elevation: 8 },
      default: {},
    }),
  },
  pressed: {
    opacity: 0.8,
  },
});
