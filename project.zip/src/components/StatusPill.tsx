import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface StatusPillProps {
  label: string;
  tone: 'success' | 'warning' | 'info' | 'neutral';
}

export function StatusPill({ label, tone }: StatusPillProps) {
  const color = tone === 'success' ? colors.success : tone === 'warning' ? colors.warning : tone === 'info' ? colors.info : colors.textSecondary;
  return <View style={[styles.pill, { borderColor: color }]}><Text style={[styles.text, { color }]}>{label}</Text></View>;
}

const styles = StyleSheet.create({
  pill: { alignSelf: 'flex-start', borderWidth: StyleSheet.hairlineWidth, borderRadius: s(3), paddingHorizontal: s(2), paddingVertical: s(1), backgroundColor: colors.surface },
  text: { fontFamily: 'Inter-SemiBold', fontSize: s(2.5), lineHeight: s(3.5), letterSpacing: 0.2 },
});
