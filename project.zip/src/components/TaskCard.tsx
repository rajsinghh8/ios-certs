import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TaskItem } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface TaskCardProps {
  task: TaskItem;
  onPress: () => void;
  onToggle: () => void;
}

const priorityColor = (priority: TaskItem['priority']) => {
  if (priority === 'high') return colors.error;
  if (priority === 'medium') return colors.warning;
  return colors.success;
};

const statusLabel = (status: TaskItem['status']) => {
  if (status === 'inProgress') return 'In progress';
  if (status === 'done') return 'Done';
  return 'To do';
};

export function TaskCard({ task, onPress, onToggle }: TaskCardProps) {
  const complete = task.status === 'done';
  return (
    <View style={styles.outer}>
      <Pressable
        onPress={onPress}
        android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
        style={({ pressed }) => [StyleSheet.absoluteFillObject, pressed && Platform.OS === 'ios' && styles.primaryPressed]}
      />
      <View pointerEvents="none" style={styles.content}>
        <View style={[styles.checkCircle, complete && styles.checkCircleDone]}>
          <Ionicons name={complete ? 'checkmark' : 'ellipse-outline'} size={s(5)} color={complete ? colors.textInverse : colors.textDisabled} />
        </View>
        <View style={styles.body}>
          <Text style={[styles.title, complete && styles.titleDone]} numberOfLines={1}>{task.title}</Text>
          <Text style={styles.description} numberOfLines={2}>{task.description}</Text>
          <View style={styles.metaRow}>
            <View style={[styles.priorityDot, { backgroundColor: priorityColor(task.priority) }]} />
            <Text style={styles.metaText}>{task.priority.toUpperCase()}</Text>
            <Text style={styles.metaText}>{task.dueDate}</Text>
            <Text style={styles.statusText}>{statusLabel(task.status)}</Text>
          </View>
        </View>
      </View>
      <Pressable
        onPress={onToggle}
        hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }}
        android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
        style={({ pressed }) => [styles.toggleButton, pressed && Platform.OS === 'ios' && styles.secondaryPressed]}
      >
        <Ionicons name={complete ? 'refresh-outline' : 'checkmark-circle-outline'} size={s(6)} color={complete ? colors.textSecondary : colors.primary} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  outer: {
    minHeight: s(30),
    borderRadius: s(3),
    backgroundColor: colors.card,
    overflow: 'hidden',
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: s(1) },
        shadowOpacity: 0.1,
        shadowRadius: s(2),
      },
      android: { elevation: 4 },
      default: {},
    }),
  },
  primaryPressed: {
    opacity: 0.92,
  },
  secondaryPressed: {
    opacity: 0.7,
  },
  content: {
    flex: 1,
    minHeight: s(30),
    flexDirection: 'row',
    padding: s(4),
    paddingRight: s(14),
  },
  checkCircle: {
    width: s(10),
    height: s(10),
    borderRadius: s(5),
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: s(3),
  },
  checkCircleDone: {
    backgroundColor: colors.success,
  },
  body: {
    flex: 1,
  },
  title: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
  },
  titleDone: {
    color: colors.textDisabled,
    textDecorationLine: 'line-through',
  },
  description: {
    marginTop: s(1),
    fontFamily: 'Inter-Regular',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  metaRow: {
    marginTop: s(3),
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  priorityDot: {
    width: s(2),
    height: s(2),
    borderRadius: s(1),
    marginRight: s(1),
  },
  metaText: {
    marginRight: s(3),
    fontFamily: 'Inter-Bold',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '700',
    letterSpacing: 1.2,
    color: colors.textSecondary,
  },
  statusText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.primary,
  },
  toggleButton: {
    position: 'absolute',
    top: s(4),
    right: s(4),
    width: s(10),
    height: s(10),
    borderRadius: s(5),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surface,
  },
});
