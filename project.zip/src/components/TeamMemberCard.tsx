import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { cardShadow } from '../theme/shadows';
import { Availability, TeamMember } from '../types';
import { Avatar } from './Avatar';

const AVAILABILITY_COLORS: Record<Availability, string> = {
  Available: colors.success,
  Busy: colors.error,
  Away: colors.warning,
};

interface TeamMemberCardProps {
  member: TeamMember;
  assignedTaskCount: number;
  onRemove?: () => void;
}

export function TeamMemberCard({ member, assignedTaskCount, onRemove }: TeamMemberCardProps) {
  return (
    <View style={styles.card}>
      <Avatar name={member.name} size={48} />
      <View style={styles.info}>
        <Text style={styles.name}>{member.name}</Text>
        <Text style={styles.role}>{member.role}</Text>
        <View style={styles.statusRow}>
          <View style={[styles.dot, { backgroundColor: AVAILABILITY_COLORS[member.availability] }]} />
          <Text style={styles.meta}>
            {member.availability} · {assignedTaskCount} {assignedTaskCount === 1 ? 'task' : 'tasks'}
          </Text>
        </View>
      </View>
      {onRemove ? (
        <Pressable
          onPress={onRemove}
          accessibilityRole="button"
          accessibilityLabel={`Remove ${member.name}`}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
          style={({ pressed }) => [styles.removeButton, pressed && Platform.OS === 'ios' && styles.pressed]}
        >
          <Ionicons name="trash-outline" size={20} color={colors.error} />
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: s(3),
    borderRadius: s(3),
    backgroundColor: colors.card,
    ...cardShadow,
  },
  info: {
    flex: 1,
    marginLeft: s(3),
  },
  name: {
    ...typography.bodyStrong,
  },
  role: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: s(1),
  },
  dot: {
    width: s(2),
    height: s(2),
    borderRadius: s(1),
    marginRight: s(1),
  },
  meta: {
    ...typography.caption,
  },
  removeButton: {
    width: s(11),
    height: s(11),
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressed: {
    opacity: 0.6,
  },
});
