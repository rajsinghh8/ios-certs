import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { AppNotification, NotificationType } from '../types';
import { formatRelativeTime } from '../utils/format';

const TYPE_ICONS: Record<NotificationType, keyof typeof Ionicons.glyphMap> = {
  task: 'checkbox-outline',
  project: 'folder-outline',
  team: 'people-outline',
};

interface NotificationItemProps {
  notification: AppNotification;
  onPress: () => void;
  onDelete: () => void;
}

// Whole-row tap and the delete icon are independent siblings (absoluteFill split) — no nested Pressables.
export function NotificationItem({ notification, onPress, onDelete }: NotificationItemProps) {
  return (
    <View style={[styles.container, !notification.isRead && styles.unread]}>
      <Pressable
        onPress={onPress}
        accessibilityRole="button"
        accessibilityLabel={notification.message}
        android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
        style={StyleSheet.absoluteFillObject}
      />
      <View style={styles.content} pointerEvents="none">
        <View style={styles.iconWrap}>
          <Ionicons name={TYPE_ICONS[notification.type]} size={20} color={colors.primary} />
        </View>
        <View style={styles.textWrap}>
          <Text style={[styles.message, !notification.isRead && styles.messageUnread]}>
            {notification.message}
          </Text>
          <Text style={styles.time}>{formatRelativeTime(notification.createdAt)}</Text>
        </View>
        {!notification.isRead ? <View style={styles.unreadDot} /> : null}
      </View>
      <Pressable
        onPress={onDelete}
        accessibilityRole="button"
        accessibilityLabel="Delete notification"
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
        style={({ pressed }) => [styles.deleteButton, pressed && Platform.OS === 'ios' && styles.pressed]}
      >
        <Ionicons name="close" size={20} color={colors.textDisabled} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: s(18),
    paddingHorizontal: s(4),
    paddingVertical: s(3),
    backgroundColor: colors.surface,
  },
  unread: {
    backgroundColor: colors.primaryLight,
  },
  content: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconWrap: {
    width: s(10),
    height: s(10),
    borderRadius: s(5),
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textWrap: {
    flex: 1,
    marginLeft: s(3),
    marginRight: s(2),
  },
  message: {
    ...typography.body,
  },
  messageUnread: {
    fontFamily: typography.bodyStrong.fontFamily,
    fontWeight: '600',
  },
  time: {
    ...typography.caption,
    marginTop: s(1),
  },
  unreadDot: {
    width: s(2),
    height: s(2),
    borderRadius: s(1),
    backgroundColor: colors.primary,
    marginRight: s(2),
  },
  deleteButton: {
    width: s(10),
    height: s(10),
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressed: {
    opacity: 0.6,
  },
});
