import React from 'react';
import { Platform, StyleSheet, Text, TextInput, TextInputProps, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface TextFieldProps extends TextInputProps {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
}

export function TextField({ label, value, onChangeText, ...props }: TextFieldProps) {
  return (
    <View style={styles.wrap}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholderTextColor={colors.textDisabled}
        autoCorrect={false}
        returnKeyType="done"
        underlineColorAndroid="transparent"
        selectionColor={colors.primary}
        style={styles.input}
        {...props}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    marginBottom: s(3),
  },
  label: {
    fontFamily: 'Inter-Medium',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    marginBottom: s(2),
  },
  input: {
    minHeight: s(12),
    borderRadius: s(2),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    paddingHorizontal: s(3),
    paddingVertical: s(3),
    fontFamily: Platform.select({ ios: 'Inter-Regular', android: 'Inter-Regular', default: 'Inter-Regular' }),
    fontSize: s(4),
    lineHeight: s(4) * 1.4,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textPrimary,
  },
});
