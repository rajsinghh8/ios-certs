import React from 'react';
import { KeyboardTypeOptions, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { fonts, typography } from '../theme/typography';

interface TextFieldProps {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  error?: string;
  helper?: string;
  secureTextEntry?: boolean;
  multiline?: boolean;
  keyboardType?: KeyboardTypeOptions;
}

export function TextField({
  label,
  value,
  onChangeText,
  placeholder,
  error,
  helper,
  secureTextEntry = false,
  multiline = false,
  keyboardType = 'default',
}: TextFieldProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.textDisabled}
        secureTextEntry={secureTextEntry}
        multiline={multiline}
        keyboardType={keyboardType}
        autoCapitalize={multiline ? 'sentences' : 'none'}
        autoCorrect={false}
        returnKeyType={multiline ? 'default' : 'done'}
        underlineColorAndroid="transparent"
        selectionColor={colors.primary}
        accessibilityLabel={label}
        style={[styles.input, multiline && styles.multiline, !!error && styles.inputError]}
      />
      {error ? (
        <Text style={styles.error}>{error}</Text>
      ) : helper ? (
        <Text style={styles.helper}>{helper}</Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: s(4),
  },
  label: {
    ...typography.captionStrong,
    marginBottom: s(1),
  },
  input: {
    minHeight: s(12),
    paddingHorizontal: s(3),
    paddingVertical: s(2),
    borderRadius: s(2),
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    fontFamily: fonts.regular,
    fontSize: 16,
    lineHeight: 22,
    color: colors.textPrimary,
  },
  multiline: {
    minHeight: s(24),
    textAlignVertical: 'top',
  },
  inputError: {
    borderColor: colors.error,
  },
  error: {
    ...typography.caption,
    color: colors.error,
    marginTop: s(1),
  },
  helper: {
    ...typography.caption,
    marginTop: s(1),
  },
});
