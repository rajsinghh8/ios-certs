import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { ProjectStatus, TaskPriority, TaskStatus } from '../types';

export type BadgeValue = TaskStatus | TaskPriority | ProjectStatus;

const BADGE_COLORS: Record<BadgeValue, string> = {
  'To Do': colors.textDisabled,
  'In Progress': colors.primary,
  Done: colors.success,
  Low: colors.success,
  Medium: colors.warning,
  High: colors.error,
  Planning: colors.accent,
  Active: colors.primary,
  'On Hold': colors.warning,
  Completed: colors.success,
};

export const getBadgeColor = (value: BadgeValue): string => BADGE_COLORS[value];

interface BadgeProps {
  label: BadgeValue;
}

export function Badge({ label }: BadgeProps) {
  const badgeColor = BADGE_COLORS[label];
  return (
    <View style={[styles.badge, { borderColor: badgeColor }]}>
      <View style={[styles.dot, { backgroundColor: badgeColor }]} />
      <Text style={[styles.text, { color: badgeColor }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: s(2),
    paddingVertical: s(1),
    borderRadius: s(4),
    borderWidth: 1,
    backgroundColor: colors.surface,
  },
  dot: {
    width: s(2),
    height: s(2),
    borderRadius: s(1),
    marginRight: s(1),
  },
  text: {
    ...typography.captionStrong,
  },
});
