import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface HeaderBarProps {
  title: string;
  subtitle?: string;
  onNotifications?: () => void;
}

export function HeaderBar({ title, subtitle, onNotifications }: HeaderBarProps) {
  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.title}>{title}</Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
      </View>
      {onNotifications ? (
        <Pressable
          onPress={onNotifications}
          android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
          style={({ pressed }) => [styles.iconButton, pressed && Platform.OS === 'ios' && styles.pressed]}
        >
          <Ionicons name="notifications-outline" size={s(6)} color={colors.textPrimary} />
          <View pointerEvents="none" style={styles.dot} />
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { minHeight: s(16), flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: s(4), paddingVertical: s(3), backgroundColor: colors.surface, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  title: { fontFamily: 'Inter-Bold', fontSize: s(5), lineHeight: s(6), letterSpacing: -0.5, color: colors.textPrimary },
  subtitle: { marginTop: s(1), fontFamily: 'Inter-Regular', fontSize: s(3), lineHeight: s(4), letterSpacing: 0.2, color: colors.textSecondary },
  iconButton: { width: s(10), height: s(10), borderRadius: s(5), alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  dot: { position: 'absolute', top: s(2), right: s(2), width: s(2), height: s(2), borderRadius: s(1), backgroundColor: colors.error },
  pressed: { opacity: 0.7 },
});
