import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { headerShadow } from '../theme/shadows';

interface HeaderBarProps {
  title: string;
  onBack?: () => void;
  rightIcon?: keyof typeof Ionicons.glyphMap;
  onRightPress?: () => void;
  rightLabel?: string;
}

export function HeaderBar({ title, onBack, rightIcon, onRightPress, rightLabel }: HeaderBarProps) {
  return (
    <View style={styles.container}>
      <View style={styles.side}>
        {onBack ? (
          <Pressable
            onPress={onBack}
            accessibilityRole="button"
            accessibilityLabel="Go back"
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
            style={({ pressed }) => [styles.iconButton, pressed && Platform.OS === 'ios' && styles.pressed]}
          >
            <Ionicons
              name={Platform.OS === 'ios' ? 'chevron-back' : 'arrow-back'}
              size={24}
              color={colors.primary}
            />
          </Pressable>
        ) : null}
      </View>
      <Text style={styles.title} numberOfLines={1} accessibilityRole="header">
        {title}
      </Text>
      <View style={[styles.side, styles.sideRight]}>
        {onRightPress ? (
          <Pressable
            onPress={onRightPress}
            accessibilityRole="button"
            accessibilityLabel={rightLabel ?? 'Action'}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
            style={({ pressed }) => [styles.iconButton, pressed && Platform.OS === 'ios' && styles.pressed]}
          >
            {rightIcon ? (
              <Ionicons name={rightIcon} size={24} color={colors.primary} />
            ) : (
              <Text style={styles.rightLabel}>{rightLabel}</Text>
            )}
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: s(14),
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: s(2),
    backgroundColor: colors.surface,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
    ...headerShadow,
  },
  side: {
    width: s(14),
    flexDirection: 'row',
    alignItems: 'center',
  },
  sideRight: {
    justifyContent: 'flex-end',
  },
  iconButton: {
    minWidth: s(11),
    height: s(11),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: s(6),
  },
  pressed: {
    opacity: 0.6,
  },
  title: {
    ...typography.heading3,
    flex: 1,
    textAlign: 'center',
    letterSpacing: Platform.select({ ios: -0.4, android: 0, default: 0 }),
  },
  rightLabel: {
    ...typography.bodyStrong,
    color: colors.primary,
  },
});
