import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface HeaderBarProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  rightLabel?: string;
  onRightPress?: () => void;
}

export function HeaderBar({ title, subtitle, onBack, rightLabel, onRightPress }: HeaderBarProps) {
  return (
    <View style={styles.container}>
      {onBack ? (
        <Pressable
          onPress={onBack}
          hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }}
          android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
          style={({ pressed }) => [styles.backButton, pressed && Platform.OS === 'ios' && styles.pressed]}
        >
          <Ionicons name="chevron-back" size={s(6)} color={colors.primary} />
        </Pressable>
      ) : null}
      <View style={styles.titleWrap}>
        <Text style={styles.title}>{title}</Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
      </View>
      {rightLabel && onRightPress ? (
        <Pressable
          onPress={onRightPress}
          android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
          style={({ pressed }) => [styles.rightButton, pressed && Platform.OS === 'ios' && styles.pressed]}
        >
          <Text style={styles.rightText}>{rightLabel}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    minHeight: s(16),
    paddingHorizontal: s(4),
    paddingVertical: s(3),
    backgroundColor: colors.surface,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
    flexDirection: 'row',
    alignItems: 'center',
    ...Platform.select({
      ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(1) }, shadowOpacity: 0.08, shadowRadius: s(2) },
      android: { elevation: 4 },
      default: {},
    }),
  },
  backButton: {
    width: s(10),
    height: s(10),
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: s(2),
  },
  titleWrap: {
    flex: 1,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: s(6),
    lineHeight: s(6) * 1.2,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
  },
  subtitle: {
    marginTop: s(1),
    fontFamily: 'Inter-Regular',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  rightButton: {
    minHeight: s(9),
    paddingHorizontal: s(3),
    borderRadius: s(2),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primaryLight,
  },
  rightText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.primaryDark,
  },
  pressed: {
    opacity: 0.7,
  },
});
