import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface HeaderBarProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  actionLabel?: string;
  onAction?: () => void;
}

export default function HeaderBar({ title, subtitle, onBack, actionLabel, onAction }: HeaderBarProps) {
  return (
    <View style={styles.container}>
      <View style={styles.leftGroup}>
        {onBack ? (
          <Pressable
            onPress={onBack}
            hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }}
            android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
            style={({ pressed }) => [styles.iconButton, pressed && Platform.OS === 'ios' && styles.pressed]}
          >
            <Ionicons name="chevron-back" size={24} color={colors.primary} />
          </Pressable>
        ) : null}
        <View style={styles.titleBlock}>
          <Text style={styles.title}>{title}</Text>
          {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
        </View>
      </View>
      {actionLabel && onAction ? (
        <Pressable
          onPress={onAction}
          android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
          style={({ pressed }) => [styles.action, pressed && Platform.OS === 'ios' && styles.pressed]}
        >
          <Text style={styles.actionText}>{actionLabel}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    minHeight: s(16),
    paddingHorizontal: s(4),
    paddingVertical: s(3),
    backgroundColor: colors.surface,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    ...Platform.select({
      ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 4 },
      android: { elevation: 1 },
      default: {},
    }),
  },
  leftGroup: {
    flex: 1,
    minHeight: s(10),
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    width: s(10),
    height: s(10),
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleBlock: {
    flex: 1,
    minHeight: s(10),
    justifyContent: 'center',
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 22,
    lineHeight: 26,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
  },
  subtitle: {
    marginTop: s(1),
    fontFamily: 'Inter-Regular',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  action: {
    minHeight: s(9),
    paddingHorizontal: s(3),
    borderRadius: s(2),
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.primaryDark,
  },
  pressed: {
    opacity: 0.7,
  },
});
