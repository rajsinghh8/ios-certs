import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface HeaderBarProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  onBack?: () => void;
  rightLabel?: string;
  onRightPress?: () => void;
}

export function HeaderBar({ title, subtitle, showBack = false, onBack, rightLabel, onRightPress }: HeaderBarProps) {
  return (
    <View style={styles.container}>
      <View style={styles.leftGroup}>
        {showBack ? (
          <Pressable
            onPress={onBack}
            hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }}
            android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
            style={({ pressed }) => [styles.backButton, pressed && Platform.OS === 'ios' && styles.pressed]}
          >
            <Ionicons name="chevron-back" size={s(6)} color={colors.primary} />
          </Pressable>
        ) : null}
        <View style={styles.titleGroup}>
          <Text style={styles.title}>{title}</Text>
          {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
        </View>
      </View>
      {rightLabel && onRightPress ? (
        <Pressable
          onPress={onRightPress}
          android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
          style={({ pressed }) => [styles.rightButton, pressed && Platform.OS === 'ios' && styles.pressed]}
        >
          <Text style={styles.rightText}>{rightLabel}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    minHeight: s(16),
    paddingHorizontal: s(4),
    paddingVertical: s(3),
    backgroundColor: colors.background,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  leftGroup: {
    flex: 1,
    minHeight: s(10),
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    width: s(10),
    height: s(10),
    borderRadius: s(5),
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: s(2),
  },
  pressed: {
    opacity: 0.7,
  },
  titleGroup: {
    flex: 1,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: s(6),
    lineHeight: 28.8,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
  },
  subtitle: {
    marginTop: s(1),
    fontFamily: 'Inter-Regular',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  rightButton: {
    minHeight: s(9),
    paddingHorizontal: s(4),
    borderRadius: s(2),
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rightText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.primary,
  },
});
