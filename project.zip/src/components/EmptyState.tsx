import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface EmptyStateProps {
  title: string;
  message: string;
  actionLabel: string;
  onAction: () => void;
}

export function EmptyState({ title, message, actionLabel, onAction }: EmptyStateProps) {
  return (
    <View style={styles.container}>
      <View style={styles.iconWrap}>
        <Ionicons name="checkmark-done-outline" size={s(8)} color={colors.primary} />
      </View>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.message}>{message}</Text>
      <Pressable
        onPress={onAction}
        android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
        style={({ pressed }) => [styles.button, pressed && Platform.OS === 'ios' && styles.pressed]}
      >
        <Text style={styles.buttonText}>{actionLabel}</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: s(6),
    paddingVertical: s(12),
  },
  iconWrap: {
    width: s(16),
    height: s(16),
    borderRadius: s(8),
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: s(4),
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: s(5),
    lineHeight: 24,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
    textAlign: 'center',
  },
  message: {
    marginTop: s(2),
    fontFamily: 'Inter-Regular',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  button: {
    minHeight: s(11),
    marginTop: s(6),
    paddingHorizontal: s(5),
    borderRadius: s(2),
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressed: {
    opacity: 0.7,
  },
  buttonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(4),
    lineHeight: 22.4,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textInverse,
  },
});
