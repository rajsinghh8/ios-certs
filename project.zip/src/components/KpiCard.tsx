import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { cardShadow } from '../theme/shadows';

interface KpiCardProps {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value: string;
  tint: string;
}

export function KpiCard({ icon, label, value, tint }: KpiCardProps) {
  return (
    <View style={styles.card} accessibilityLabel={`${label}: ${value}`}>
      <View style={[styles.iconWrap, { backgroundColor: tint }]}>
        <Ionicons name={icon} size={20} color={colors.textInverse} />
      </View>
      <Text style={styles.value}>{value}</Text>
      <Text style={styles.label}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minWidth: s(36),
    padding: s(3),
    borderRadius: s(3),
    backgroundColor: colors.card,
    ...cardShadow,
  },
  iconWrap: {
    width: s(9),
    height: s(9),
    borderRadius: s(3),
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: s(2),
  },
  value: {
    ...typography.heading2,
  },
  label: {
    ...typography.caption,
  },
});
