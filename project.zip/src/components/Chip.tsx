import React from 'react';
import { Platform, Pressable, StyleSheet, Text } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface ChipProps {
  label: string;
  selected?: boolean;
  onPress: () => void;
}

export default function Chip({ label, selected = false, onPress }: ChipProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
      style={({ pressed }) => [styles.chip, selected && styles.selected, pressed && Platform.OS === 'ios' && styles.pressed]}
    >
      <Text style={[styles.text, selected && styles.selectedText]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  chip: {
    minHeight: s(9),
    paddingHorizontal: s(3),
    paddingVertical: s(2),
    borderRadius: s(6),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: s(2),
    marginBottom: s(2),
  },
  selected: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  text: {
    fontFamily: 'Inter-Medium',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  selectedText: {
    color: colors.textInverse,
  },
  pressed: {
    opacity: 0.7,
  },
});
