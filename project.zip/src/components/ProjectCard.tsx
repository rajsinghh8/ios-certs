import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { cardShadow } from '../theme/shadows';
import { Project } from '../types';
import { Badge } from './Badge';
import { ProgressBar } from './ProgressBar';

interface ProjectCardProps {
  project: Project;
  progressPercent: number;
  taskCount: number;
  onPress: () => void;
}

export function ProjectCard({ project, progressPercent, taskCount, onPress }: ProjectCardProps) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${project.name}, ${progressPercent}% complete`}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [styles.card, pressed && Platform.OS === 'ios' && styles.pressed]}
    >
      <View style={styles.headerRow}>
        <Text style={styles.name} numberOfLines={1}>
          {project.name}
        </Text>
        <Badge label={project.status} />
      </View>
      <Text style={styles.description} numberOfLines={2}>
        {project.description}
      </Text>
      <View style={styles.progressRow}>
        <View style={styles.progressBar}>
          <ProgressBar percent={progressPercent} />
        </View>
        <Text style={styles.percent}>{progressPercent}%</Text>
      </View>
      <Text style={styles.meta}>
        {taskCount} {taskCount === 1 ? 'task' : 'tasks'} · {project.memberIds.length} members
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    ...cardShadow,
  },
  pressed: {
    opacity: 0.7,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: s(2),
  },
  name: {
    ...typography.heading3,
    flex: 1,
  },
  description: {
    ...typography.body,
    color: colors.textSecondary,
    marginTop: s(2),
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: s(3),
  },
  progressBar: {
    flex: 1,
  },
  percent: {
    ...typography.captionStrong,
    marginLeft: s(2),
  },
  meta: {
    ...typography.caption,
    marginTop: s(2),
  },
});
