import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface InfoCardProps {
  title: string;
  subtitle: string;
  meta?: string;
  icon?: keyof typeof Ionicons.glyphMap;
  onPress?: () => void;
  onMorePress?: () => void;
}

export function InfoCard({ title, subtitle, meta, icon = 'calendar-outline', onPress, onMorePress }: InfoCardProps) {
  return (
    <View style={styles.card}>
      {onPress ? (
        <Pressable
          onPress={onPress}
          android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
          style={({ pressed }) => [StyleSheet.absoluteFillObject, pressed && Platform.OS === 'ios' && styles.pressed]}
        />
      ) : null}
      <View style={styles.content} pointerEvents="none">
        <View style={styles.iconWrap}>
          <Ionicons name={icon} size={s(5)} color={colors.primary} />
        </View>
        <View style={styles.textWrap}>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.subtitle}>{subtitle}</Text>
          {meta ? <Text style={styles.meta}>{meta}</Text> : null}
        </View>
      </View>
      {onMorePress ? (
        <Pressable
          onPress={onMorePress}
          hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }}
          android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
          style={({ pressed }) => [styles.moreButton, pressed && Platform.OS === 'ios' && styles.pressed]}
        >
          <Ionicons name="ellipsis-horizontal" size={s(5)} color={colors.textSecondary} />
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    minHeight: s(20),
    borderRadius: s(3),
    backgroundColor: colors.card,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    padding: s(3),
    overflow: 'hidden',
    ...Platform.select({
      ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(1) }, shadowOpacity: 0.1, shadowRadius: s(2) },
      android: { elevation: 4 },
      default: {},
    }),
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingRight: s(10),
  },
  iconWrap: {
    width: s(11),
    height: s(11),
    borderRadius: s(11) / 2,
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: s(3),
  },
  textWrap: {
    flex: 1,
  },
  title: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(4),
    lineHeight: s(4) * 1.4,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
  },
  subtitle: {
    marginTop: s(1),
    fontFamily: 'Inter-Regular',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  meta: {
    marginTop: s(1),
    fontFamily: 'Inter-Medium',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.primaryDark,
  },
  moreButton: {
    position: 'absolute',
    right: s(2),
    top: s(2),
    width: s(10),
    height: s(10),
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 2,
  },
  pressed: {
    opacity: 0.7,
  },
});
