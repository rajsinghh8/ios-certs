import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface InfoCardProps {
  title: string;
  subtitle: string;
  meta?: string;
  icon?: keyof typeof Ionicons.glyphMap;
  onPress?: () => void;
  onMore?: () => void;
}

export default function InfoCard({ title, subtitle, meta, icon = 'calendar-outline', onPress, onMore }: InfoCardProps) {
  return (
    <View style={styles.card}>
      {onPress ? (
        <Pressable
          onPress={onPress}
          android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
          style={({ pressed }) => [StyleSheet.absoluteFillObject, pressed && Platform.OS === 'ios' && styles.pressed]}
        />
      ) : null}
      <View pointerEvents="none" style={styles.content}>
        <View style={styles.iconWrap}>
          <Ionicons name={icon} size={22} color={colors.primary} />
        </View>
        <View style={styles.textBlock}>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.subtitle}>{subtitle}</Text>
          {meta ? <Text style={styles.meta}>{meta}</Text> : null}
        </View>
      </View>
      {onMore ? (
        <Pressable
          onPress={onMore}
          hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }}
          android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
          style={({ pressed }) => [styles.more, pressed && Platform.OS === 'ios' && styles.pressed]}
        >
          <Ionicons name="ellipsis-horizontal" size={20} color={colors.textSecondary} />
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    minHeight: s(20),
    borderRadius: s(3),
    backgroundColor: colors.card,
    overflow: 'hidden',
    marginBottom: s(3),
    ...Platform.select({
      ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 6 },
      android: { elevation: 4 },
      default: {},
    }),
  },
  content: {
    minHeight: s(20),
    flexDirection: 'row',
    alignItems: 'center',
    padding: s(3),
    paddingRight: s(12),
  },
  iconWrap: {
    width: s(11),
    height: s(11),
    borderRadius: s(6),
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: s(3),
  },
  textBlock: {
    flex: 1,
    minHeight: s(14),
    justifyContent: 'center',
  },
  title: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    lineHeight: 22,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
  },
  subtitle: {
    marginTop: s(1),
    fontFamily: 'Inter-Regular',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  meta: {
    marginTop: s(1),
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    lineHeight: 17,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.primaryDark,
  },
  more: {
    position: 'absolute',
    right: s(3),
    top: s(5),
    width: s(9),
    height: s(9),
    borderRadius: s(5),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.background,
  },
  pressed: {
    opacity: 0.7,
  },
});
