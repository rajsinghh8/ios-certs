import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';
import { cardShadow } from '../theme/shadows';
import { Task } from '../types';
import { formatDate, isOverdue } from '../utils/format';
import { Badge, getBadgeColor } from './Badge';

interface TaskListItemProps {
  task: Task;
  assigneeName: string;
  onPress: () => void;
}

export function TaskListItem({ task, assigneeName, onPress }: TaskListItemProps) {
  const overdue = isOverdue(task.dueDate, task.status === 'Done');
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${task.title}, ${task.status}, ${task.priority} priority`}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [styles.card, pressed && Platform.OS === 'ios' && styles.pressed]}
    >
      <View style={[styles.priorityBar, { backgroundColor: getBadgeColor(task.priority) }]} />
      <View style={styles.content}>
        <Text style={[styles.title, task.status === 'Done' && styles.titleDone]} numberOfLines={2}>
          {task.title}
        </Text>
        <View style={styles.badgeRow}>
          <Badge label={task.status} />
          <Badge label={task.priority} />
        </View>
        <View style={styles.metaRow}>
          <Ionicons name="person-outline" size={14} color={colors.textDisabled} />
          <Text style={styles.meta}>{assigneeName}</Text>
          <Ionicons
            name="calendar-outline"
            size={14}
            color={overdue ? colors.error : colors.textDisabled}
            style={styles.metaIcon}
          />
          <Text style={[styles.meta, overdue && styles.overdue]}>
            {formatDate(task.dueDate)}
            {overdue ? ' · Overdue' : ''}
          </Text>
        </View>
      </View>
      <Ionicons name="chevron-forward" size={18} color={colors.textDisabled} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: s(3),
    paddingRight: s(3),
    borderRadius: s(3),
    backgroundColor: colors.card,
    ...cardShadow,
  },
  pressed: {
    opacity: 0.7,
  },
  priorityBar: {
    width: s(1),
    alignSelf: 'stretch',
    borderRadius: s(1),
    marginRight: s(3),
  },
  content: {
    flex: 1,
  },
  title: {
    ...typography.bodyStrong,
  },
  titleDone: {
    color: colors.textDisabled,
    textDecorationLine: 'line-through',
  },
  badgeRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: s(2),
    marginTop: s(2),
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    marginTop: s(2),
  },
  metaIcon: {
    marginLeft: s(3),
  },
  meta: {
    ...typography.caption,
    marginLeft: s(1),
  },
  overdue: {
    color: colors.error,
  },
});
