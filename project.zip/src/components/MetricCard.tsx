import React from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ProductivityMetric } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface MetricCardProps {
  metric: ProductivityMetric;
}

const toneColor = (tone: ProductivityMetric['tone']) => {
  if (tone === 'success') return colors.success;
  if (tone === 'warning') return colors.warning;
  if (tone === 'info') return colors.info;
  return colors.primary;
};

export function MetricCard({ metric }: MetricCardProps) {
  const iconColor = toneColor(metric.tone);
  return (
    <View style={styles.card}>
      <View style={[styles.iconWrap, { backgroundColor: metric.tone === 'primary' ? colors.primaryLight : colors.background }]}>
        <Ionicons name={metric.icon as keyof typeof Ionicons.glyphMap} size={s(5)} color={iconColor} />
      </View>
      <Text style={styles.value}>{metric.value}</Text>
      <Text style={styles.label}>{metric.label}</Text>
      <Text style={[styles.trend, { color: iconColor }]}>{metric.trend}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    width: s(38),
    minHeight: s(36),
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    marginRight: s(3),
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: s(1) },
        shadowOpacity: 0.1,
        shadowRadius: s(2),
      },
      android: { elevation: 4 },
      default: {},
    }),
  },
  iconWrap: {
    width: s(10),
    height: s(10),
    borderRadius: s(5),
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: s(3),
  },
  value: {
    fontFamily: 'Inter-Bold',
    fontSize: s(7),
    lineHeight: 33.6,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
  },
  label: {
    marginTop: s(1),
    fontFamily: 'Inter-Medium',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
  },
  trend: {
    marginTop: s(2),
    fontFamily: 'Inter-SemiBold',
    fontSize: s(3),
    lineHeight: 16.8,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
});
