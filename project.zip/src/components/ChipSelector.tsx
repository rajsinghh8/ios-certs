import React from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';

interface ChipSelectorProps<T extends string> {
  options: readonly T[];
  selected: T | null;
  onSelect: (value: T | null) => void;
  // When provided, an extra leading chip clears the selection (value null).
  allLabel?: string;
  // Maps an option value (e.g. an id) to its visible label; defaults to the value itself.
  getLabel?: (value: T) => string;
}

export function ChipSelector<T extends string>({
  options,
  selected,
  onSelect,
  allLabel,
  getLabel,
}: ChipSelectorProps<T>) {
  const renderChip = (label: string, value: T | null) => {
    const isActive = selected === value;
    return (
      <Pressable
        key={value ?? '__all__'}
        onPress={() => onSelect(value)}
        accessibilityRole="button"
        accessibilityState={{ selected: isActive }}
        android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
        style={({ pressed }) => [
          styles.chip,
          isActive && styles.chipActive,
          pressed && Platform.OS === 'ios' && styles.pressed,
        ]}
      >
        <Text style={[styles.chipText, isActive && styles.chipTextActive]}>{label}</Text>
      </Pressable>
    );
  };

  return (
    <ScrollView
      horizontal
      directionalLockEnabled
      decelerationRate="fast"
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.row}
    >
      {allLabel ? renderChip(allLabel, null) : null}
      {options.map((option) => renderChip(getLabel ? getLabel(option) : option, option))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  row: {
    paddingVertical: s(1),
    gap: s(2),
  },
  chip: {
    minHeight: s(9),
    paddingHorizontal: s(4),
    borderRadius: s(5),
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chipActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  pressed: {
    opacity: 0.7,
  },
  chipText: {
    ...typography.captionStrong,
  },
  chipTextActive: {
    color: colors.textInverse,
  },
});
