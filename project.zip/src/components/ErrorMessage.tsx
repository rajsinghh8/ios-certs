import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { typography } from '../theme/typography';

interface ErrorMessageProps {
  message: string;
}

export function ErrorMessage({ message }: ErrorMessageProps) {
  return (
    <View style={styles.container} accessibilityRole="alert">
      <Ionicons name="alert-circle" size={20} color={colors.error} />
      <Text style={styles.text}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: s(3),
    marginBottom: s(4),
    borderRadius: s(2),
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.error,
  },
  text: {
    ...typography.body,
    flex: 1,
    marginLeft: s(2),
    color: colors.error,
  },
});
