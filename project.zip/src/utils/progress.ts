import { Task } from '../types';

// Project progress = percentage of its tasks that are Done.
export const getProjectProgress = (tasks: Task[], projectId: string): number => {
  const projectTasks = tasks.filter((task) => task.projectId === projectId);
  if (projectTasks.length === 0) {
    return 0;
  }
  const doneCount = projectTasks.filter((task) => task.status === 'Done').length;
  return Math.round((doneCount / projectTasks.length) * 100);
};
