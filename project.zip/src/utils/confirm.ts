import { Alert, Platform } from 'react-native';

// Alert.alert is a no-op on react-native-web, so the web preview falls back to window.confirm.
export const confirmAction = (
  title: string,
  message: string,
  confirmLabel: string,
  onConfirm: () => void,
): void => {
  if (Platform.OS === 'web') {
    const accepted = typeof window !== 'undefined' && window.confirm(`${title}\n\n${message}`);
    if (accepted) {
      onConfirm();
    }
    return;
  }
  Alert.alert(title, message, [
    { text: 'Cancel', style: 'cancel' },
    { text: confirmLabel, style: 'destructive', onPress: onConfirm },
  ]);
};

export const notify = (title: string, message: string): void => {
  if (Platform.OS === 'web') {
    if (typeof window !== 'undefined') {
      window.alert(`${title}\n\n${message}`);
    }
    return;
  }
  Alert.alert(title, message);
};
