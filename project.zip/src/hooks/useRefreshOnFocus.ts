import { useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';

// Runs `load` on mount and again every time the screen regains focus
// (e.g. after returning from a create/edit form).
export function useRefreshOnFocus(load: () => void): void {
  const navigation = useNavigation();

  useEffect(() => {
    load();
    const unsubscribe = (navigation as any).addListener?.('focus', load);
    return () => {
      if (typeof unsubscribe === 'function') {
        unsubscribe();
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}
