export type AppointmentStatus = 'confirmed' | 'cancelled' | 'completed' | 'noShow';
export type OverrideType = 'dayOff' | 'customHours';
export type Weekday = 0 | 1 | 2 | 3 | 4 | 5 | 6;

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'operator';
}

export interface Location {
  id: string;
  name: string;
  city: string;
  timezone: string;
  address: string;
}

export interface Service {
  id: string;
  name: string;
  durationMinutes: number;
  priceCents: number;
  staffIds: string[];
}

export interface StaffMember {
  id: string;
  name: string;
  locationId: string;
  title: string;
  serviceIds: string[];
}

export interface TimeBlock {
  start: string;
  end: string;
}

export interface WeeklyScheduleDay {
  staffId: string;
  weekday: Weekday;
  blocks: TimeBlock[];
}

export interface ScheduleOverride {
  id: string;
  staffId: string;
  date: string;
  type: OverrideType;
  blocks: TimeBlock[];
  note: string;
}

export interface Appointment {
  id: string;
  locationId: string;
  serviceId: string;
  staffId: string;
  customerName: string;
  customerEmail: string;
  date: string;
  startTime: string;
  endTime: string;
  status: AppointmentStatus;
  createdAt: string;
}

export interface WaitlistEntry {
  id: string;
  locationId: string;
  serviceId: string;
  staffId?: string;
  customerName: string;
  customerEmail: string;
  date: string;
  createdAt: string;
  notified: boolean;
}

export interface DashboardStats {
  recentAppointments: number;
  noShows: number;
  completed: number;
}
