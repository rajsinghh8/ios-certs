export type TaskPriority = 'low' | 'medium' | 'high';
export type TaskStatus = 'todo' | 'inProgress' | 'done';
export type TaskFilter = 'all' | 'today' | 'inProgress' | 'done';

export interface TaskItem {
  id: string;
  title: string;
  description: string;
  category: string;
  dueDate: string;
  priority: TaskPriority;
  status: TaskStatus;
  createdAt: string;
}

export interface ProductivityMetric {
  id: string;
  label: string;
  value: string;
  trend: string;
  tone: 'primary' | 'success' | 'warning' | 'info';
  icon: string;
}
