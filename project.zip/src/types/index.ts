export type UserRole = 'admin' | 'user';

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: UserRole;
}

export interface Session {
  token: string;
  userId: string;
  name: string;
  email: string;
  role: UserRole;
}

export type ProjectStatus = 'Planning' | 'Active' | 'On Hold' | 'Completed';

export interface Project {
  id: string;
  name: string;
  description: string;
  status: ProjectStatus;
  ownerId: string;
  memberIds: string[];
  startDate: string;
  endDate: string;
  createdAt: string;
}

export type TaskStatus = 'To Do' | 'In Progress' | 'Done';
export type TaskPriority = 'Low' | 'Medium' | 'High';

export interface Task {
  id: string;
  projectId: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  assigneeId: string | null;
  dueDate: string;
  createdAt: string;
}

export type Availability = 'Available' | 'Busy' | 'Away';

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: string;
  availability: Availability;
}

export type NotificationType = 'task' | 'project' | 'team';

export interface AppNotification {
  id: string;
  type: NotificationType;
  message: string;
  relatedEntityType: 'task' | 'project' | 'member';
  relatedEntityId: string;
  isRead: boolean;
  createdAt: string;
}

export interface Activity {
  id: string;
  projectId: string;
  userName: string;
  description: string;
  timestamp: string;
}

export interface AppSettings {
  pushNotifications: boolean;
  emailDigest: boolean;
  taskReminders: boolean;
  compactLists: boolean;
}
