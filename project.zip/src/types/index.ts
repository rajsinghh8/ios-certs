export type AppointmentStatus = 'confirmed' | 'cancelled' | 'completed' | 'no_show';
export type OverrideType = 'day_off' | 'custom_hours';

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'operator';
}

export interface Location {
  id: string;
  name: string;
  city: string;
  timezone: string;
  address: string;
}

export interface Service {
  id: string;
  name: string;
  durationMinutes: number;
  priceCents: number;
  staffIds: string[];
}

export interface StaffMember {
  id: string;
  name: string;
  locationId: string;
  serviceIds: string[];
  color: string;
}

export interface TimeBlock {
  start: string;
  end: string;
}

export interface WeeklySchedule {
  staffId: string;
  blocksByDay: Record<number, TimeBlock[]>;
}

export interface ScheduleOverride {
  id: string;
  staffId: string;
  date: string;
  type: OverrideType;
  blocks: TimeBlock[];
  note: string;
}

export interface Appointment {
  id: string;
  customerName: string;
  customerEmail: string;
  locationId: string;
  serviceId: string;
  staffId: string;
  date: string;
  startTime: string;
  endTime: string;
  status: AppointmentStatus;
  createdAt: string;
}

export interface WaitlistEntry {
  id: string;
  customerName: string;
  customerEmail: string;
  locationId: string;
  serviceId: string;
  staffId?: string;
  date: string;
  notified: boolean;
  createdAt: string;
}

export interface Session {
  token: string;
  userId: string;
  name: string;
  email: string;
  role: 'operator';
}
