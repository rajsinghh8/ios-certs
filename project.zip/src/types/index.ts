export type ProjectStatus = 'Active' | 'Planning' | 'At risk' | 'Complete';
export type TaskStatus = 'To do' | 'In progress' | 'Done';
export type TaskPriority = 'High' | 'Medium' | 'Low';

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  initials: string;
  color: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  status: ProjectStatus;
  progress: number;
  dueDate: string;
  memberIds: string[];
}

export interface Task {
  id: string;
  projectId: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  assigneeId: string;
  dueDate: string;
}

export interface AppNotification {
  id: string;
  title: string;
  detail: string;
  kind: 'task' | 'project';
  referenceId: string;
  isRead: boolean;
  createdAt: string;
}
