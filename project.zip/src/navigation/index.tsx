import { Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React, { useEffect, useState } from 'react';
import { Platform, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import LoginScreen from '../screens/LoginScreen';
import SignupScreen from '../screens/SignupScreen';
import DashboardScreen from '../screens/DashboardScreen';
import BookAppointmentScreen from '../screens/BookAppointmentScreen';
import AppointmentsScreen from '../screens/AppointmentsScreen';
import AppointmentDetailScreen from '../screens/AppointmentDetailScreen';
import ManageScreen from '../screens/ManageScreen';
import EditLocationScreen from '../screens/EditLocationScreen';
import EditServiceScreen from '../screens/EditServiceScreen';
import EditStaffScreen from '../screens/EditStaffScreen';
import StaffHoursScreen from '../screens/StaffHoursScreen';
import WaitlistScreen from '../screens/WaitlistScreen';
import NotFoundScreen from '../screens/NotFoundScreen';
import { storage } from '../utils/storage';

export type RootStackParamList = {
  Login: undefined;
  Signup: undefined;
  MainTabs: undefined;
  AppointmentDetail: { id: string };
  EditLocation: { id?: string };
  EditService: { id?: string };
  EditStaff: { id?: string };
  StaffHours: { staffId: string };
  NotFound: undefined;
};

export type MainTabParamList = {
  Dashboard: undefined;
  Book: undefined;
  Appointments: undefined;
  Manage: undefined;
  Waitlist: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<MainTabParamList>();

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarLabelStyle: styles.tabLabel,
        tabBarIcon: ({ color, size }) => {
          const name = route.name === 'Dashboard' ? 'speedometer-outline' : route.name === 'Book' ? 'add-circle-outline' : route.name === 'Appointments' ? 'calendar-outline' : route.name === 'Manage' ? 'settings-outline' : 'notifications-outline';
          return <Ionicons name={name} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="Book" component={BookAppointmentScreen} />
      <Tab.Screen name="Appointments" component={AppointmentsScreen} />
      <Tab.Screen name="Manage" component={ManageScreen} />
      <Tab.Screen name="Waitlist" component={WaitlistScreen} />
    </Tab.Navigator>
  );
}

export function RootNavigator() {
  const [initialRoute, setInitialRoute] = useState<keyof RootStackParamList | null>(null);

  useEffect(() => {
    storage.getItem('auth_token').then((token) => setInitialRoute(token ? 'MainTabs' : 'Login'));
  }, []);

  if (!initialRoute) return null;

  return (
    <Stack.Navigator
      initialRouteName={initialRoute}
      screenOptions={{
        headerStyle: { backgroundColor: colors.surface, ...Platform.select({ android: { elevation: 4 }, ios: {}, default: {} }) },
        headerTitleStyle: { fontFamily: 'Inter-SemiBold', fontWeight: '600', fontSize: 17, color: colors.textPrimary },
        headerTintColor: colors.primary,
        headerBackTitleVisible: false,
        headerShadowVisible: true,
      }}
    >
      <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Signup" component={SignupScreen} options={{ headerShown: false }} />
      <Stack.Screen name="MainTabs" component={MainTabs} options={{ headerShown: false }} />
      <Stack.Screen name="AppointmentDetail" component={AppointmentDetailScreen} options={{ headerShown: false }} />
      <Stack.Screen name="EditLocation" component={EditLocationScreen} options={{ headerShown: false }} />
      <Stack.Screen name="EditService" component={EditServiceScreen} options={{ headerShown: false }} />
      <Stack.Screen name="EditStaff" component={EditStaffScreen} options={{ headerShown: false }} />
      <Stack.Screen name="StaffHours" component={StaffHoursScreen} options={{ headerShown: false }} />
      <Stack.Screen name="NotFound" component={NotFoundScreen} options={{ title: 'Not Found' }} />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: colors.surface,
    borderTopColor: colors.border,
    borderTopWidth: StyleSheet.hairlineWidth,
    height: Platform.select({ ios: 83, android: 60, default: 60 }),
    paddingBottom: Platform.select({ ios: 28, android: 8, default: 8 }),
    paddingTop: 8,
    ...Platform.select({ android: { elevation: 8 }, ios: {}, default: {} }),
  },
  tabLabel: {
    fontSize: 11,
    lineHeight: 15,
    fontWeight: '500',
    fontFamily: 'Inter-Medium',
    letterSpacing: 0.2,
  },
});
