import { Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React, { useEffect, useState } from 'react';
import { Platform, StyleSheet } from 'react-native';
import AppointmentsScreen from '../screens/AppointmentsScreen';
import BookingScreen from '../screens/BookingScreen';
import DashboardScreen from '../screens/DashboardScreen';
import LoginScreen from '../screens/LoginScreen';
import ManageScreen from '../screens/ManageScreen';
import NotFoundScreen from '../screens/NotFoundScreen';
import SignupScreen from '../screens/SignupScreen';
import StaffHoursScreen from '../screens/StaffHoursScreen';
import WaitlistScreen from '../screens/WaitlistScreen';
import { colors } from '../theme/colors';
import { storage } from '../utils/storage';

export type RootStackParamList = {
  Login: undefined;
  Signup: undefined;
  MainTabs: undefined;
  NotFound: undefined;
};

export type MainTabParamList = {
  Dashboard: undefined;
  Book: undefined;
  Appointments: undefined;
  StaffHours: undefined;
  Manage: undefined;
  Waitlist: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<MainTabParamList>();

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarLabelStyle: styles.tabLabel,
        tabBarIcon: ({ color, size }) => {
          const iconName = route.name === 'Dashboard' ? 'stats-chart-outline' : route.name === 'Book' ? 'calendar-outline' : route.name === 'Appointments' ? 'list-outline' : route.name === 'StaffHours' ? 'time-outline' : route.name === 'Manage' ? 'settings-outline' : 'notifications-outline';
          return <Ionicons name={iconName} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen} options={{ title: 'Home' }} />
      <Tab.Screen name="Book" component={BookingScreen} options={{ title: 'Book' }} />
      <Tab.Screen name="Appointments" component={AppointmentsScreen} options={{ title: 'Appointments' }} />
      <Tab.Screen name="StaffHours" component={StaffHoursScreen} options={{ title: 'Hours' }} />
      <Tab.Screen name="Manage" component={ManageScreen} options={{ title: 'Manage' }} />
      <Tab.Screen name="Waitlist" component={WaitlistScreen} options={{ title: 'Waitlist' }} />
    </Tab.Navigator>
  );
}

export function RootNavigator() {
  const [initialRoute, setInitialRoute] = useState<keyof RootStackParamList | null>(null);

  useEffect(() => {
    storage.getItem('auth_token').then((token) => setInitialRoute(token ? 'MainTabs' : 'Login')).catch(() => setInitialRoute('Login'));
  }, []);

  if (!initialRoute) return null;

  return (
    <Stack.Navigator
      initialRouteName={initialRoute}
      screenOptions={{
        headerStyle: {
          backgroundColor: colors.surface,
          ...Platform.select({ android: { elevation: 4 }, ios: {}, default: {} }),
        },
        headerTitleStyle: styles.headerTitle,
        headerTintColor: colors.primary,
        headerBackTitleVisible: false,
        headerShadowVisible: true,
      }}
    >
      <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Signup" component={SignupScreen} options={{ headerShown: false }} />
      <Stack.Screen name="MainTabs" component={MainTabs} options={{ headerShown: false }} />
      <Stack.Screen name="NotFound" component={NotFoundScreen} options={{ title: 'Not found' }} />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  headerTitle: {
    fontFamily: Platform.select({ ios: 'Inter-SemiBold', android: 'Inter-SemiBold', default: 'Inter-SemiBold' }),
    fontWeight: '600',
    fontSize: 17,
    color: colors.textPrimary,
    letterSpacing: Platform.select({ ios: -0.4, android: 0, default: 0 }),
  },
  tabBar: {
    backgroundColor: colors.surface,
    borderTopColor: colors.border,
    borderTopWidth: StyleSheet.hairlineWidth,
    height: Platform.select({ ios: 83, android: 60, default: 60 }),
    paddingBottom: Platform.select({ ios: 28, android: 8, default: 8 }),
    paddingTop: 8,
    ...Platform.select({ android: { elevation: 8 }, ios: {}, default: {} }),
  },
  tabLabel: {
    fontSize: 11,
    fontWeight: '500',
    fontFamily: Platform.select({ ios: 'Inter-Medium', android: 'Inter-Medium', default: 'Inter-Medium' }),
    letterSpacing: 0.2,
  },
});
