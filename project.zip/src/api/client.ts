import Constants from 'expo-constants';

interface ApiResponse<T> {
  data: T;
}

const extra = Constants.expoConfig?.extra as { apiUrl?: string } | undefined;

export const apiClient = {
  baseURL: extra?.apiUrl ?? '',
  async get<T>(_path: string): Promise<ApiResponse<T>> {
    throw new Error('Network API is disabled while USE_MOCK is true.');
  },
  async post<T>(_path: string, _body: unknown): Promise<ApiResponse<T>> {
    throw new Error('Network API is disabled while USE_MOCK is true.');
  },
  async put<T>(_path: string, _body: unknown): Promise<ApiResponse<T>> {
    throw new Error('Network API is disabled while USE_MOCK is true.');
  },
  async delete<T>(_path: string): Promise<ApiResponse<T>> {
    throw new Error('Network API is disabled while USE_MOCK is true.');
  },
};
