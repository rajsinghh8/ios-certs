import axios from 'axios';
import Toast from 'react-native-toast-message';
import { storage } from '../storage';

export const apiClient = axios.create({
  baseURL: process.env.EXPO_PUBLIC_API_URL || '',
  timeout: 15000,
});

apiClient.interceptors.request.use(async (config) => {
  const rawSession = await storage.getItem('auth_token');
  if (rawSession) {
    try {
      const session = JSON.parse(rawSession) as { token?: string };
      if (session.token) {
        config.headers.Authorization = `Bearer ${session.token}`;
      }
    } catch {
      // Ignore malformed stored session; request proceeds unauthenticated.
    }
  }
  return config;
});

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const message =
      error?.response?.data?.message ||
      (error?.response ? `Request failed (${error.response.status})` : 'Network error — please try again');
    Toast.show({ type: 'error', text1: message });
    return Promise.reject(error);
  },
);
