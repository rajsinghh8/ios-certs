import axios from 'axios';
import appConfig from '../../app.json';
import { storage } from '../utils/storage';

const apiUrl = appConfig.expo.extra.apiUrl;

export const apiClient = axios.create({
  baseURL: apiUrl,
  timeout: 10000,
});

apiClient.interceptors.request.use(async (config) => {
  const rawSession = await storage.getItem('auth_token');
  if (rawSession) {
    config.headers.Authorization = `Bearer ${rawSession}`;
  }
  return config;
});
