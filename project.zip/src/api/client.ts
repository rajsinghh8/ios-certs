import appJson from '../../app.json';
import { storage } from '../utils/storage';

type Method = 'GET' | 'POST' | 'PUT' | 'DELETE';

const baseURL = appJson.expo.extra.apiUrl;

async function request<T>(method: Method, path: string, body?: unknown): Promise<{ data: T }> {
  const saved = await storage.getItem('auth_token');
  const token = saved ? JSON.parse(saved).token : undefined;
  throw new Error(`API client is not connected yet (${method} ${baseURL}${path}, token ${token ? 'present' : 'missing'}).`);
}

export const apiClient = {
  get: <T>(path: string) => request<T>('GET', path),
  post: <T>(path: string, body: unknown) => request<T>('POST', path, body),
  put: <T>(path: string, body: unknown) => request<T>('PUT', path, body),
  delete: <T>(path: string) => request<T>('DELETE', path),
};
