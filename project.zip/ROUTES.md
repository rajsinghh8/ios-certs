# Test ios — Screens & Navigation

## How to run

```bash
cd /home/hewlett/projects/frontendX_backend_merged/frontend_runs/run_8a5ada3b_20260825_073526/project
npm install --legacy-peer-deps && npx expo start
```

Press `a` for Android, `i` for the iOS simulator, `w` for web, or scan the QR code with Expo Go on a physical device.

## Screens

| Screen | File | Description |
|--------|------|-------------|
| Login | `src/screens/LoginScreen.tsx` | Email/password entry with validation, sign-up, and password-reset actions. |
| Sign Up | `src/screens/SignUpScreen.tsx` | New account form with inline validation and success feedback. |
| Forgot Password | `src/screens/ForgotPasswordScreen.tsx` | Mock reset-link request with a visible completion state. |
| Dashboard | `src/screens/DashboardScreen.tsx` | KPI summary, active project progress, and recent activity. |
| Projects | `src/screens/ProjectsScreen.tsx` | Searchable project directory with a stateful create-project action. |
| Project Details | `src/screens/ProjectDetailsScreen.tsx` | Project overview, members, progress, and stateful task creation. |
| All Tasks | `src/screens/TasksScreen.tsx` | Cross-project task search, status filtering, and status updates. |
| Task Details | `src/screens/TaskDetailsScreen.tsx` | Task description, assignee, due date, status update, and project link. |
| Team | `src/screens/TeamScreen.tsx` | Searchable team directory with mock invite action. |
| Notifications | `src/screens/NotificationsScreen.tsx` | Read-state notification center with task/project deep links. |
| Settings | `src/screens/SettingsScreen.tsx` | Profile preferences, notification toggle, save state, and confirmed sign-out. |
| Not Found | `src/screens/NotFoundScreen.tsx` | Fallback screen with return navigation. |

## Navigation map

- Login -> MainTabs: successful sign-in.
- Login -> Sign Up: tap **Create an account**.
- Login -> Forgot Password: tap **Forgot password?**.
- Sign Up -> MainTabs: successful registration.
- Forgot Password -> Login: tap **Back to sign in**.
- Dashboard -> Projects / Tasks: tap a KPI card.
- Dashboard -> Project Details: tap a project-progress card.
- Dashboard / Projects -> Notifications: tap the notification control.
- Projects -> Project Details: tap a project card or create a project.
- Project Details -> Task Details: tap a task row.
- Task Details -> Project Details: tap **View project**.
- Notifications -> Task Details / Project Details: tap a notification.
- Settings -> Login: confirm **Sign out**.

## Shared components

- `HeaderBar.tsx` — title/subtitle row with notification affordance.
- `ProgressBar.tsx` — branded project-progress indicator.
- `StatusPill.tsx` — accessible visual status label for tasks and projects.

## Design tokens

`colors.ts` exports: `primary`, `primaryDark`, `primaryLight`, `accent`, `background`, `surface`, `card`, `border`, `textPrimary`, `textSecondary`, `textDisabled`, `textInverse`, `success`, `warning`, `error`, `info`, and `shadowColor`.
