# IPA Endpoint Creation — Screens & Navigation

## How to run
cd /home/hewlett/projects/frontendX_backend_merged/frontend_runs/run_f67c8db0_20260727_084531/project
npm install && npx expo start
# Press 'a' for Android, 'i' for iOS simulator, 'w' for web,
# or scan the QR code with the Expo Go app on a physical iOS/Android device.

## Screens
| Screen | File | Description |
|--------|------|-------------|
| Login | src/screens/LoginScreen.tsx | Normal email/password sign-in; any typed account can enter through mock auth. |
| Signup | src/screens/SignupScreen.tsx | Create account form that signs the user in and resets to the app. |
| Dashboard | src/screens/DashboardScreen.tsx | Shows recent appointment counts, completed/no-show totals, setup summary, staff workload, and logout. |
| Browse & book | src/screens/BookingScreen.tsx | Select location, service, eligible staff/anyone, day, and 15-minute open slot; confirms immediately. |
| All appointments | src/screens/AppointmentsScreen.tsx | Filter appointments and cancel, complete, or mark no-show with 24-hour and past-time rules. |
| Staff hours | src/screens/StaffHoursScreen.tsx | Edit normal weekly time blocks and date-specific overrides such as day off or custom hours. |
| Locations, services & staff | src/screens/ManageScreen.tsx | Add and review locations, services with exact cents pricing, and staff members. |
| Waitlist | src/screens/WaitlistScreen.tsx | Add and view waitlist entries for fully-booked days and see notification state. |
| NotFound | src/screens/NotFoundScreen.tsx | Fallback screen with a working Go Back action. |

## Navigation map
- Login -> MainTabs when the sign-in form submits successfully through `login()`.
- Login -> Signup by tapping Create account.
- Signup -> MainTabs by submitting valid signup details through `signup()`.
- Signup -> Login by tapping the header back chevron.
- MainTabs -> Dashboard by tapping the Home tab.
- MainTabs -> Browse & book by tapping the Book tab.
- MainTabs -> All appointments by tapping the Appointments tab.
- MainTabs -> Staff hours by tapping the Hours tab.
- MainTabs -> Locations, services & staff by tapping the Manage tab.
- MainTabs -> Waitlist by tapping the Waitlist tab.
- Dashboard -> Login by tapping Logout, which calls `logout()` and resets navigation.

## Shared components
- src/components/HeaderBar.tsx — Reusable native header with title, subtitle, optional back chevron, and optional right action.
- src/components/PrimaryButton.tsx — Pressable CTA button with primary, secondary, danger, and disabled states.
- src/components/InfoCard.tsx — Elevated card for list rows and summaries, including absolute-fill primary press support plus optional kebab action.
- src/components/Chip.tsx — Selectable filter/choice pill used across booking, schedules, management, and waitlist.
- src/components/TextField.tsx — Labeled React Native TextInput with cross-platform underline suppression and Inter typography.

## Design tokens
- primary: '#0F766E'
- primaryDark: '#115E59'
- primaryLight: '#CCFBF1'
- accent: '#4F46E5'
- background: '#F8FAFC'
- surface: '#FFFFFF'
- card: '#FFFFFF'
- border: '#E2E8F0'
- textPrimary: '#0F172A'
- textSecondary: '#475569'
- textDisabled: '#94A3B8'
- textInverse: '#FFFFFF'
- success: '#16A34A'
- warning: '#D97706'
- error: '#DC2626'
- info: '#0284C7'
- shadowColor: '#000000'
