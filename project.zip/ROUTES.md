# Test — Screens & Navigation

## How to run
cd /home/ryzen/frontend_generator_backend-test/frontend_runs/run_f96ab4d4_20260810_083229/project
npm install && npx expo start
# Press 'a' for Android, 'i' for iOS simulator, 'w' for web,
# or scan the QR code with the Expo Go app on a physical iOS/Android device.

## Screens
| Screen | File | Description |
|--------|------|-------------|
| MainTabs / Dashboard | src/screens/DashboardScreen.tsx | Home dashboard with daily progress, horizontal insight cards, and tasks due today. |
| MainTabs / Tasks | src/screens/TasksScreen.tsx | Searchable and filterable task list with create and completion toggles. |
| MainTabs / Stats | src/screens/StatsScreen.tsx | Productivity statistics calculated from the live task store. |
| TaskDetail | src/screens/TaskDetailScreen.tsx | Task details, schedule metadata, status controls, edit action, and delete action. |
| TaskForm | src/screens/TaskFormScreen.tsx | Create/edit task form with controlled inputs, priority chips, and status chips. |
| NotFound | src/screens/NotFoundScreen.tsx | Fallback screen with a go-back action. |

## Navigation map
- MainTabs / Dashboard -> TaskForm (tap New).
- MainTabs / Dashboard -> TaskDetail (tap a due-today task card).
- MainTabs / Dashboard -> MainTabs / Tasks (tap View all).
- MainTabs / Tasks -> TaskForm (tap Add or floating + button).
- MainTabs / Tasks -> TaskDetail (tap any task card).
- TaskDetail -> TaskForm (tap Edit).
- TaskDetail -> previous screen (tap back chevron or delete task).
- TaskForm -> previous screen (submit create/edit or tap back chevron).
- Bottom tabs switch between Dashboard, Tasks, and Stats.

## Shared components
- src/components/HeaderBar.tsx — Custom safe header with title, subtitle, optional back button, and optional right action.
- src/components/TaskCard.tsx — Elevated task row/card using the absolute-fill primary press pattern plus a separate completion action.
- src/components/FilterChip.tsx — Reusable selected/unselected Pressable chip for filters, priority, and status choices.
- src/components/MetricCard.tsx — Horizontal dashboard insight card with icon, metric value, label, and trend text.
- src/components/EmptyState.tsx — Centered empty-list message with a Pressable call to action.

## Design tokens
- primary: #4F46E5
- primaryDark: #3730A3
- primaryLight: #EEF2FF
- accent: #14B8A6
- background: #F8FAFC
- surface: #FFFFFF
- card: #FFFFFF
- border: #E2E8F0
- textPrimary: #0F172A
- textSecondary: #64748B
- textDisabled: #94A3B8
- textInverse: #FFFFFF
- success: #22C55E
- warning: #F59E0B
- error: #EF4444
- info: #3B82F6
- shadowColor: #000000

## Build note
Cross-platform mobile project (iOS + Android) — preview runs entirely via `expo start --web` in the browser (platformOverride.js + ?forcePlatform= toggle simulates iOS/Android styling); no EAS build or native compile step is run here.
