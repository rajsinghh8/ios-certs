# Ios Appp test55 — Screens & Navigation

## How to run
cd /workspace/frontend_runs/2d31769a-1e7d-42bc-b2dc-8408f6d1bded/project
npm install --legacy-peer-deps && npx expo start
# Press 'a' for Android, 'i' for iOS simulator, 'w' for web,
# or scan the QR code with the Expo Go app on a physical iOS/Android device.

## Screens
| Screen | File | Description |
|--------|------|-------------|
| Login | src/screens/LoginScreen.tsx | Email/password sign in with validation, inline error and "Forgot password?" link |
| ForgotPassword | src/screens/ForgotPasswordScreen.tsx | Placeholder reset-link form with success state |
| Dashboard (tab) | src/screens/DashboardScreen.tsx | KPI cards, task statistics, project progress, recent activity |
| Projects (tab) | src/screens/ProjectListScreen.tsx | Searchable/filterable project list with FAB, loading and empty states |
| ProjectDetail | src/screens/ProjectDetailScreen.tsx | Project info, progress, task list filtered by status/priority, team tab |
| TaskDetail | src/screens/TaskDetailScreen.tsx | Task info, status/priority/assignee updates, delete with confirmation |
| CreateProject | src/screens/CreateProjectScreen.tsx | Validated create/edit project form with member selection |
| CreateTask | src/screens/CreateTaskScreen.tsx | Validated create/edit task form (assignee limited to project members) |
| Team (tab) | src/screens/TeamMembersScreen.tsx | Searchable members, inline add form, remove with confirmation |
| Notifications (tab) | src/screens/NotificationsScreen.tsx | All/Unread filter, mark read, mark all read, delete with confirmation |
| Settings (tab) | src/screens/SettingsScreen.tsx | Profile, persisted preference toggles, logout with confirmation |
| NotFound | src/screens/NotFoundScreen.tsx | Fallback screen with Go Back |

## Navigation map
- Login -> MainTabs (successful login; initial route is MainTabs when a session token exists)
- Login -> ForgotPassword (tap "Forgot password?")
- Dashboard -> Projects tab (tap "View all")
- Dashboard -> ProjectDetail (tap a project progress row)
- Projects -> ProjectDetail (tap project card)
- Projects -> CreateProject (tap FAB / empty-state button)
- ProjectDetail -> CreateProject (header edit icon)
- ProjectDetail -> CreateTask (Add task button)
- ProjectDetail -> TaskDetail (tap task row)
- TaskDetail -> CreateTask (header edit icon, edit mode)
- Notifications -> TaskDetail / ProjectDetail (tap a notification)
- Settings -> Login (confirmed logout, stack reset)
- Dashboard / Projects / Team / Notifications / Settings: bottom tab bar

## Shared components
- Avatar.tsx — initials circle
- Badge.tsx — colored status/priority/project-status pill
- ChipSelector.tsx — horizontal chip filter/selector
- EmptyState.tsx — icon, title, message and optional action
- ErrorMessage.tsx — inline error banner
- FloatingButton.tsx — floating "+" action button
- HeaderBar.tsx — screen header with optional back and right action
- KpiCard.tsx — icon, value and label metric card
- LoadingState.tsx — centered spinner with label
- NotificationItem.tsx — notification row with tap and delete (no nested Pressables)
- PrimaryButton.tsx — primary/secondary/danger button with loading state
- ProgressBar.tsx — horizontal progress bar
- ProjectCard.tsx — project summary card
- SearchBar.tsx — search input with clear button
- SettingsToggle.tsx — labeled switch row
- TaskListItem.tsx — task row with badges, assignee and due date
- TeamMemberCard.tsx — member card with remove action
- TextField.tsx — labeled input with helper/error text

## Design tokens
colors.ts: primary, primaryDark, primaryLight, accent, background, surface, card, border, textPrimary, textSecondary, textDisabled, textInverse, success, warning, error, info, shadowColor

## Notes
- Smoke tests (npx jest) pass for all screens; async store loads may log "environment torn down" noise after a test finishes, which is harmless.
