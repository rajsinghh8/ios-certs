# IPA Endpoint for Integration — Screens & Navigation

## How to run
cd /home/hewlett/projects/frontendX_backend_merged/frontend_runs/run_c5a08bcc_20260727_073059/project
npm install && npx expo start
# Press 'a' for Android, 'i' for iOS simulator, 'w' for web,
# or scan the QR code with the Expo Go app on a physical iOS/Android device.

## Screens
| Screen | File | Description |
|--------|------|-------------|
| Login | src/screens/LoginScreen.tsx | Normal email/password sign-in; any entered account is accepted through mock auth. |
| Signup | src/screens/SignupScreen.tsx | Create account form that persists a mock session and enters the app. |
| Dashboard | src/screens/DashboardScreen.tsx | Summary of completed appointments, no-shows, upcoming appointments, and staff utilization. |
| Browse & book | src/screens/BookAppointmentScreen.tsx | Pick location, service, eligible staff or anyone, day, and a non-overlapping open time; confirms immediately. |
| All appointments | src/screens/AppointmentsScreen.tsx | Filter appointments; cancel eligible upcoming appointments; complete/no-show past appointments. |
| Appointment | src/screens/AppointmentDetailScreen.tsx | Detail view for one appointment with customer, service, staff, location, local timezone, and status. |
| Manage | src/screens/ManageScreen.tsx | Browse locations, services, and staff; add/edit records; open staff hours from staff rows. |
| Add/Edit location | src/screens/EditLocationScreen.tsx | Add or update location name, city, timezone, and address. |
| Add/Edit service | src/screens/EditServiceScreen.tsx | Add or update service name, duration, exact cents-backed price, and trained staff. |
| Add/Edit staff | src/screens/EditStaffScreen.tsx | Add or update staff name, single location, and service training. |
| Staff hours | src/screens/StaffHoursScreen.tsx | Edit weekly split work blocks and add date-specific day-off or custom-hours overrides. |
| Waitlist | src/screens/WaitlistScreen.tsx | View and add waitlist entries for fully booked service/date/staff combinations. |
| Not Found | src/screens/NotFoundScreen.tsx | Fallback screen with a working back action. |

## Navigation map
- Login -> MainTabs (submit email and password through mock login)
- Login -> Signup (tap Create account)
- Signup -> MainTabs (submit valid signup form)
- Signup -> Login (tap Back to sign in)
- MainTabs -> Dashboard (bottom tab)
- MainTabs -> Browse & book (bottom tab)
- MainTabs -> All appointments (bottom tab)
- MainTabs -> Manage (bottom tab)
- MainTabs -> Waitlist (bottom tab)
- All appointments -> Appointment (tap appointment card)
- Manage -> Add/Edit location (tap Add while Locations selected or tap location row)
- Manage -> Add/Edit service (tap Add while Services selected or tap service row)
- Manage -> Add/Edit staff (tap Add while Staff selected or tap staff row)
- Manage -> Staff hours (tap staff card secondary ellipsis action)
- Edit and detail screens -> previous screen (tap HeaderBar back chevron)

## Shared components
- src/components/HeaderBar.tsx — Native-style title/subtitle header with optional back chevron and action button.
- src/components/PrimaryButton.tsx — Pressable CTA button with primary, secondary, and danger variants.
- src/components/Chip.tsx — Selectable Pressable filter/choice chip.
- src/components/InfoCard.tsx — Elevated tappable card with icon, title, subtitle, meta text, and optional secondary ellipsis action using the split-Pressable pattern.

## Design tokens
- primary: #0F766E
- primaryDark: #115E59
- primaryLight: #CCFBF1
- accent: #F97316
- background: #F6F8FB
- surface: #FFFFFF
- card: #FFFFFF
- border: #D8E2EA
- textPrimary: #102A43
- textSecondary: #486581
- textDisabled: #9FB3C8
- textInverse: #FFFFFF
- success: #16A34A
- warning: #D97706
- error: #DC2626
- info: #2563EB
- shadowColor: #000000
