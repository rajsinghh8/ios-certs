# Ios Appp test55

A cross-platform project management app: sign in, review a dashboard of KPIs, task statistics, project progress and recent activity, browse and create projects, manage and filter tasks by status and priority, manage team members, read notifications, and adjust settings.

## Tech stack
React Native (Expo) + TypeScript, React Navigation, react-native-mmkv.

## Getting started
```
npm install --legacy-peer-deps
cp .env.example .env
npx expo start
```
Scan the QR code with Expo Go, or press w for the web preview.

Demo login: `admin@example.com` / `password123`.

## Environment variables
See .env.example. EXPO_PUBLIC_API_URL is optional — every entity runs on
local mock data (USE_MOCK = true in src/data/store.ts) until it's set and
each entity's flag is flipped to false.

## Project structure
- src/screens — one file per screen (plus co-located smoke tests)
- src/components — shared UI components
- src/navigation — root stack + bottom tab navigator
- src/data — mock records and the USE_MOCK-gated store
- src/api — shared axios client with auth and toast interceptors
- src/storage — platform-safe persisted storage wrapper (MMKV / AsyncStorage on web)
- src/hooks — shared hooks
- src/constants — shared literal values
- src/validation — reusable form validators
- src/utils — formatting, progress and confirm helpers
- src/theme — colors, spacing, typography, shadows, layout
- src/types — entity interfaces
